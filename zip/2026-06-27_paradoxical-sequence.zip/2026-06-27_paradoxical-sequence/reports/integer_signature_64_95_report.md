# Integer-Side Projection of 64-95 -> 32-63 Signature

## 1. Purpose

This analysis projects the sequence-level signature for `64-95 -> 32-63` back onto actual integer coordinates. It asks whether actual integers carrying the signature are biased in integer-side coordinates. It is not a mechanism proof.

The analysis unit is an occurrence-weighted actual integer projection inside the same sampled long-word universe used by the previous remaining_K chain analysis. A single integer can contribute more than once if multiple `START_IN_LAYER` occurrences in the initial `64-95` layer qualify.

## 2. Groups

- A: `transition = 64-95 -> 32-63`, `entry_route = START_IN_LAYER`, `group = pass`, `transition_k = 1`, `pre_k_window_3 = 1,1,1`.
- B: same pass route, but not the A signature.
- C: `from_bin = 64-95`, `entry_route = START_IN_LAYER`, `group = stay`, with the same signature.
- D: same stay route, but not the signature.

## 3. Main Findings

- `A_signature_pass`: count `1230`, unique n `1156`, weighted support `0.00343913`, mean log2(n) `21.4313`, median log2(n) `21.5602` (ok).
- `B_non_signature_pass`: count `8275`, unique n `6689`, weighted support `0.0242429`, mean log2(n) `22.3249`, median log2(n) `22.3266` (ok).
- `C_signature_stay`: count `9849`, unique n `3308`, weighted support `0.0247484`, mean log2(n) `21.929`, median log2(n) `21.8932` (ok).
- `D_non_signature_stay`: count `52772`, unique n `6766`, weighted support `0.14977`, mean log2(n) `22.2107`, median log2(n) `22.1894` (ok).
- A vs B: A has mean log2(n) shift `-0.89358` and median shift `-0.766406`.
- A vs C: A has mean log2(n) shift `-0.497657` and median shift `-0.332992`.

## 4. Residue Structure

- A top residues mod 3: 2:0.342555, 1:0.328906, 0:0.328538.
- A top residues mod 8: 7:0.381876, 1:0.221259, 3:0.199275, 5:0.19759.
- A top residues mod 16: 15:0.261107, 9:0.131505, 7:0.120769, 13:0.118744, 11:0.111766.
- A top residues mod 32: 31:0.178958, 9:0.0919693, 29:0.084394, 15:0.0821489, 23:0.0658063.
- A top residues mod 64: 63:0.0971838, 31:0.0817742, 41:0.0625933, 61:0.0552885, 47:0.0424586.
- A top residues mod 128: 127:0.0511837, 31:0.0465038, 63:0.0460002, 125:0.0455024, 41:0.0354103.
- A top residues mod 256: 253:0.0348405, 255:0.0333497, 191:0.0270258, 225:0.0266108, 159:0.026547.
- A top residues mod 384: 63:0.0219954, 253:0.0216324, 383:0.0186257, 293:0.0186045, 255:0.0183875.
- A top residues mod 5: 3:0.227998, 2:0.222117, 0:0.19446, 1:0.186525, 4:0.168899.
- A top residues mod 7: 2:0.165344, 1:0.165135, 0:0.154164, 4:0.140747, 5:0.134029.
- A top residues mod 9: 7:0.116611, 2:0.116044, 5:0.114719, 6:0.114664, 0:0.114018.

Residue rows include A-vs-B, A-vs-C, and A-vs-D delta/enrichment columns in `integer_signature_64_95_residue.csv`; cells with small support are marked as candidates, not claims.

## 5. Prefix-Cylinder Structure

- A top parity_prefix_4: `1111`:0.261107, `1011`:0.131505, `1110`:0.120769, `1001`:0.118744, `1101`:0.111766, `1010`:0.0897543.
- A top parity_prefix_6: `111111`:0.0971838, `111110`:0.0817742, `101111`:0.0625933, `100111`:0.0552885, `111101`:0.0424586, `111001`:0.0406199.
- A top parity_prefix_8: `10011111`:0.0348405, `11111111`:0.0333497, `11111101`:0.0270258, `10101111`:0.0266108, `11111011`:0.026547, `11111001`:0.0209706.
- A top valuation_prefix_4: `1,1,1,1`:0.178958, `2,1,1,1`:0.0625933, `3,1,1,1`:0.0455024, `1,1,1,2`:0.0424586, `1,2,1,1`:0.0343193, `2,2,1,1`:0.0311259.
- A top valuation_prefix_6: `1,1,1,1,1,1`:0.0511837, `1,1,1,1,1,2`:0.0270258, `1,1,1,1,2,1`:0.026547, `2,1,1,1,1,1`:0.0208908, `3,1,1,1,1,1`:0.0191164, `1,1,1,4,1,1`:0.015336.

## 6. Stopping-Time / Scale Coordinates

- `stopping_time` A mean `21.2538`, median `6`; A-B mean delta `6.30653`; A-C mean delta `-1.63543`.
- `total_stopping_time` A mean `298.268`, median `282`; A-B mean delta `-12.3611`; A-C mean delta `-26.0072`.
- `escape_length` A mean `107.004`, median `101`; A-B mean delta `-4.44572`; A-C mean delta `-9.87462`.
- `tau` A mean `51.8522`, median `51`; A-B mean delta `2.5311`; A-C mean delta `-2.91658`.
- `K_tau` A mean `77.5047`, median `76`; A-B mean delta `3.42801`; A-C mean delta `-4.71171`.
- `remaining_K` A mean `64`, median `64`; A-B mean delta `-0.562536`; A-C mean delta `-8.3607`.
- `x_K` A mean `55.6279`, median `54`; A-B mean delta `4.29628`; A-C mean delta `-4.22061`.
- `log_max_over_log_n` A mean `1.33153`, median `1.32539`; A-B mean delta `0.0210563`; A-C mean delta `-0.00212626`.
- `first_peak_time` A mean `136.448`, median `133`; A-B mean delta `2.12956`; A-C mean delta `-10.8665`.

## 7. Valuation Structure

- `v2_n` A mean `0`, median `0`; A-B mean delta `0`.
- `v2_3n_plus_1` A mean `1.74021`, median `1`; A-B mean delta `0.0860686`.
- `transition_k` A mean `1`, median `1`; A-B mean delta `-1.33099`.
- `cumulative_k_before_transition` A mean `13.5047`, median `12`; A-B mean delta `3.99055`.

## 8. Representative Integers

- n `149247` (`p=24`, `h=6`, pos `2`): log2(n) `17.1873`, remaining_K `64`, prefix `1,1,1,1,1,1,1,2,1,3,1,1`.
- n `157231` (`p=24`, `h=6`, pos `8`): log2(n) `17.2625`, remaining_K `64`, prefix `1,1,1,2,2,1,1,1,1,1,1,1`.
- n `165641` (`p=24`, `h=6`, pos `13`): log2(n) `17.3377`, remaining_K `64`, prefix `2,1,1,2,2,1,1,1,2,2,1,1`.
- n `186347` (`p=24`, `h=6`, pos `11`): log2(n) `17.5076`, remaining_K `64`, prefix `1,2,2,1,1,1,2,2,1,1,1,1`.
- n `196315` (`p=24`, `h=6`, pos `16`): log2(n) `17.5828`, remaining_K `64`, prefix `1,2,1,1,3,1,2,2,1,1,1,2`.
- n `209641` (`p=24`, `h=6`, pos `9`): log2(n) `17.6776`, remaining_K `64`, prefix `2,1,1,1,2,2,1,1,1,1,1,1`.
- n `220855` (`p=24`, `h=6`, pos `14`): log2(n) `17.7527`, remaining_K `64`, prefix `1,1,3,1,2,2,1,1,1,2,2,1`.
- n `235847` (`p=24`, `h=6`, pos `7`): log2(n) `17.8475`, remaining_K `64`, prefix `1,1,2,2,1,1,1,1,1,1,1,1`.
- n `236991` (`p=24`, `h=6`, pos `8`): log2(n) `17.8545`, remaining_K `64`, prefix `1,1,1,1,1,2,1,1,1,2,1,2`.
- n `248463` (`p=24`, `h=6`, pos `12`): log2(n) `17.9227`, remaining_K `64`, prefix `1,1,1,4,1,1,1,2,2,1,1,1`.
- n `261753` (`p=24`, `h=6`, pos `17`): log2(n) `17.9978`, remaining_K `64`, prefix `2,1,2,1,1,3,1,2,2,1,1,1`.
- n `4245203` (`p=25`, `h=2`, pos `7`): log2(n) `22.0174`, remaining_K `64`, prefix `1,3,1,1,4,1,1,1,2,2,5,2`.

## 9. Interpretation Limits

- This is an integer-side bias check.
- It does not claim causality or mechanism.
- It does not say that the signature arises from an intrinsic property of the integer.
- Small-support cells are candidate cells only.
- The analysis only checks correspondence between a sequence signature and integer coordinates.
- The cautious reading is that the sequence signature has an integer-side shadow where support is adequate.

## 10. Next Candidates

Only the strongest supported residue or prefix cells should be promoted to a next run. Good next candidates are larger-sample rechecks of A-vs-B and A-vs-C for the top mod `2^k` residues and top parity/valuation prefix cylinders listed above.
