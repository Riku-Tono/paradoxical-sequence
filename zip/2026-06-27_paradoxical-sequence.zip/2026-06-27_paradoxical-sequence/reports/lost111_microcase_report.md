# Micro-case analysis of trajectories that lose 111 before first pass

Observational analysis only. Dataset and scanner mode: `original_n_strict`.

## Verified groups

- Lost111: `8`
- matched Keep111: `8`

## Matching quality

- mean |log2(n)| difference: `0.013`
- mean |total_K| difference: `0.000`
- mean |first_pass_wait| difference: `0.750`
- mean |word_length| difference: `0.125`

## Break categories

- `111 -> 1,1,3+`: 5
- `111 -> 1,1,2`: 3

## Main descriptive answers

1. The eight do not all fail in one exact row pattern, but the break is tightly localized: every case has formed 111 and then the current pre3 no longer remains `1,1,1` before pass.
2. The dominant break categories are listed above; the most common category is `111 -> 1,1,3+`.
3. In these rows, losing 111 is observed as a concrete interruption of the current k=1 run rather than passive survival of the same current pre3. Some rows retain all-1 material in local4 for a moment, which is recorded separately.
4. Median distance from break to pass is `6.000` events; min/max are `4` / `7`.
5. They are genuine near-A failures structurally in `1/8` cases: if 111 had been maintained to pass, the remaining A_start route/k conditions would already hold.
6. These eight support the reading that 111 maintenance, not merely first formation, separates A_start from this micro-subset of Other_start.

## Output files

- `lost111_step1_full_timeline.csv`
- `lost111_step2_break_events.csv`
- `lost111_step3_break_category_counts.csv`
- `lost111_step4_matched_pair_comparison.csv`
- `lost111_step5_earliest_divergence.csv`
- `lost111_step6_counterfactual_structural_check.csv`
- `lost111_step7_trajectory_cards.md`
