# Formation of all-1 context before first pass

Observational analysis only. Dataset and scanner mode: `original_n_strict`. Window: first `64-95` entry through first `64-95 -> 32-63` pass, inclusive.

## Verified counts

- total trajectories: `550`
- G0 never enters `64-95`: `12`
- G1 enters `64-95`: `538`
- A_start: `365`
- A_inflow: `104`
- Other_start: `66`

## Class summary

- A_start median first 111: `6.000`, median first 1111: `8.000`, maintain-111-to-pass share `1.000`.
- A_inflow median first 111: `15.000`, median first 1111: `16.000`, maintain-111-to-pass share `1.000`.
- Other_start median first 111: `4.500`, median first 1111: `6.000`, maintain-111-to-pass share `0.000`.

Other_start decomposition:
- never reaches 111: `58/66`
- reaches 111 but loses it before pass: `8/66`
- maintains 111 to pass: `0/66`
- first 111 appears at distance <= 1 from pass: `0/66`

## Main descriptive answers

1. The all-1 context grows as a run process inside the layer: `1` and `11` appear earlier and more broadly; `111` and `1111` distinguish the all-1 pass faces.
2. In A_start and A_inflow, 111 is usually formed before the pass rather than only at the pass: median distance from first 111 to pass is `1.000` for A_start and `1.000` for A_inflow.
3. Other_start mostly fails by not forming 111 in the pre-pass window (`58/66`), with a smaller group that forms 111 and then loses it (`8/66`).
4. A_start is characterized by stable maintenance of 111 through the pass in this dataset: maintain-111 share `1.000` and maintain-1111 share `0.564`.

## Output files

- `all1_formation_per_trajectory.csv`
- `all1_formation_event_scan.csv`
- `all1_formation_class_summary.csv`
