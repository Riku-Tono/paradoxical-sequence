# Twelve trajectories with no 64-95 -> 32-63 transition

Observational pass only. Event definitions are the prior remaining_K scanner definitions, using the `original_n_strict` mode because that reproduces the expected 12-count exclusion set.

## Step 1. Verified exclusion

Count: 12 trajectories.

7, 9, 18, 19, 25, 91, 121, 242, 243, 484, 485, 486

Every listed trajectory has `target_hit_count = 0` in `step1_verified_exclusion.csv`.

## Step 2. Raw sequence and pairwise outputs

- `step2_trajectory_sequences.csv` contains the full per-trajectory sequences.
- `step2_pairwise_raw_comparison.csv` contains all 66 pairwise comparisons with identity, LCS length, common-prefix length, and common-suffix length for every requested sequence family.
- `step2_identical_sequences.csv` contains only exact repeated sequences.

## Step 3. Alternative transition frequencies

- `32-63 -> 32-63`: 149
- `16-31 -> 16-31`: 42
- `8-15 -> 8-15`: 36
- `4-7 -> 0-1`: 12
- `8-15 -> 4-7`: 12
- `16-31 -> 8-15`: 8
- `32-63 -> 16-31`: 7
- `4-7 -> 4-7`: 5

## Step 4. Signature clustering

Every trajectory is unique under the combined transition_k / entry_route / pre_k_window_3 / local-window profile.

## Step 5. Near-A distance

- `7`: 0/4; missing reaches 64-95; START_IN_LAYER; transition_k = 1; pre_k_window_3 = (1,1,1)
- `9`: 0/4; missing reaches 64-95; START_IN_LAYER; transition_k = 1; pre_k_window_3 = (1,1,1)
- `18`: 0/4; missing reaches 64-95; START_IN_LAYER; transition_k = 1; pre_k_window_3 = (1,1,1)
- `19`: 0/4; missing reaches 64-95; START_IN_LAYER; transition_k = 1; pre_k_window_3 = (1,1,1)
- `25`: 0/4; missing reaches 64-95; START_IN_LAYER; transition_k = 1; pre_k_window_3 = (1,1,1)
- `91`: 0/4; missing reaches 64-95; START_IN_LAYER; transition_k = 1; pre_k_window_3 = (1,1,1)
- `121`: 0/4; missing reaches 64-95; START_IN_LAYER; transition_k = 1; pre_k_window_3 = (1,1,1)
- `242`: 0/4; missing reaches 64-95; START_IN_LAYER; transition_k = 1; pre_k_window_3 = (1,1,1)
- `243`: 0/4; missing reaches 64-95; START_IN_LAYER; transition_k = 1; pre_k_window_3 = (1,1,1)
- `484`: 0/4; missing reaches 64-95; START_IN_LAYER; transition_k = 1; pre_k_window_3 = (1,1,1)
- `485`: 0/4; missing reaches 64-95; START_IN_LAYER; transition_k = 1; pre_k_window_3 = (1,1,1)
- `486`: 0/4; missing reaches 64-95; START_IN_LAYER; transition_k = 1; pre_k_window_3 = (1,1,1)

Missing-condition counts:
- `reaches 64-95`: 12
- `START_IN_LAYER`: 12
- `transition_k = 1`: 12
- `pre_k_window_3 = (1,1,1)`: 12

## Step 6. Time-order comparison

`step6_time_order_windows.csv` gives before/during/after windows around the best available A-region anchor. In this run every anchor is `highest_remaining_K_no_64_95`, because no trajectory enters the `64-95` band. `step6_time_order_summary.csv` gives the compact observed change labels.

## Final descriptive answers

1. The 12 share a broad exclusion fact rather than a common alternative corridor: all remain below `64-95`. The dominant observed movement is repeated `32-63 -> 32-63` stay behavior among the longer cases, not a replacement `64-95` corridor.
2. They are fundamentally different from A under the requested four-condition distance: every trajectory scores 0/4 because none reaches `64-95` at all.
3. The dominating missing condition is `reaches 64-95`; once that is absent, `START_IN_LAYER`, `transition_k = 1`, and `pre_k_window_3 = (1,1,1)` at `64-95` are also absent for all 12.
4. There is no evidence here of a second canonical signature. The combined signature profiles are all singleton clusters in this 12-trajectory set.
5. The set is heterogeneous under the requested clustering. It is structurally coherent only in the coarse sense that all 12 never enter the A source band.
