# Rozier-Terracol External Benchmark Overlay

## Purpose

This overlays Rozier-Terracol Appendix C acyclic paradoxical starting integers on the remaining_K coordinate system and the observed `64-95 -> 32-63` signature. It uses Rozier-Terracol only as an external benchmark, not as proof.

Source: Rozier and Terracol, `Paradoxical behavior in Collatz sequences`, Appendix C, arXiv:2502.00948.

## Benchmark Set

- Extracted Appendix C occurrences: `593`.
- Distinct starting integers: `550`.
- Integers appearing in multiple `(j,q)` groups: `40`.

## Signature Overlap

- `hits_64_95_to_32_63`: `536` / `550` = `0.974545`.
- `hits_start_in_layer_64_95`: `443` / `550` = `0.805455`.
- `hits_transition_k1_64_95`: `516` / `550` = `0.938182`.
- `hits_pre111_64_95`: `468` / `550` = `0.850909`.
- `hits_full_A_signature`: `377` / `550` = `0.685455`.
- `hits_32_63_signature`: `0` / `550` = `0`.
- `hits_96_127_to_64_95`: `93` / `550` = `0.169091`.
- `hits_any_band_signature`: `470` / `550` = `0.854545`.

## Matched Baselines

- `log2_floor` / `hits_full_A_signature`: Rozier `0.685455`, baseline `nan`, enrichment `nan`, support `0` (no_actual_support).
- `log2_floor` / `hits_32_63_signature`: Rozier `0`, baseline `nan`, enrichment `nan`, support `0` (no_actual_support).
- `log2_floor` / `hits_any_band_signature`: Rozier `0.854545`, baseline `nan`, enrichment `nan`, support `0` (no_actual_support).
- `mod32` / `hits_full_A_signature`: Rozier `0.685455`, baseline `0.00573461`, enrichment `119.529`, support `93951` (ok).
- `mod32` / `hits_32_63_signature`: Rozier `0`, baseline `0.0449032`, enrichment `0`, support `93951` (ok).
- `mod32` / `hits_any_band_signature`: Rozier `0.854545`, baseline `0.054526`, enrichment `15.6722`, support `93951` (ok).
- `mod64` / `hits_full_A_signature`: Rozier `0.685455`, baseline `0.00573461`, enrichment `119.529`, support `93951` (ok).
- `mod64` / `hits_32_63_signature`: Rozier `0`, baseline `0.0449032`, enrichment `0`, support `93951` (ok).
- `mod64` / `hits_any_band_signature`: Rozier `0.854545`, baseline `0.054526`, enrichment `15.6722`, support `93951` (ok).
- `parity_prefix_4` / `hits_full_A_signature`: Rozier `0.685455`, baseline `0.00573461`, enrichment `119.529`, support `93951` (ok).
- `parity_prefix_4` / `hits_32_63_signature`: Rozier `0`, baseline `0.0449032`, enrichment `0`, support `93951` (ok).
- `parity_prefix_4` / `hits_any_band_signature`: Rozier `0.854545`, baseline `0.054526`, enrichment `15.6722`, support `93951` (ok).
- `parity_prefix_6` / `hits_full_A_signature`: Rozier `0.685455`, baseline `0.00573461`, enrichment `119.529`, support `93951` (ok).
- `parity_prefix_6` / `hits_32_63_signature`: Rozier `0`, baseline `0.0449032`, enrichment `0`, support `93951` (ok).
- `parity_prefix_6` / `hits_any_band_signature`: Rozier `0.854545`, baseline `0.054526`, enrichment `15.6722`, support `93951` (ok).
- `combined_log2_mod64_parity6` / `hits_full_A_signature`: Rozier `0.685455`, baseline `nan`, enrichment `nan`, support `0` (no_actual_support).
- `combined_log2_mod64_parity6` / `hits_32_63_signature`: Rozier `0`, baseline `nan`, enrichment `nan`, support `0` (no_actual_support).
- `combined_log2_mod64_parity6` / `hits_any_band_signature`: Rozier `0.854545`, baseline `nan`, enrichment `nan`, support `0` (no_actual_support).

## Residue And Prefix Overlay

- `mod8_is_7`: Rozier `0.123636`, actual baseline `0.338209`, enrichment `0.365562`, support `68` (ok).
- `mod16_is_15`: Rozier `0.0527273`, actual baseline `0.170883`, enrichment `0.308558`, support `29` (ok).
- `mod32_is_31`: Rozier `0.02`, actual baseline `0.0707672`, enrichment `0.282617`, support `11` (ok).
- `mod64_is_63`: Rozier `0.00909091`, actual baseline `0.025936`, enrichment `0.350513`, support `5` (low).
- `mod128_is_127`: Rozier `0.00363636`, actual baseline `0.00960136`, enrichment `0.378734`, support `2` (low).
- `mod256_is_255`: Rozier `0`, actual baseline `0.00347475`, enrichment `0`, support `0` (low).
- `parity_prefix_4_all1`: Rozier `0.0527273`, actual baseline `0.170883`, enrichment `0.308558`, support `29` (ok).
- `parity_prefix_6_all1`: Rozier `0.00909091`, actual baseline `0.025936`, enrichment `0.350513`, support `5` (low).
- `valuation_prefix_4_all1`: Rozier `0.0436364`, actual baseline `0.0707672`, enrichment `0.616619`, support `24` (ok).
- `log2_floor_at_or_below_actual_q25_21.0`: Rozier `1`, actual baseline `0.369086`, enrichment `2.7094`, support `550` (ok).

## Reading

The external benchmark overlaps strongly with the `64-95 -> 32-63` A carrier when Rozier-Terracol starting integers are mapped through their odd cores into the odd-accelerated remaining_K coordinate system. It does not align with the checked `32-63 -> 16-31` face. The residue/prefix overlay also shows that the Rozier benchmark is not simply enriched in `2^k - 1` residues or all-1 prefixes; those shares are mostly below the sampled actual baseline.

The log2 and combined log2-matched baselines have no actual support because the Rozier-Terracol integers are far below the sampled actual universe used in the remaining_K analysis. For that reason, the strongest supported baseline comparison is residue/prefix matching, where full A overlap is enriched relative to the sampled actual baseline. This is compatible with a real external overlap, but it is not proof that the two phenomena are the same.

## Limits

- No causality is claimed.
- Rozier-Terracol is used only as an external benchmark.
- Even Rozier starting integers are mapped to odd-accelerated remaining_K coordinates through their odd core, while ordinary stopping coordinates are computed on the original integer.
- Low-support cells are marked and should remain candidates.
- Matched baselines use the same sampled actual universe as the earlier remaining_K analysis, not an exhaustive integer universe.
