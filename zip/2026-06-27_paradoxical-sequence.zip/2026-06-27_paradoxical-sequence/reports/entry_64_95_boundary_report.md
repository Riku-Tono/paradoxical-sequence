# Entry boundary into remaining_K band 64-95

Observational analysis only. Dataset: `original_n_strict` rows from the same Rozier-overlay trajectory set used in the previous report; event scanner definitions are reused from the remaining_K pipeline.

## Group sizes

- total trajectories: `550`
- G0 never enters `64-95`: `12`
- G1 enters `64-95`: `538`
- G2 first `64-95` event passes to `32-63`: `5`
- G3 enters `64-95` but never has `64-95 -> 32-63`: `0`

## Step 1. Max remaining_K profile

G0 max_remaining_K min/median/max: `11` / `60.0` / `63`.

G0 max_remaining_K_bin counts:
- `16-31`: 1
- `32-63`: 7
- `8-15`: 4

Reading: the 12 G0 cases are not all clustered just below 64; five are below `32-63`, and seven are in `32-63`.

## Step 2. Odd-core collapse

The 12 rows collapse to `8` distinct odd cores.

Duplicate odd-core groups:
- odd_core `9`: [9, 18]
- odd_core `121`: [121, 242, 484]
- odd_core `243`: [243, 486]

## Step 3. First-entry analysis

First `64-95` event passes immediately to `32-63` in `5/538` G1 trajectories.
A-like at first entry (`pass`, `START_IN_LAYER`, `transition_k=1`, `pre111`) occurs in `0/538` G1 trajectories.
A signature anywhere in trajectories that enter `64-95`: `365/538`.

First-entry transition counts:
- `64-95 -> 64-95`: 533
- `64-95 -> 32-63`: 5

First-entry transition_k counts:
- `1`: 275
- `2`: 147
- `3`: 53
- `4`: 30
- `5`: 19
- `6`: 8
- `7`: 6

First-entry entry_route counts:
- `START_IN_LAYER`: 431
- `INFLOW_FROM_96-127`: 107

First-entry pre_k_window_3 counts:
- `1`: 213
- `2`: 110
- `3+`: 108
- `1,1`: 13
- `1,2,1`: 11
- `1,1,2`: 10
- `2,2,1`: 10
- `2,1`: 9
- `1,3+,2`: 8
- `3+,2,1`: 7

## Step 4. Boundary-near controls

B_low size: `7`. B_entry size: `538`.

B_low summary: mean log2(n) `8.005`, mean word length `34.286`, mean total_K `61.857`, share valuation prefix 1,1,1,1 `0.000`, share parity 1111 `0.000`, share mod16=15 `0.000`, share mod32=31 `0.000`.
B_entry summary: mean log2(n) `10.765`, mean word length `47.281`, mean total_K `85.190`, share valuation prefix 1,1,1,1 `0.048`, share parity 1111 `0.054`, share mod16=15 `0.054`, share mod32=31 `0.020`.

Because B_low has only seven cases, these coordinate contrasts should be read as low-support diagnostics only.

## Step 5. Transition just below the boundary

For G0, highest remaining_K events are listed in `step5_G0_highest_events.csv`. The short G0 cases immediately move downstream from their highest event; the longer G0 cases start in `32-63` and usually stay in `32-63` before later moving down.

## Step 6. Threshold counts

- `48-55`: count `0`, mean word length `nan`, mean total_K `nan`, all-1 valuation prefix4 `nan`, parity1111 `nan`, mod16=15 `nan`, mod32=31 `nan`.
- `56-63`: count `7`, mean word length `34.286`, mean total_K `61.857`, all-1 valuation prefix4 `0.000`, parity1111 `0.000`, mod16=15 `0.000`, mod32=31 `0.000`.
- `64-71`: count `47`, mean word length `37.638`, mean total_K `68.936`, all-1 valuation prefix4 `0.000`, parity1111 `0.000`, mod16=15 `0.000`, mod32=31 `0.000`.
- `72-95`: count `384`, mean word length `46.177`, mean total_K `83.289`, all-1 valuation prefix4 `0.055`, parity1111 `0.052`, mod16=15 `0.052`, mod32=31 `0.023`.

## Final descriptive answers

1. Yes. The 12 no-transition trajectories are truly outside the `64-95` layer: all have `enters_64_95 = 0`.
2. They are not 12 independent odd-core trajectories. They collapse to `8` odd cores; duplicates appear under powers of two.
3. The entrance is gradual in this coordinate audit rather than a clean sharp integer-side break. The threshold rows show count and mean-size changes, but no single residue/prefix flag cleanly separates the boundary.
4. The typical first-entry signature is dominated by the observed first-entry counts above; most first `64-95` events are `64-95 -> 64-95` stays, with `transition_k=1` common.
5. A does not usually appear at first entry: first-entry A-like events are `0/538`. A-anywhere is `365/538`, so A is mostly a later-inside-layer event in this dataset.
6. There is no strong integer-side shadow at the 64 boundary in these simple coordinates. The B_low group is small, so this is a descriptive non-finding, not a proof of invisibility.
7. These 12 should be treated as boundary non-entrants and low-K/shorter cases, not near-A failures inside the `64-95` layer.

## Output files

- `step1_max_remaining_K_profile.csv`
- `step2_odd_core_collapse.csv`
- `step3_first_64_95_entry.csv`
- `step4_boundary_controls.csv`
- `step5_G0_highest_events.csv`
- `step6_threshold_counts.csv`
