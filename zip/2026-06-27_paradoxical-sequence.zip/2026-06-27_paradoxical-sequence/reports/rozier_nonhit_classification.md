# Rozier A Non-Hit Classification

## 1. Purpose

This is an Appendix diagnostic that classifies which Rozier-Terracol starting integers do not hit the full A signature. It is not a mechanism claim.

Full A signature: `64-95 -> 32-63`, `START_IN_LAYER`, `transition_k=1`, `pre_k_window_3=1,1,1`, all on the same occurrence.

## 2. Counts

- `odd_core`: total `550`, A-hit `377`, A-non-hit `173`, A-hit rate `0.685455`, A-non-hit rate `0.314545`.
- `odd_only`: total `294`, A-hit `177`, A-non-hit `117`, A-hit rate `0.602041`, A-non-hit rate `0.397959`.
- `original_n_strict`: total `550`, A-hit `365`, A-non-hit `185`, A-hit rate `0.663636`, A-non-hit rate `0.336364`.

## 3. Non-Hit Primary Reasons

### odd_core
- `Class 1: has 64-95 -> 32-63, but not START_IN_LAYER`: `93`
- `Class 3: transition_k=1 exists, but pre_k_window_3 != 1,1,1`: `47`
- `Class 2: START_IN_LAYER exists, but transition_k != 1`: `19`
- `Class 0: no 64-95 -> 32-63 transition`: `14`

### odd_only
- `Class 1: has 64-95 -> 32-63, but not START_IN_LAYER`: `74`
- `Class 3: transition_k=1 exists, but pre_k_window_3 != 1,1,1`: `21`
- `Class 2: START_IN_LAYER exists, but transition_k != 1`: `14`
- `Class 0: no 64-95 -> 32-63 transition`: `8`

### original_n_strict
- `Class 1: has 64-95 -> 32-63, but not START_IN_LAYER`: `107`
- `Class 3: transition_k=1 exists, but pre_k_window_3 != 1,1,1`: `46`
- `Class 2: START_IN_LAYER exists, but transition_k != 1`: `20`
- `Class 0: no 64-95 -> 32-63 transition`: `12`

## 4. Near-A Analysis

- `odd_core`: near-A non-hits `154` / `173`.
  - missing `start_in_layer`: `91`
  - missing `pre111`: `47`
  - missing `transition_64_95_to_32_63`: `16`
- `odd_only`: near-A non-hits `102` / `117`.
  - missing `start_in_layer`: `72`
  - missing `pre111`: `21`
  - missing `transition_64_95_to_32_63`: `9`
- `original_n_strict`: near-A non-hits `164` / `185`.
  - missing `start_in_layer`: `104`
  - missing `pre111`: `46`
  - missing `transition_64_95_to_32_63`: `14`

## 5. Other Band Hits

- `odd_core`: hits_96_127 `93`, hits_32_63 `0`, any_band `93` among `173` non-hits.
- `odd_only`: hits_96_127 `74`, hits_32_63 `0`, any_band `74` among `117` non-hits.
- `original_n_strict`: hits_96_127 `107`, hits_32_63 `0`, any_band `107` among `185` non-hits.

## 6. First Occurrence vs Later Occurrence

- `odd_core` A-hit: first 64-95 to 32-63 `0/377`; A-non-hit: first 64-95 to 32-63 `0/173`.
- `odd_only` A-hit: first 64-95 to 32-63 `0/177`; A-non-hit: first 64-95 to 32-63 `0/117`.
- `original_n_strict` A-hit: first 64-95 to 32-63 `0/365`; A-non-hit: first 64-95 to 32-63 `0/185`.

## 7. Short Reading

- `original_n_strict`: most non-hits are `Class 1: has 64-95 -> 32-63, but not START_IN_LAYER`; near-A non-hits `164` / `185`.
- `odd_core`: most non-hits are `Class 1: has 64-95 -> 32-63, but not START_IN_LAYER`; near-A non-hits `154` / `173`.
- `odd_only`: most non-hits are `Class 1: has 64-95 -> 32-63, but not START_IN_LAYER`; near-A non-hits `102` / `117`.

The non-hit side is not random noise. Most non-hits still move through the same broad 64-95 -> 32-63 corridor, but miss the strict A face by route or local k-context. This is useful as a map of what A excludes, not as a new main claim.

## 8. Interpretation Limits

- Rozier-Terracol paradoxical sequences and this A signature are defined differently.
- Non-hit classification is an external benchmark map, not a causal or mechanism explanation.
- The classification is Appendix diagnostic material, not the central claim.
- Small classes should be treated as candidate structure only.
