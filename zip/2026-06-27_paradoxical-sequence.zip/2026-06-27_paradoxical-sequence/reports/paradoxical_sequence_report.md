# Paradoxical Sequence Analysis

## 目的

`remaining_K` chain で確認された、同じ帯の mass deficit と下流 conditional excess が同時に立つ逆符号現象を、sequence / k-pattern / state / entry route に分解する。これは観測解析であり、原因や生成機構の証明ではない。

## 対象遷移

- `96-127 -> 64-95`
- `64-95 -> 32-63`
- `32-63 -> 16-31`

## 全体結果

- `96-127 -> 64-95`: from mass Δ `-0.0130593`, actual pass率 `0.176505`, iid pass率 `0.167431`, conditional Δ `0.00907383`, support `0.0503482`.
- `64-95 -> 32-63`: from mass Δ `-0.0752273`, actual pass率 `0.116249`, iid pass率 `0.108388`, conditional Δ `0.00786124`, support `0.608096`.
- `32-63 -> 16-31`: from mass Δ `-0.180211`, actual pass率 `0.106222`, iid pass率 `0.101604`, conditional Δ `0.00461753`, support `4.09928`.

3対象すべてで、from-bin mass は actual 側が薄い一方、pass率は actual 側が高い。conditional excess 自体は `96-127 -> 64-95` が最大だが、support は小さい。質量差の大きさは `32-63 -> 16-31` と `64-95 -> 32-63` の方が安定して読むべき対象になる。

## Transition ごとの解析

### 96-127 -> 64-95

Pass vs Stay / Entry Route:
- ALL: actual from `0.0186444`, iid from `0.0317038`, mass Δ `-0.0130593`, actual pass `0.176505`, iid pass `0.167431`, conditional Δ `0.00907383`.
- `START_IN_LAYER`: actual route share `1`, iid route share `1`, actual pass `0.176505`, iid pass `0.167431`, conditional Δ `0.00907383` (ok support).

Focus State (`late_growth|deep_32_63|even`):
- `late_growth|deep_32_63|even`: no supported row for this transition in the sampled universe.

Positive pass-side concentrations:
- `pre_k_window_3` `1,2,2`: pass-share Δ `0.0215746`, support `0.0013634` (low).
- `pre_k_window_3` `2,1,2`: pass-share Δ `0.0208569`, support `0.00167386` (low).
- `local_rolling_k_window_3` `2,2,2`: pass-share Δ `0.0200453`, support `0.00267312` (ok).
- `pre_k_window_5` `1,2,1,2,2`: pass-share Δ `0.0195416`, support `0.000175214` (low).
- `k_prefix_3` `2,1,3+`: pass-share Δ `0.0175019`, support `0.0014928` (low).
- `pre_k_window_5` `3+`: pass-share Δ `0.0150536`, support `0.00140668` (low).
Negative/depleted pass-side concentrations:
- `pre_k_window_3` `1,1,2`: pass-share Δ `-0.0271487`, support `0.00327711` (ok).
- `pre_k_window_3` `1,1,1`: pass-share Δ `-0.0207669`, support `0.00645446` (ok).
- `transition_k` `3+`: pass-share Δ `-0.0194654`, support `0.0087342` (ok).
- `local_rolling_k_window_3` `3+,1,1`: pass-share Δ `-0.0159568`, support `0.0102771` (ok).

### 64-95 -> 32-63

Pass vs Stay / Entry Route:
- ALL: actual from `0.266435`, iid from `0.341662`, mass Δ `-0.0752273`, actual pass `0.116249`, iid pass `0.108388`, conditional Δ `0.00786124`.
- `INFLOW_FROM_96-127`: actual route share `0.241089`, iid route share `0.299808`, actual pass `0.0512316`, iid pass `0.0518211`, conditional Δ `-0.000589567` (ok support).
- `START_IN_LAYER`: actual route share `0.758911`, iid route share `0.700192`, actual pass `0.136904`, iid pass `0.132609`, conditional Δ `0.00429505` (ok support).

Focus State (`late_growth|deep_32_63|even`):
- route `ALL`: actual from `0.0418732`, iid from `0.0541741`, mass Δ `-0.0123009`, actual pass `0.177095`, iid pass `0.17506`, conditional Δ `0.00203578` (ok support).
- route `START_IN_LAYER`: actual from `0.0418732`, iid from `0.0541741`, mass Δ `-0.0123009`, actual pass `0.177095`, iid pass `0.17506`, conditional Δ `0.00203578` (ok support).

Positive pass-side concentrations:
- `transition_k` `1`: pass-share Δ `0.0495034`, support `0.353739` (ok).
- `pre_k_window_3` `1,1,1`: pass-share Δ `0.0339716`, support `0.09395` (ok).
- `pre_k_window_3` `1,2,3+`: pass-share Δ `0.0162109`, support `0.0120311` (ok).
- `local_rolling_k_window_3` `3+,1,1`: pass-share Δ `0.0154696`, support `0.131566` (ok).
- `pre_k_window_5` `2,1,1,1,1`: pass-share Δ `0.0146934`, support `0.0125406` (ok).
- `local_rolling_k_window_4` `1,1,1,1`: pass-share Δ `0.0121055`, support `0.158644` (ok).
Negative/depleted pass-side concentrations:
- `transition_k` `2`: pass-share Δ `-0.0415682`, support `0.155326` (ok).
- `pre_k_window_3` `1,1,3+`: pass-share Δ `-0.0209307`, support `0.0318745` (ok).
- `pre_k_window_3` `1,1,2`: pass-share Δ `-0.0154673`, support `0.0476053` (ok).
- `local_rolling_k_window_4` `2,1,1,1`: pass-share Δ `-0.0117566`, support `0.140627` (ok).

### 32-63 -> 16-31

Pass vs Stay / Entry Route:
- ALL: actual from `1.95953`, iid from `2.13974`, mass Δ `-0.180211`, actual pass `0.106222`, iid pass `0.101604`, conditional Δ `0.00461753`.
- `INFLOW_FROM_64-95`: actual route share `0.31012`, iid route share `0.347564`, actual pass `0.0509682`, iid pass `0.0497946`, conditional Δ `0.00117357` (ok support).
- `START_IN_LAYER`: actual route share `0.68988`, iid route share `0.652436`, actual pass `0.13106`, iid pass `0.129204`, conditional Δ `0.00185568` (ok support).

Focus State (`late_growth|deep_32_63|even`):
- route `ALL`: actual from `0.258959`, iid from `0.315629`, mass Δ `-0.0566699`, actual pass `0.0551497`, iid pass `0.0546024`, conditional Δ `0.000547325` (ok support).
- route `INFLOW_FROM_64-95`: actual from `0.146397`, iid from `0.188814`, mass Δ `-0.0424173`, actual pass `0.0506538`, iid pass `0.0502277`, conditional Δ `0.000426081` (ok support).
- route `START_IN_LAYER`: actual from `0.112562`, iid from `0.126815`, mass Δ `-0.0142526`, actual pass `0.060997`, iid pass `0.0611158`, conditional Δ `-0.000118785` (ok support).

Positive pass-side concentrations:
- `pre_k_window_5` `1,1,1,1,2`: pass-share Δ `0.0114368`, support `0.0949464` (ok).
- `pre_k_window_3` `1,1,2`: pass-share Δ `0.00985669`, support `0.334897` (ok).
- `transition_k` `2`: pass-share Δ `0.00878829`, support `1.03331` (ok).
- `pre_k_window_5` `3+,2,1,1,2`: pass-share Δ `0.00848144`, support `0.0128147` (ok).
- `pre_k_window_5` `1,3+,2,1,1`: pass-share Δ `0.00801259`, support `0.0306705` (ok).
- `local_rolling_k_window_3` `2,1,2`: pass-share Δ `0.00600945`, support `0.531786` (ok).
Negative/depleted pass-side concentrations:
- `transition_k` `1`: pass-share Δ `-0.00959151`, support `2.45117` (ok).
- `pre_k_window_3` `1,2,1`: pass-share Δ `-0.00696537`, support `0.30714` (ok).
- `local_rolling_k_window_3` `1,1,1`: pass-share Δ `-0.00657314`, support `1.8496` (ok).
- `pre_k_window_5` `1,1,1,2,3+`: pass-share Δ `-0.00488347`, support `0.0257948` (ok).

## 代表系列

`paradoxical_sequence_transition_examples.csv` に、各 transition/source/group ごとの代表系列を保存した。行数は以下。

- `32-63 -> 16-31` / `actual` / `pass`: `12` rows
- `32-63 -> 16-31` / `actual` / `stay`: `12` rows
- `32-63 -> 16-31` / `iid` / `pass`: `12` rows
- `32-63 -> 16-31` / `iid` / `stay`: `12` rows
- `64-95 -> 32-63` / `actual` / `pass`: `12` rows
- `64-95 -> 32-63` / `actual` / `stay`: `12` rows
- `64-95 -> 32-63` / `iid` / `pass`: `12` rows
- `64-95 -> 32-63` / `iid` / `stay`: `12` rows
- `96-127 -> 64-95` / `actual` / `pass`: `12` rows
- `96-127 -> 64-95` / `actual` / `stay`: `12` rows
- `96-127 -> 64-95` / `iid` / `pass`: `12` rows
- `96-127 -> 64-95` / `iid` / `stay`: `12` rows

## Entry Route の読み

- `96-127 -> 64-95` は今回の観測範囲では `START_IN_LAYER` のみ。上流 `128+` からの流入はこの母集団では見えない。
- `64-95 -> 32-63` は `START_IN_LAYER` 側に conditional excess が集中し、`INFLOW_FROM_96-127` 側はほぼ同率かやや negative。したがって、この遷移の conditional excess は混合比だけではなく、開始群側の pass率差と対応している。
- `32-63 -> 16-31` は `START_IN_LAYER` と `INFLOW_FROM_64-95` の両方が positive。mass deficit は inflow 側で大きいが、pass率差は両側に薄く広がる。

## k-pattern の読み

- `64-95 -> 32-63` では `transition_k=1` と `pre_k_window_3=1,1,1` が actual pass 側に強く寄る。これは今回の中で最も読みやすい sequence-level concentration。
- `32-63 -> 16-31` では `transition_k=2`, `pre_k_window_3=1,1,2`, `pre_k_window_5=1,1,1,1,2` が pass 側に寄る。support は比較的十分。
- `96-127 -> 64-95` は conditional Δ は最大だが、上位patternの多くが low support。ここは観測候補として扱い、強い主張にしない。

## 観測の限界

- 前回と同じ sampled long-word / final-state-defined universe を用いた。全列挙ではない。
- `support_note=low` は重み付き support `< 0.002` とした。low support の pattern は安定主張ではなく候補。
- rolling window は transition 近傍の局所窓に限定した。全語内の全window頻度ではない。
- ここで言えるのは、逆符号現象を担う sequence 群・状態・流入経路との対応であり、原因ではない。

## 次に調べる候補

1. `64-95 -> 32-63` の `transition_k=1` / `pre_k_window_3=1,1,1` を大きめ iid sample で安定性確認する。
2. `32-63 -> 16-31` の `START_IN_LAYER` と `INFLOW_FROM_64-95` を分け、`1,1,2` 系がどちらに濃いかを見る。
3. `96-127 -> 64-95` は support を増やすか、現時点では低サポート候補として保留する。
