# Joint waiting-time and within-layer feature analysis

Observational analysis only. Dataset and scanner mode: `original_n_strict`, same 550-trajectory universe as the previous boundary report.

## Verified counts

- total trajectories: `550`
- G0 never enters `64-95`: `12`
- G1 enters `64-95`: `538`
- A-anywhere among G1: `365`
- A-miss among G1: `173`

## A-hit vs A-miss summary

- `A_hit` count `365`; median first-pass wait `10.000`, mean `10.458`, min/max `2`/`19`; median longest k=1 run `4.000`; pre111-before-pass share `1.000`; first-pass k=1 share `1.000`.
- `A_miss` count `173`; median first-pass wait `16.000`, mean `12.023`, min/max `0`/`18`; median longest k=1 run `3.000`; pre111-before-pass share `0.665`; first-pass k=1 share `0.879`.

## Waiting-time strata

- `wait_0`: count `5`, A-hit rate `0.000`, median k=1 run `0.000`, pre111 share `0.000`.
- `wait_1`: count `9`, A-hit rate `0.000`, median k=1 run `1.000`, pre111 share `0.000`.
- `wait_2`: count `18`, A-hit rate `0.056`, median k=1 run `1.500`, pre111 share `0.056`.
- `wait_3_5`: count `65`, A-hit rate `0.738`, median k=1 run `3.000`, pre111 share `0.738`.
- `wait_6_10`: count `145`, A-hit rate `0.945`, median k=1 run `4.000`, pre111 share `0.952`.
- `wait_11_plus`: count `296`, A-hit rate `0.605`, median k=1 run `4.000`, pre111 share `0.990`.

## First-pass timing of A

Among A-hit trajectories, first A equals first `64-95 -> 32-63` pass in `365/365` rows.
A before first pass: `0`. A after first pass: `0`.

## Dominant A-miss first-pass signatures

- route `INFLOW_FROM_96-127`, k `1`, pre3 `1,1,1`, first_pass_is_A `0`: `104`
- route `START_IN_LAYER`, k `1`, pre3 `3+,1,1`, first_pass_is_A `0`: `28`
- route `START_IN_LAYER`, k `5`, pre3 `2,3+,3+`, first_pass_is_A `0`: `7`
- route `START_IN_LAYER`, k `3`, pre3 `2,2,3+`, first_pass_is_A `0`: `5`
- route `START_IN_LAYER`, k `1`, pre3 `3+,1`, first_pass_is_A `0`: `4`
- route `START_IN_LAYER`, k `1`, pre3 `2,3+,1`, first_pass_is_A `0`: `4`
- route `START_IN_LAYER`, k `1`, pre3 `1,3+,1`, first_pass_is_A `0`: `3`
- route `START_IN_LAYER`, k `1`, pre3 `1`, first_pass_is_A `0`: `2`
- route `START_IN_LAYER`, k `1`, pre3 `3+,3+,1`, first_pass_is_A `0`: `2`
- route `INFLOW_FROM_96-127`, k `1`, pre3 `3+,1,1`, first_pass_is_A `0`: `2`

## Feature thresholds

- `longest_k1_run_before_first_pass >= 3`: support `478`, inside A-hit rate `0.764`, outside `0.000`, difference `0.764`.
- `has_pre111_before_first_pass`: support `480`, inside A-hit rate `0.760`, outside `0.000`, difference `0.760`.
- `share_k1_before_first_pass >= 0.5`: support `463`, inside A-hit rate `0.724`, outside `0.400`, difference `0.324`.
- `first_pass_transition_k = 1`: support `517`, inside A-hit rate `0.706`, outside `0.000`, difference `0.706`.
- `first_pass_entry_route = START_IN_LAYER`: support `431`, inside A-hit rate `0.847`, outside `0.000`, difference `0.847`.

## Final descriptive answers

1. Trajectories typically wait inside `64-95` for several events before first passing: all-G1 median first-pass wait is `13.000` events and mean is `10.961`.
2. In this scanner, A is the first `64-95 -> 32-63` pass whenever it occurs: `365/365` A-hit rows have `first_A_index = first_pass_index`.
3. A-hit trajectories do not wait longer overall in this dataset: median first-pass wait is `10.000` for A-hit vs `16.000` for A-miss, and the mean is also lower for A-hit. The wait-strata table is non-monotone: A-hit rate peaks in `wait_6_10` and then drops in `wait_11_plus`.
4. A-hit rows show stronger within-layer all-1 context descriptively: higher pre111-before-pass share and longer k=1 runs than A-miss rows in the summary table.
5. A-miss first passes are recurring non-A signatures. The largest aggregate class is `INFLOW_FROM_96-127`, `transition_k=1`, `pre_k_window_3=1,1,1`, which is non-A because the entry route is not `START_IN_LAYER`; secondary A-miss classes include START_IN_LAYER passes with non-pre111 windows.
6. Waiting time alone does not describe A-hit cleanly. The waiting strata are informative, but the feature thresholds show that local features, especially pre111 and first-pass k=1 / START_IN_LAYER, carry additional separation.
7. In these observations A is best described as a within-layer first-pass signature after a wait/stay period, not an entry signature. It is one pass signature among several, with a distinctive all-1 local face.

## Output files

- `joint_wait_feature_per_trajectory.csv`
- `Ahit_vs_Amiss_wait_feature_summary.csv`
- `wait_strata_feature_table.csv`
- `first_pass_signature_counts.csv`
- `A_event_timing_summary.csv`
- `feature_threshold_Ahit_rates.csv`
