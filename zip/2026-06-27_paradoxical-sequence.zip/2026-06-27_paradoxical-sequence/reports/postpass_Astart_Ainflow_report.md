# Post-pass fate of A_start and A_inflow

Observational analysis only. Dataset and scanner mode: `original_n_strict`, same 550-trajectory universe as the previous reports.

## Verified counts

- total trajectories: `550`
- G0 never enters `64-95`: `12`
- G1 enters `64-95`: `538`
- A_start: `365`
- A_inflow: `104`
- Other_start: `66`
- Other_inflow: `3`

## Immediate downstream paths

- A_start top next-3 transition sequence: `32-63 -> 32-63 | 32-63 -> 32-63 | 32-63 -> 32-63` (365)
- A_inflow top next-3 transition sequence: `32-63 -> 32-63 | 32-63 -> 32-63 | 32-63 -> 32-63` (104)
- A_start top next-5 transition sequence: `32-63 -> 32-63 | 32-63 -> 32-63 | 32-63 -> 32-63 | 32-63 -> 32-63 | 32-63 -> 32-63` (365)
- A_inflow top next-5 transition sequence: `32-63 -> 32-63 | 32-63 -> 32-63 | 32-63 -> 32-63 | 32-63 -> 32-63 | 32-63 -> 32-63` (104)

## Downstream timing

- A_start median steps to `32-63 -> 16-31`: `23.000`, mean `22.732`.
- A_inflow median steps to `32-63 -> 16-31`: `23.000`, mean `22.875`.
- A_start median steps below 16: `30.000`; A_inflow median steps below 16: `30.000`.

## Next boundary face

- A_start top `32-63 -> 16-31` face: route `INFLOW_FROM_64-95`, k `3`, pre3 `1,1,3+` (365).
- A_inflow top `32-63 -> 16-31` face: route `INFLOW_FROM_64-95`, k `3`, pre3 `1,1,3+` (104).

## Integer-side / prefix comparison

- A_start mean/median log2(n): `10.525` / `10.771`; A_inflow: `11.459` / `11.737`.
- A_start mean/median word length: `46.189` / `46.000`; A_inflow: `55.538` / `55.000`.
- A_start share valuation prefix `1,1,1,1`: `0.055`; A_inflow: `0.048`.

## Odd-core collapse

- A_start row/distinct odd_core: `365` / `243`.
- A_inflow row/distinct odd_core: `104` / `89`.

## Final descriptive answers

1. Class counts are A_start `365`, A_inflow `104`, Other_start `66`, Other_inflow `3`.
2. A_start and A_inflow have the same immediate downstream band path at the coarse transition level: in both classes, the top next-3 and next-5 sequences are all `32-63 -> 32-63` stays and cover the full class. Their k-pattern proportions differ, so they are not identical in the word-side sequence.
3. They do not show a meaningful timing split to the next boundary in this sample: both have median 23 events to `32-63 -> 16-31` and median 30 events to below 16.
4. The next `32-63 -> 16-31` boundary is highly uniform here: every class has the same route/k/pre3 face, `INFLOW_FROM_64-95`, `transition_k=3`, `pre_k_window_3=1,1,3+`.
5. A_start and A_inflow are separated by route by definition, and also differ descriptively in integer/word size: A_inflow is larger on mean/median log2(n), word length, and total_K. Prefix shares are not sharply separated in the simple prefix coordinates.
6. Odd-core collapse does not erase the A_start/A_inflow distinction, but duplicate cores exist in both classes; class-level differences should be checked against distinct odd-core counts.
7. A_inflow is best treated as a separate pass face within the broader all-1 pass umbrella: near-A locally, not identical to A_start because its entry route and upstream provenance differ.

## Output files

- `postpass_step1_first_pass_classes.csv`
- `postpass_step2_downstream_windows.csv`
- `postpass_step2_downstream_sequence_counts.csv`
- `postpass_step3_downstream_times.csv`
- `postpass_step3_downstream_time_summary.csv`
- `postpass_step4_32_63_to_16_31_signatures.csv`
- `postpass_step4_32_63_to_16_31_signature_counts.csv`
- `postpass_step5_class_feature_summary.csv`
- `postpass_step6_odd_core_by_class.csv`
