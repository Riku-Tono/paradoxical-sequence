# Rozier A Occurrence Neighborhood Check

## Purpose

This is the ChatGPT2-style paper-side check: inspect only the exact A occurrence neighborhood, not the full biography of non-hit integers.

A event definition: `64-95 -> 32-63`, `entry_route=START_IN_LAYER`, `transition_k=1`, `pre_k_window_3=1,1,1`, all on the same occurrence.

## Counts

- `odd_core`: `377` unique integers, `377` strict A occurrences, `0` integers with multiple A occurrences.
- `odd_only`: `177` unique integers, `177` strict A occurrences, `0` integers with multiple A occurrences.
- `original_n_strict`: `365` unique integers, `365` strict A occurrences, `0` integers with multiple A occurrences.

## Position Summary

- `odd_core`: position median `11`, min `2`, max `18`, K_tau median `82`.
- `odd_only`: position median `13`, min `3`, max `18`, K_tau median `88`.
- `original_n_strict`: position median `10`, min `2`, max `19`, K_tau median `81`.

## Local Signature Sanity

- `odd_core` same-occurrence validity: `1`.
  - roll4 `1,1,1,1;1,1,1,2;1,1,2,2;1,2,2,1`: `145`
  - roll4 `1,1,1,2;1,1,2,2;1,2,2,1;3+,1,1,1`: `129`
  - roll4 `1,1,1,1;1,1,1,3+;1,1,3+,1;1,3+,1,2`: `67`
  - roll4 `1,1,1,3+;1,1,3+,1;1,3+,1,2;3+,1,1,1`: `30`
  - roll4 `1,1,1,3+;1,1,3+,1;1,3+,1,2`: `4`
  - roll4 `1,1,1,2;1,1,2,2;1,2,2,1`: `2`
- `odd_only` same-occurrence validity: `1`.
  - roll4 `1,1,1,1;1,1,1,2;1,1,2,2;1,2,2,1`: `69`
  - roll4 `1,1,1,2;1,1,2,2;1,2,2,1;3+,1,1,1`: `60`
  - roll4 `1,1,1,1;1,1,1,3+;1,1,3+,1;1,3+,1,2`: `33`
  - roll4 `1,1,1,3+;1,1,3+,1;1,3+,1,2;3+,1,1,1`: `15`
- `original_n_strict` same-occurrence validity: `1`.
  - roll4 `1,1,1,1;1,1,1,2;1,1,2,2;1,2,2,1`: `141`
  - roll4 `1,1,1,2;1,1,2,2;1,2,2,1;3+,1,1,1`: `126`
  - roll4 `1,1,1,1;1,1,1,3+;1,1,3+,1;1,3+,1,2`: `65`
  - roll4 `1,1,1,3+;1,1,3+,1;1,3+,1,2;3+,1,1,1`: `31`
  - roll4 `1,1,1,3+;1,1,3+,1;1,3+,1,2`: `1`
  - roll4 `1,1,1,3+;1,1,3+,1;1,3+,1,2;2,1,1,1`: `1`

## Reading

The strict A overlap is not produced by mixing conditions across different events: every row in the occurrence table satisfies the full same-occurrence A definition. This supports using the Rozier overlay as a narrow appendix/benchmark check, with the already-noted limits about odd-core/original-n mapping and first-hit behavior.

## Limits

- This does not claim Rozier-Terracol and the remaining_K phenomenon are the same.
- This does not claim causality.
- This is a local occurrence-neighborhood check only; non-hit taxonomy is a separate next step.
