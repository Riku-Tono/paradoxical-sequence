# Rozier Overlay Robustness Recheck

## 1. Purpose

The previous Rozier-Terracol overlay was strong enough to require a robustness audit. This report checks extraction, mapping mode, strict event definitions, counting mode, baselines, and negative controls. It does not introduce a new claim.

## 2. Extraction Audit

- Raw Appendix C occurrences: `593`.
- Distinct starting integers: `550`.
- Distinct duplicated integers: `40`.
- Odd/even split: odd `294`, even `256`.

The extraction reproduces the expected `593` occurrences and `550` distinct starting integers.

## 3. Mapping Mode Comparison

- `original_n_strict`: hits_64_95_to_32_63 `538/550` = `0.978182`; hits_start_in_layer_64_95 `431/550` = `0.783636`; hits_transition_k1_64_95 `517/550` = `0.94`; hits_pre111_64_95 `469/550` = `0.852727`; hits_full_A_signature `365/550` = `0.663636`; hits_32_63_signature `0/550` = `0`; hits_any_band_signature `472/550` = `0.858182`.
- `odd_core`: hits_64_95_to_32_63 `536/550` = `0.974545`; hits_start_in_layer_64_95 `443/550` = `0.805455`; hits_transition_k1_64_95 `516/550` = `0.938182`; hits_pre111_64_95 `468/550` = `0.850909`; hits_full_A_signature `377/550` = `0.685455`; hits_32_63_signature `0/550` = `0`; hits_any_band_signature `470/550` = `0.854545`.
- `odd_only`: hits_64_95_to_32_63 `286/294` = `0.972789`; hits_start_in_layer_64_95 `212/294` = `0.721088`; hits_transition_k1_64_95 `271/294` = `0.921769`; hits_pre111_64_95 `249/294` = `0.846939`; hits_full_A_signature `177/294` = `0.602041`; hits_32_63_signature `0/294` = `0`; hits_any_band_signature `251/294` = `0.853741`.

## 4. Strict Event Definition

- `odd_core`: loose 64-95->32-63 `536/550`, first-hit strict `7/550`, strict A-event `377/550`.
- `odd_only`: loose 64-95->32-63 `286/294`, first-hit strict `3/294`, strict A-event `177/294`.
- `original_n_strict`: loose 64-95->32-63 `538/550`, first-hit strict `5/550`, strict A-event `365/550`.

## 5. Counting Mode Comparison

- `odd_core` / `integer_level_any_A`: `377/550` = `0.685455`.
- `odd_core` / `occurrence_level_A_events_over_focus_events`: `377/18882` = `0.0199661`.
- `odd_core` / `first_64_occurrence_only`: `0/536` = `0`.
- `odd_only` / `integer_level_any_A`: `177/294` = `0.602041`.
- `odd_only` / `occurrence_level_A_events_over_focus_events`: `177/10547` = `0.016782`.
- `odd_only` / `first_64_occurrence_only`: `0/286` = `0`.
- `original_n_strict` / `integer_level_any_A`: `365/550` = `0.663636`.
- `original_n_strict` / `occurrence_level_A_events_over_focus_events`: `365/19137` = `0.019073`.
- `original_n_strict` / `first_64_occurrence_only`: `0/538` = `0`.

## 6. Baseline And Negative Controls

- baseline `all_2_to_4614` / `hits_full_A_signature`: Rozier `0.685455`, baseline `0.202905`, enrichment `3.37821`, support `4613`.
- baseline `all_2_to_4614` / `hits_any_band_signature`: Rozier `0.854545`, baseline `0.318881`, enrichment `2.67982`, support `4613`.
- baseline `same_log2_range` / `hits_full_A_signature`: Rozier `0.685455`, baseline `0.202993`, enrichment `3.37674`, support `4611`.
- baseline `same_log2_range` / `hits_any_band_signature`: Rozier `0.854545`, baseline `0.31902`, enrichment `2.67866`, support `4611`.
- baseline `random_same_count` / `hits_full_A_signature`: Rozier `0.685455`, baseline `0.218182`, enrichment `3.14167`, support `550`.
- baseline `random_same_count` / `hits_any_band_signature`: Rozier `0.854545`, baseline `0.343636`, enrichment `2.48677`, support `550`.
- baseline `random_10x` / `hits_full_A_signature`: Rozier `0.685455`, baseline `0.198909`, enrichment `3.44607`, support `5500`.
- baseline `random_10x` / `hits_any_band_signature`: Rozier `0.854545`, baseline `0.317636`, enrichment `2.69033`, support `5500`.
- baseline `random_same_count_bootstrap_100` / `hits_full_A_signature`: Rozier `0.685455`, baseline `0.205`, enrichment `3.34368`, support `55000`.
- baseline `random_same_count_bootstrap_100` / `hits_any_band_signature`: Rozier `0.854545`, baseline `0.321164`, enrichment `2.66078`, support `55000`.

- negative `consecutive_from_min` full A: `112/550` = `0.203636`.
- negative `odd_random_same_size_range` full A: `96/550` = `0.174545`.
- negative `random_same_size_range` full A: `113/550` = `0.205455`.
- negative `shift_2n_plus_1` full A: `195/550` = `0.354545`.
- negative `shift_n_minus_1` full A: `186/550` = `0.338182`.
- negative `shift_n_plus_1` full A: `184/550` = `0.334545`.

## 7. Diagnostic Examples

See `rozier_recheck_examples.csv` for representative hit and non-hit rows with exact occurrence coordinates.

## 8. Final Verdict

Verdict: `partially robust`. The strict A-event remains high under both odd-core and original-n strict mapping, and the random same-range negative control is much lower.

## 9. Interpretation Limits

- Rozier-Terracol paradoxical sequences and this remaining_K signature are defined differently.
- This is an external benchmark overlay, not proof of the same phenomenon.
- Odd-core dependence is reported explicitly rather than hidden.
- Baselines with insufficient support should not be used as claims.
- The result can support an appendix or robustness note only after the exact definitions are stated.
