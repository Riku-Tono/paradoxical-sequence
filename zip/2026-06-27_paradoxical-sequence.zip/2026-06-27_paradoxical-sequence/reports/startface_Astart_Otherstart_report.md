# A_start vs Other_start within START_IN_LAYER first-pass trajectories

Observational analysis only. Dataset and scanner mode: `original_n_strict`, same 550-trajectory universe as previous reports.

## Verified counts

- total trajectories: `550`
- G0 never enters `64-95`: `12`
- G1 enters `64-95`: `538`
- START_IN_LAYER first-pass rows: `431`
- A_start: `365`
- Other_start: `66`

## Dominant Other_start signatures

- `1 | 3+,1,1`: 28
- `5 | 2,3+,3+`: 7
- `3 | 2,2,3+`: 5
- `1 | 3+,1`: 4
- `1 | 2,3+,1`: 4
- `1 | 1,3+,1`: 3
- `1 | 1`: 2
- `1 | 3+,3+,1`: 2

Failed A-condition counts among Other_start:
- `pre_k_window_3 = 1,1,1`: 66
- `pre_k_window_5 suffix 1,1,1`: 66
- `local_window_4 contains 1,1,1,1`: 66
- `transition_k = 1`: 20

## Pre-pass history

- A_start median wait: `10.000`; Other_start median wait: `3.000`.
- A_start median longest k=1 run: `4.000`; Other_start: `2.000`.
- A_start pre111-before-pass share: `1.000`; Other_start: `0.121`.
- Other_start top last-5 k patterns: `2 | 2 | 5 | 1 | 1:8; 1 | 1 | 2 | 3 | 5:7; 2 | 2 | 2 | 2 | 3:3; 1:2; 3 | 1 | 1:2; 3 | 1:2; 5 | 1 | 1:2; 4 | 2 | 5 | 1 | 1:2`.

## Downstream

- A_start median steps to `32-63 -> 16-31`: `23.000`; Other_start: `23.000`.
- A_start top next-5 transition sequence: `32-63 -> 32-63 | 32-63 -> 32-63 | 32-63 -> 32-63 | 32-63 -> 32-63 | 32-63 -> 32-63:365`.
- Other_start top next-5 transition sequence: `32-63 -> 32-63 | 32-63 -> 32-63 | 32-63 -> 32-63 | 32-63 -> 32-63 | 32-63 -> 32-63:66`.

## Integer / odd-core

- A_start mean/median log2(n): `10.525` / `10.771`; Other_start: `10.949` / `11.197`.
- A_start row/distinct odd_core: `365` / `243`; Other_start: `66` / `46`.

## Final descriptive answers

1. Other_start is dominated by a small number of deformations from A_start, especially the route-preserving cases where the pass is START_IN_LAYER but the final k/pre3 face is not `k=1` and `pre111` together.
2. Other_start is not a completely unrelated residual, but it is more heterogeneous than A_start; the signature-count table should be used to separate the main deformations from low-count tails.
3. The dominant failed condition is listed above from `startface_step3_other_start_A_distance.csv`; in this run, failures of the pass-local all-1 context are the main separator.
4. Other_start usually lacks pre111 throughout the pre-pass window in this sample; only a small minority has pre111 earlier before losing it at pass. The history table separates never-developed, earlier-developed, and lost-before-pass cases.
5. Wait time is strongly descriptive but not sufficient alone. Other_start concentrates in short waits, while longer waits are mostly A_start; the cleanest split is wait time plus the final local k/pre3 pattern at pass.
6. Downstream behavior after entering `32-63` is broadly similar at the band level; Other_start mostly continues through the same `32-63` stay corridor and next-boundary timing is close.
7. Other_start has some integer/prefix differences from A_start, but the simple prefix/residue coordinates do not by themselves provide a clean split.
8. Other_start is best treated as a separate START_IN_LAYER pass face family, with a dominant near-A deformation plus a low-count heterogeneous tail.

## Output files

- `startface_step1_first_pass_table.csv`
- `startface_step2_other_start_signature_counts.csv`
- `startface_step3_other_start_A_distance.csv`
- `startface_step4_prepass_history.csv`
- `startface_step4_prepass_history_summary.csv`
- `startface_step5_wait_feature_interaction.csv`
- `startface_step6_downstream_comparison.csv`
- `startface_step6_downstream_summary.csv`
- `startface_step7_integer_prefix_summary.csv`
- `startface_step8_odd_core_collapse.csv`
