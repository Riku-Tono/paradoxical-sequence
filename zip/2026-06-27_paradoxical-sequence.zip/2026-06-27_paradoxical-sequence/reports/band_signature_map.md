# Band Signature Map

## Purpose

Compact observed-signature map for the paradoxical remaining_K transitions. This is a sequence-signature map, not an integer-level cause analysis.

Target transitions:

- `96-127 -> 64-95`
- `64-95 -> 32-63`
- `32-63 -> 16-31`

## Entry Route Summary

### 96-127 -> 64-95
- `ALL`: actual from `0.0186444`, iid from `0.0317038`, mass delta `-0.0130593`, actual pass `0.176505`, iid pass `0.167431`, conditional delta `0.00907383`, actual/iid pass share `1` / `1`, support `0.0503482` (ok).
- `START_IN_LAYER`: actual from `0.0186444`, iid from `0.0317038`, mass delta `-0.0130593`, actual pass `0.176505`, iid pass `0.167431`, conditional delta `0.00907383`, actual/iid pass share `1` / `1`, support `0.0503482` (ok).
- `INFLOW_FROM_128-191`: actual from `0`, iid from `0`, mass delta `0`, actual pass `nan`, iid pass `nan`, conditional delta `nan`, actual/iid pass share `0` / `0`, support `0` (low).

### 64-95 -> 32-63
- `ALL`: actual from `0.266435`, iid from `0.341662`, mass delta `-0.0752273`, actual pass `0.116249`, iid pass `0.108388`, conditional delta `0.00786124`, actual/iid pass share `1` / `1`, support `0.608096` (ok).
- `START_IN_LAYER`: actual from `0.2022`, iid from `0.239229`, mass delta `-0.0370286`, actual pass `0.136904`, iid pass `0.132609`, conditional delta `0.00429505`, actual/iid pass share `0.893751` / `0.85666`, support `0.441429` (ok).
- `INFLOW_FROM_96-127`: actual from `0.0642345`, iid from `0.102433`, mass delta `-0.0381986`, actual pass `0.0512316`, iid pass `0.0518211`, conditional delta `-0.000589567`, actual/iid pass share `0.106249` / `0.14334`, support `0.166668` (ok).

### 32-63 -> 16-31
- `ALL`: actual from `1.95953`, iid from `2.13974`, mass delta `-0.180211`, actual pass `0.106222`, iid pass `0.101604`, conditional delta `0.00461753`, actual/iid pass share `1` / `1`, support `4.09928` (ok).
- `START_IN_LAYER`: actual from `1.35184`, iid from `1.39605`, mass delta `-0.0442038`, actual pass `0.13106`, iid pass `0.129204`, conditional delta `0.00185568`, actual/iid pass share `0.851196` / `0.829665`, support `2.74789` (ok).
- `INFLOW_FROM_64-95`: actual from `0.607691`, iid from `0.743697`, mass delta `-0.136007`, actual pass `0.0509682`, iid pass `0.0497946`, conditional delta `0.00117357`, actual/iid pass share `0.148804` / `0.170335`, support `1.35139` (ok).

## Band-Specific Faces

### 96-127 -> 64-95
- ALL top signatures: local_rolling_k_window_3=1,2,2 (Δshare 0.0213656, ok); local_rolling_k_window_3=2,1,1 (Δshare 0.0185908, ok); local_rolling_k_window_4=2,1,1,1 (Δshare 0.0148242, ok)
- START_IN_LAYER top signatures: local_rolling_k_window_3=1,2,2 (Δshare 0.0213656, ok); local_rolling_k_window_3=2,1,1 (Δshare 0.0185908, ok); local_rolling_k_window_4=2,1,1,1 (Δshare 0.0148242, ok)
- INFLOW_FROM_128-191 top signatures: none
- Top joint cells: transition_k=1 & pre_k_window_3=1,1,1 & local_rolling_k_window_4=1,1,1,2 (cond Δ 0.00984782, share Δ 0.000911295, ok); transition_k=1 & pre_k_window_3=1,1,1 & local_rolling_k_window_4=1,1,1,1 (cond Δ -0.0194107, share Δ -0.00496029, ok); transition_k=1 & pre_k_window_3=1,1,1 & local_rolling_k_window_4=1,1,1,3+ (cond Δ -0.0278558, share Δ -0.00422472, ok)

### 64-95 -> 32-63
- ALL top signatures: transition_k=1 (Δshare 0.0495034, ok); pre_k_window_3=1,1,1 (Δshare 0.0339716, ok); local_rolling_k_window_3=1,1,1 (Δshare 0.0181253, ok)
- START_IN_LAYER top signatures: transition_k=1 (Δshare 0.04342, ok); pre_k_window_3=1,1,1 (Δshare 0.0238072, ok); pre_k_window_5=2,1,1,1,1 (Δshare 0.0141714, ok)
- INFLOW_FROM_96-127 top signatures: pre_k_window_3=1,1,1 (Δshare 0.133357, ok); transition_k=1 (Δshare 0.112164, ok); local_rolling_k_window_3=1,1,1 (Δshare 0.063841, ok)
- Top joint cells: transition_k=3+ & pre_k_window_3=1,2,3+ & local_rolling_k_window_4=1,2,3+,3+ (cond Δ 0.410148, share Δ 0.00431431, ok); transition_k=3+ & pre_k_window_3=1,2,3+ & local_rolling_k_window_4=2,1,2,3+ (cond Δ 0.23919, share Δ 0.00353433, ok); transition_k=3+ & pre_k_window_3=1,2,3+ & local_rolling_k_window_4=2,3+,1,1 (cond Δ 0.178485, share Δ 0.00177138, ok)

### 32-63 -> 16-31
- ALL top signatures: pre_k_window_5=1,1,1,1,2 (Δshare 0.0114368, ok); pre_k_window_3=1,1,2 (Δshare 0.00985669, ok); transition_k=2 (Δshare 0.00878829, ok)
- START_IN_LAYER top signatures: transition_k=3+ (Δshare 0.00709669, ok); pre_k_window_5=1,1,1,1,2 (Δshare 0.00562541, ok); transition_k=2 (Δshare 0.00490995, ok)
- INFLOW_FROM_64-95 top signatures: pre_k_window_3=1,1,2 (Δshare 0.0662796, ok); pre_k_window_5=1,1,1,1,2 (Δshare 0.0477051, ok); pre_k_window_5=3+,2,1,1,2 (Δshare 0.0459284, ok)
- Top joint cells: transition_k=3+ & pre_k_window_3=2,1,3+ & local_rolling_k_window_4=3+,2,1,2 (cond Δ 0.243372, share Δ 0.000582188, ok); transition_k=1 & pre_k_window_3=3+,2,1 & local_rolling_k_window_4=1,2,1,2 (cond Δ 0.235672, share Δ 0.000297246, ok); transition_k=3+ & pre_k_window_3=2,2,3+ & local_rolling_k_window_4=3+,1,3+,1 (cond Δ 0.234256, share Δ 0.000548034, ok)

## Cross-Band Comparison

- The bands do not share one identical signature. The common carrier type is conditional excess concentrated in a small number of sequence signatures under mass deficit.
- `64-95 -> 32-63` is the cleanest all-1 / `transition_k=1` face. Its readable carriers include `transition_k=1`, `pre_k_window_3=1,1,1`, and all-1 local rolling windows.
- `32-63 -> 16-31` is genuinely closer to a `transition_k=2` / `1,1,2` face in the observed map, though it also has several neighboring local signatures.
- `96-127 -> 64-95` has visible candidate signatures, but its total support is much smaller. Treat it as low-support / provisional compared with the other two bands.

## Counter-Signatures

Counter-signatures are rows where actual pass-side share is depleted relative to iid. They are classified as iid-enriched pass, actual-stay-enriched, mixed, or support artifact in `band_signature_counter_patterns.csv`.

## Limits

- Same sampled long-word / final-state-defined universe as the previous remaining_K analyses.
- Low support is marked explicitly using weighted support `< 0.002`.
- This map should not be read as a mechanism claim or an integer-level cause. It only identifies observed carriers and band-specific faces.
