# Matched-Control Analysis for 64-95 Signature

## Question

Does the sequence signature still distinguish pass from stay after controlling for integer-side shadow coordinates such as `log2(n)`, residues, parity prefixes, and valuation prefixes?

Target A is `64-95 -> 32-63`, `START_IN_LAYER`, `pass`, `transition_k=1`, `pre_k_window_3=1,1,1`.

## Method

Each match uses A as the target distribution. Within matched cells that contain all four groups, the report compares `A/(A+C)` against `B/(B+D)`, weighted by A's matched cell distribution. This controls for the selected integer-side coordinate while preserving the A/B/C/D comparison.

## Result

- `log2_floor`: signature pass rate `0.129288`, non-signature pass rate `0.135226`, delta `-0.00593811`, enrichment `0.956087`, A kept `1`, reading `weak_or_not_supported`.
- `mod16`: signature pass rate `0.125257`, non-signature pass rate `0.140704`, delta `-0.0154469`, enrichment `0.890217`, A kept `1`, reading `weak_or_not_supported`.
- `mod32`: signature pass rate `0.126624`, non-signature pass rate `0.140509`, delta `-0.0138856`, enrichment `0.901177`, A kept `1`, reading `weak_or_not_supported`.
- `mod64`: signature pass rate `0.129266`, non-signature pass rate `0.140887`, delta `-0.0116216`, enrichment `0.917511`, A kept `1`, reading `weak_or_not_supported`.
- `parity_prefix_4`: signature pass rate `0.125257`, non-signature pass rate `0.140704`, delta `-0.0154469`, enrichment `0.890217`, A kept `1`, reading `weak_or_not_supported`.
- `parity_prefix_6`: signature pass rate `0.129266`, non-signature pass rate `0.140887`, delta `-0.0116216`, enrichment `0.917511`, A kept `1`, reading `weak_or_not_supported`.
- `valuation_prefix_4_exact`: signature pass rate `0.14469`, non-signature pass rate `0.136112`, delta `0.00857756`, enrichment `1.06302`, A kept `0.973151`, reading `survives`.
- `valuation_prefix_1111_indicator`: signature pass rate `0.12259`, non-signature pass rate `0.13885`, delta `-0.0162605`, enrichment `0.882892`, A kept `1`, reading `weak_or_not_supported`.
- `log2_floor_mod32_parity4`: signature pass rate `0.149863`, non-signature pass rate `0.137334`, delta `0.0125298`, enrichment `1.09124`, A kept `0.98669`, reading `survives`.
- `log2_floor_mod32_parity6`: signature pass rate `0.170485`, non-signature pass rate `0.136106`, delta `0.034379`, enrichment `1.25259`, A kept `0.977816`, reading `survives`.
- `log2_floor_mod64_parity4`: signature pass rate `0.170485`, non-signature pass rate `0.136106`, delta `0.034379`, enrichment `1.25259`, A kept `0.977816`, reading `survives`.
- `log2_floor_mod64_parity6`: signature pass rate `0.170485`, non-signature pass rate `0.136106`, delta `0.034379`, enrichment `1.25259`, A kept `0.977816`, reading `survives`.

## Short Answer

Qualified yes. The sequence signature does not survive the simple `log2(n)`, residue, or parity-prefix controls by themselves; those matched deltas are negative. It does survive the supported combined controls using `log2(n)` plus residue plus parity prefix, and it also survives exact matching on the full length-4 valuation prefix. In this sampled matched comparison, the integer-side shadow does not fully explain the A signature, but the survival signal is joint-coordinate dependent.

## Interpretation Limits

- This is a matched descriptive check, not a causality or mechanism claim.
- Matching removes only the listed integer-side coordinates, not all possible integer structure.
- Cells with low matched A support should be treated as candidates only.
- The answer is only whether the sequence signature remains predictive after these controls.
