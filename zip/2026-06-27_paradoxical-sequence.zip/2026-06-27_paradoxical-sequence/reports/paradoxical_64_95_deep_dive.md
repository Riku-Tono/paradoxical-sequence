# Paradoxical 64-95 -> 32-63 Deep Dive

## Purpose

Focused descriptive decomposition of the cleanest paradoxical transition, `64-95 -> 32-63`. The goal is to identify which sequence-level components carry the actual conditional excess. This does not claim a mechanism.

## Entry Route Split

- `ALL`: actual from `0.266435`, iid from `0.341662`, actual pass `0.116249`, iid pass `0.108388`, conditional delta `0.00786124`, actual pass-share `1`, iid pass-share `1`, support `0.608096` (ok).
- `START_IN_LAYER`: actual from `0.2022`, iid from `0.239229`, actual pass `0.136904`, iid pass `0.132609`, conditional delta `0.00429505`, actual pass-share `0.893751`, iid pass-share `0.85666`, support `0.441429` (ok).
- `INFLOW_FROM_96-127`: actual from `0.0642345`, iid from `0.102433`, actual pass `0.0512316`, iid pass `0.0518211`, conditional delta `-0.000589567`, actual pass-share `0.106249`, iid pass-share `0.14334`, support `0.166668` (ok).

The readable component is `START_IN_LAYER`: it carries most pass mass and has positive conditional delta. `INFLOW_FROM_96-127` has substantial from-mass deficit but does not carry the conditional excess; its conditional delta is slightly negative.

## START_IN_LAYER Pass vs Stay

### transition_k
- `1`: pass-share delta `0.04342`, stay-share delta `0.00692753`, support `0.254351` (ok).
- `2`: pass-share delta `-0.0284234`, stay-share delta `0.00510226`, support `0.113542` (ok).
- `3+`: pass-share delta `-0.0149966`, stay-share delta `-0.0120298`, support `0.0735359` (ok).

### pre_k_window_3
- `1,1,1`: pass-share delta `0.0238072`, stay-share delta `-0.00887775`, support `0.0626419` (ok).
- `1,1,3+`: pass-share delta `-0.018666`, stay-share delta `-0.0017037`, support `0.0222123` (ok).
- `1,2,3+`: pass-share delta `0.0130755`, stay-share delta `-0.00407663`, support `0.00844683` (ok).
- `3+,1,1`: pass-share delta `0.00918058`, stay-share delta `-0.00464373`, support `0.01816` (ok).
- `1,3+,1`: pass-share delta `0.00894087`, stay-share delta `0.000201957`, support `0.0190802` (ok).
- `1,3+,3+`: pass-share delta `-0.00716781`, stay-share delta `-0.00157571`, support `0.00427449` (ok).
- `1,1,2`: pass-share delta `-0.00688447`, stay-share delta `0.00655227`, support `0.0321356` (ok).
- `3+,1,2`: pass-share delta `-0.00560395`, stay-share delta `0.000353926`, support `0.00770495` (ok).

### pre_k_window_5
- `2,1,1,1,1`: pass-share delta `0.0141714`, stay-share delta `0.000351609`, support `0.00760649` (ok).
- `1,1,1,1,3+`: pass-share delta `-0.0137291`, stay-share delta `-0.000118889`, support `0.00559306` (ok).
- `1,2,1,2,3+`: pass-share delta `0.0100872`, stay-share delta `-0.000318271`, support `0.00121374` (low).
- `1,1,1,3+,1`: pass-share delta `0.00879355`, stay-share delta `0.000870417`, support `0.0053057` (ok).
- `2,1,1,2,1`: pass-share delta `0.00779086`, stay-share delta `0.000752079`, support `0.00344283` (ok).
- `1,1,1,1,2`: pass-share delta `-0.00685792`, stay-share delta `-0.00215702`, support `0.00679145` (ok).
- `1,1,3+,1,3+`: pass-share delta `0.00526739`, stay-share delta `0.000518558`, support `0.00179822` (low).
- `2,2,1,1,2`: pass-share delta `0.00513624`, stay-share delta `0.00192654`, support `0.00196934` (low).

### local_rolling_k_window_3
- `1,1,1`: pass-share delta `0.0130346`, stay-share delta `-0.00246952`, support `0.139277` (ok).
- `3+,1,1`: pass-share delta `0.00876515`, stay-share delta `-0.00422182`, support `0.0659891` (ok).
- `2,2,1`: pass-share delta `-0.00685914`, stay-share delta `0.00713848`, support `0.0465799` (ok).
- `1,1,3+`: pass-share delta `-0.0057211`, stay-share delta `-0.00393961`, support `0.0728386` (ok).
- `2,3+,3+`: pass-share delta `0.00551763`, stay-share delta `-0.000499525`, support `0.00634127` (ok).
- `1,2,3+`: pass-share delta `0.00539621`, stay-share delta `-0.00311809`, support `0.0292258` (ok).
- `2,1,1`: pass-share delta `-0.00465829`, stay-share delta `0.0110073`, support `0.10195` (ok).
- `3+,1,2`: pass-share delta `-0.00456459`, stay-share delta `-0.000292381`, support `0.027188` (ok).

### local_rolling_k_window_4
- `1,1,1,1`: pass-share delta `0.0119205`, stay-share delta `-0.00315455`, support `0.0875788` (ok).
- `1,3+,1,1`: pass-share delta `0.00879601`, stay-share delta `-0.000127757`, support `0.0525039` (ok).
- `2,1,1,1`: pass-share delta `-0.00656626`, stay-share delta `0.00682705`, support `0.0732226` (ok).
- `1,3+,1,3+`: pass-share delta `0.00538168`, stay-share delta `0.00130928`, support `0.0154295` (ok).
- `1,3+,1,2`: pass-share delta `-0.00495394`, stay-share delta `-9.15703e-05`, support `0.0221066` (ok).
- `3+,1,3+,1`: pass-share delta `0.0048088`, stay-share delta `0.000469257`, support `0.0133547` (ok).
- `1,2,1,3+`: pass-share delta `0.00437747`, stay-share delta `0.00265954`, support `0.0252392` (ok).
- `3+,1,1,2`: pass-share delta `0.00425443`, stay-share delta `-0.000440891`, support `0.0223049` (ok).

## Joint Pattern Cells

- `transition_k=1 & pre_k_window_3=1,1,1`: actual pass `0.122009`, iid pass `0.0924706`, conditional delta `0.0295384`, pass share actual/iid `0.124237` / `0.10043`, stay share actual/iid `0.14181` / `0.150688`, support `0.0626419` (ok).
- `transition_k=1 & local_rolling_k_window_4=1,1,1,1`: actual pass `0.117277`, iid pass `0.0884549`, conditional delta `0.0288219`, pass share actual/iid `0.167572` / `0.133907`, stay share actual/iid `0.200066` / `0.210968`, support `0.0875788` (ok).
- `transition_k=1 & pre_k_window_5=2,1,1,1,1`: actual pass `0.196345`, iid pass `0.100363`, conditional delta `0.0959822`, pass share actual/iid `0.0264418` / `0.0122704`, stay share actual/iid `0.0171671` / `0.0168155`, support `0.00760649` (ok).

## Counter-Patterns

- `transition_k=2`: conditional delta `-0.0104762`, pass share actual/iid `0.276773` / `0.305197`, stay share actual/iid `0.254583` / `0.249481`, support `0.113542` (ok); reading: actual stay-enriched / iid pass-enriched.
- `pre_k_window_3=1,1,3+`: conditional delta `-0.0214785`, pass share actual/iid `0.0911391` / `0.109805`, stay share actual/iid `0.0414961` / `0.0431998`, support `0.0222123` (ok); reading: iid-enriched pass pattern.
- `pre_k_window_3=1,1,2`: conditional delta `-0.0178716`, pass share actual/iid `0.0792538` / `0.0861383`, stay share actual/iid `0.0747826` / `0.0682303`, support `0.0321356` (ok); reading: actual stay-enriched / iid pass-enriched.
- `local_rolling_k_window_4=2,1,1,1`: conditional delta `-0.0254796`, pass share actual/iid `0.106903` / `0.132324`, stay share actual/iid `0.183817` / `0.163784`, support `0.0732226` (ok); reading: actual stay-enriched / iid pass-enriched.

## Representative Sequences

`paradoxical_64_95_examples.csv` contains `60` selected rows across requested labels.

## Short Reading

- Conditional excess is concentrated in `START_IN_LAYER`, not in upstream inflow from `96-127`.
- Within `START_IN_LAYER`, the strongest readable positive component is `transition_k=1` together with short all-1 local context, especially `pre_k_window_3=1,1,1` and `local_rolling_k_window_4=1,1,1,1`.
- Counter-patterns are mostly the complement of that component: `transition_k=2` and `1,1,2` / `1,1,3+` are depleted on the actual pass side and are better read as iid-enriched pass or actual-stay-associated patterns, not as support artifacts.
- This supports treating `64-95 -> 32-63` as the cleanest paradoxical transition: the from-band is thin in actual, but the conditional excess has a compact sequence-level carrier.

## Limits

- Same sampled long-word / final-state-defined universe as the previous remaining_K chain analysis.
- Low support is marked explicitly in the CSVs.
- The analysis describes concentration and correspondence. It is not a mechanism claim.
