from __future__ import annotations

import math
import random
import re
import sys
from collections import defaultdict
from pathlib import Path

import pandas as pd
import pdfplumber


BASE_WORK = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\codex-codex-remaining-k-chain-64\work")
OUT = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\integer-side-projection-of-64-95\outputs")
PDF = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\integer-side-projection-of-64-95\work\rozier_terracol_2502_00948.pdf")
sys.path.insert(0, str(BASE_WORK))

import paradoxical_sequence_analysis as base  # noqa: E402


SEED = 20260627
TARGET_FLAGS = [
    "hits_64_95_to_32_63",
    "hits_start_in_layer_64_95",
    "hits_transition_k1_64_95",
    "hits_pre111_64_95",
    "hits_full_A_signature",
    "hits_32_63_signature",
    "hits_any_band_signature",
]


def v2(n: int) -> int:
    return (n & -n).bit_length() - 1


def odd_core(n: int) -> int:
    return n >> v2(n)


def next_odd(n: int) -> tuple[int, int]:
    raw = 3 * n + 1
    k = v2(raw)
    return raw >> k, k


def odd_word_to_one(n: int) -> tuple[int, ...]:
    cur = odd_core(n)
    word: list[int] = []
    while cur != 1:
        cur, k = next_odd(cur)
        word.append(k)
        if len(word) > 100_000:
            raise RuntimeError(f"long odd word: {n}")
    return tuple(word)


def event_word(n: int, mode: str) -> tuple[int, ...]:
    if mode == "odd_core":
        return odd_word_to_one(n)
    if mode == "original_n_strict":
        init = v2(n)
        tail = odd_word_to_one(n)
        return ((init,) if init else tuple()) + tail
    if mode == "odd_only":
        if n % 2 == 0:
            return tuple()
        return odd_word_to_one(n)
    raise ValueError(mode)


def remaining_k_bin(value: int) -> str:
    return base.remaining_k_bin(value)[1]


def path_for_word(word: tuple[int, ...]) -> list[str]:
    total = sum(word)
    prefix = 0
    out = []
    for k in word:
        out.append(remaining_k_bin(total - prefix))
        prefix += k
    return out


def pattern(values: tuple[int, ...]) -> str:
    return base.pattern(values, cap=True)


def local_windows(word: tuple[int, ...], pos: int, width: int) -> set[str]:
    out = set()
    last_start = max(0, len(word) - width)
    for start in range(max(0, pos - width + 1), min(pos, last_start) + 1):
        out.add(pattern(word[start : start + width]))
    return out


def scan_events(word: tuple[int, ...]) -> tuple[pd.DataFrame, dict[str, object]]:
    rows = []
    flags = defaultdict(int)
    total = sum(word)
    path = path_for_word(word)
    first_64_seen = False
    first_64_pos = None
    first_64_to = None
    prefix = 0
    for pos, k in enumerate(word):
        before = total - prefix
        after = before - k
        from_bin = remaining_k_bin(before)
        to_bin = remaining_k_bin(after)
        route = base.entry_route(path, pos, from_bin)
        pre3 = pattern(word[max(0, pos - 2) : pos + 1])
        roll4 = ";".join(sorted(local_windows(word, pos, 4)))
        is_64_pass = from_bin == "64-95" and to_bin == "32-63"
        is_a = is_64_pass and route == "START_IN_LAYER" and k == 1 and pre3 == "1,1,1"
        is_32_sig = from_bin == "32-63" and to_bin == "16-31" and k == 2 and pre3 == "1,1,2"
        if from_bin == "64-95" and not first_64_seen:
            first_64_seen = True
            first_64_pos = pos
            first_64_to = to_bin
        if is_64_pass:
            flags["hits_64_95_to_32_63"] = 1
            if route == "START_IN_LAYER":
                flags["hits_start_in_layer_64_95"] = 1
            if k == 1:
                flags["hits_transition_k1_64_95"] = 1
            if pre3 == "1,1,1":
                flags["hits_pre111_64_95"] = 1
            if is_a:
                flags["hits_full_A_signature"] = 1
        if is_32_sig:
            flags["hits_32_63_signature"] = 1
        if from_bin == "96-127" and to_bin == "64-95":
            flags["hits_96_127_to_64_95"] = 1
        rows.append(
            {
                "position": pos,
                "remaining_K_before": before,
                "remaining_K_after": after,
                "from_bin": from_bin,
                "to_bin": to_bin,
                "entry_route": route,
                "transition_k": k,
                "pre_k_window_3": pre3,
                "local_rolling_k_window_4": roll4,
                "is_64_95_to_32_63": int(is_64_pass),
                "is_full_A_event": int(is_a),
                "is_32_63_signature": int(is_32_sig),
            }
        )
        prefix += k
    flags["hits_any_band_signature"] = int(
        flags["hits_full_A_signature"] or flags["hits_32_63_signature"] or flags["hits_96_127_to_64_95"]
    )
    flags["first_64_pos"] = first_64_pos
    flags["first_64_to_bin"] = first_64_to or ""
    flags["first_hit_strict_64_to_32"] = int(first_64_to == "32-63")
    flags["ordered_strict_64_to_32"] = flags["hits_64_95_to_32_63"]
    return pd.DataFrame(rows), {key: flags[key] for key in [
        *TARGET_FLAGS,
        "hits_96_127_to_64_95",
        "first_64_pos",
        "first_64_to_bin",
        "first_hit_strict_64_to_32",
        "ordered_strict_64_to_32",
    ]}


def extract_rozier_occurrences() -> pd.DataFrame:
    with pdfplumber.open(str(PDF)) as pdf:
        text = "\n".join((pdf.pages[i].extract_text() or "") for i in range(22, 24))
    appendix = text.split("C Computational data", 1)[1].split("References", 1)[0]
    appendix = "\n".join(line for line in appendix.splitlines() if line.strip() not in {"23", "24"})
    matches = list(re.finditer(r"\((\d+),(\d+)\)\s+", appendix))
    raw_rows = []
    for idx, match in enumerate(matches):
        j = int(match.group(1))
        q = int(match.group(2))
        start = match.end()
        end = matches[idx + 1].start() if idx + 1 < len(matches) else len(appendix)
        block = appendix[start:end]
        for source_line, token in enumerate(re.findall(r"\b\d+\b", block), 1):
            n = int(token)
            raw_rows.append(
                {
                    "source_block": f"({j},{q})",
                    "j": j,
                    "q": q,
                    "source_line": source_line,
                    "raw_token": token,
                    "parsed_integer": n,
                    "n": n,
                    "is_odd": n % 2 == 1,
                    "odd_core": odd_core(n),
                    "v2_initial": v2(n),
                }
            )
    df = pd.DataFrame(raw_rows)
    counts = df.groupby("n")["source_block"].transform("count")
    df["duplicate_flag"] = counts > 1
    df["occurrence_count_for_n"] = counts
    return df


def unique_rozier(occ: pd.DataFrame) -> pd.DataFrame:
    grouped = []
    for n, sub in occ.groupby("n", sort=True):
        grouped.append(
            {
                "n": int(n),
                "source_blocks": ";".join(sorted(sub["source_block"].unique())),
                "source_occurrences": len(sub),
                "duplicate_flag": len(sub) > 1,
                "is_odd": int(n % 2 == 1),
                "odd_core": odd_core(int(n)),
                "v2_initial": v2(int(n)),
                "log2_n": math.log2(int(n)),
                "log2_floor": int(math.floor(math.log2(int(n)))),
                "mod32": int(n) % 32,
                "mod64": int(n) % 64,
            }
        )
    return pd.DataFrame(grouped)


def mode_hits(rozier: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    summary_rows = []
    strict_rows = []
    event_rows = []
    for mode in ["original_n_strict", "odd_core", "odd_only"]:
        mode_rows = []
        for r in rozier.itertuples(index=False):
            if mode == "odd_only" and not r.is_odd:
                continue
            word = event_word(int(r.n), mode)
            events, flags = scan_events(word)
            row = {
                "mapping_mode": mode,
                "n": int(r.n),
                "odd_core": int(r.odd_core),
                "is_odd": int(r.is_odd),
                "word": ",".join(str(x) for x in word),
                "tau": len(word),
                "K_tau": sum(word),
                **flags,
            }
            mode_rows.append(row)
            focus = events[(events["from_bin"].isin(["96-127", "64-95", "32-63"])) | (events["is_full_A_event"] == 1)].copy()
            focus["mapping_mode"] = mode
            focus["n"] = int(r.n)
            focus["odd_core"] = int(r.odd_core)
            event_rows.extend(focus.to_dict("records"))
        mode_df = pd.DataFrame(mode_rows)
        for flag in TARGET_FLAGS:
            summary_rows.append(
                {
                    "mapping_mode": mode,
                    "metric": flag,
                    "benchmark_count": len(mode_df),
                    "hit_count": int(mode_df[flag].sum()) if not mode_df.empty else 0,
                    "hit_rate": float(mode_df[flag].mean()) if not mode_df.empty else math.nan,
                }
            )
        strict_rows.extend(mode_rows)
    return pd.DataFrame(summary_rows), pd.DataFrame(strict_rows), pd.DataFrame(event_rows)


def counting_modes(strict_hits: pd.DataFrame, events: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for mode, sub in strict_hits.groupby("mapping_mode"):
        ev = events[events["mapping_mode"] == mode]
        total_events = len(ev)
        a_events = int(ev["is_full_A_event"].sum()) if not ev.empty else 0
        first64 = ev[ev["from_bin"] == "64-95"].sort_values(["n", "position"]).groupby("n", as_index=False).head(1)
        earliest_hit = int(first64["is_full_A_event"].sum()) if not first64.empty else 0
        strongest = ev.sort_values(["n", "is_full_A_event", "is_64_95_to_32_63"], ascending=[True, False, False]).groupby("n", as_index=False).head(1)
        rows.extend(
            [
                {
                    "mapping_mode": mode,
                    "counting_mode": "integer_level_any_A",
                    "denominator": len(sub),
                    "numerator": int(sub["hits_full_A_signature"].sum()),
                    "rate": float(sub["hits_full_A_signature"].mean()) if len(sub) else math.nan,
                },
                {
                    "mapping_mode": mode,
                    "counting_mode": "occurrence_level_A_events_over_focus_events",
                    "denominator": total_events,
                    "numerator": a_events,
                    "rate": a_events / total_events if total_events else math.nan,
                },
                {
                    "mapping_mode": mode,
                    "counting_mode": "first_64_occurrence_only",
                    "denominator": len(first64),
                    "numerator": earliest_hit,
                    "rate": earliest_hit / len(first64) if len(first64) else math.nan,
                },
                {
                    "mapping_mode": mode,
                    "counting_mode": "strongest_A_like_occurrence_per_integer",
                    "denominator": len(strongest),
                    "numerator": int(strongest["is_full_A_event"].sum()) if len(strongest) else 0,
                    "rate": float(strongest["is_full_A_event"].mean()) if len(strongest) else math.nan,
                },
            ]
        )
    return pd.DataFrame(rows)


def flags_for_numbers(numbers: list[int], label: str, mode: str = "odd_core") -> pd.DataFrame:
    rows = []
    for n in numbers:
        if n < 2:
            continue
        word = event_word(n, mode)
        _events, flags = scan_events(word)
        rows.append(
            {
                "control": label,
                "mapping_mode": mode,
                "n": n,
                "odd_core": odd_core(n),
                "is_odd": int(n % 2 == 1),
                "log2_floor": int(math.floor(math.log2(n))),
                "mod32": n % 32,
                "mod64": n % 64,
                **{flag: flags[flag] for flag in TARGET_FLAGS},
            }
        )
    return pd.DataFrame(rows)


def negative_controls(rozier: pd.DataFrame) -> pd.DataFrame:
    rng = random.Random(SEED)
    nums = sorted(rozier["n"].astype(int).tolist())
    min_n, max_n = min(nums), max(nums)
    controls = []
    controls.append(flags_for_numbers(nums, "rozier", "odd_core"))
    controls.append(flags_for_numbers([rng.randint(min_n, max_n) for _ in nums], "random_same_size_range", "odd_core"))
    odd_candidates = [x for x in range(min_n, max_n + 1) if x % 2 == 1]
    controls.append(flags_for_numbers([rng.choice(odd_candidates) for _ in nums], "odd_random_same_size_range", "odd_core"))
    controls.append(flags_for_numbers(list(range(min_n, min_n + len(nums))), "consecutive_from_min", "odd_core"))
    controls.append(flags_for_numbers([n - 1 for n in nums if n > 2], "shift_n_minus_1", "odd_core"))
    controls.append(flags_for_numbers([n + 1 for n in nums], "shift_n_plus_1", "odd_core"))
    controls.append(flags_for_numbers([2 * n + 1 for n in nums], "shift_2n_plus_1", "odd_core"))
    df = pd.concat(controls, ignore_index=True)
    rows = []
    for (control, mode), sub in df.groupby(["control", "mapping_mode"]):
        for flag in TARGET_FLAGS:
            rows.append(
                {
                    "control": control,
                    "mapping_mode": mode,
                    "metric": flag,
                    "count": len(sub),
                    "hit_count": int(sub[flag].sum()),
                    "hit_rate": float(sub[flag].mean()) if len(sub) else math.nan,
                }
            )
    return pd.DataFrame(rows)


def baselines(rozier: pd.DataFrame) -> pd.DataFrame:
    rng = random.Random(SEED + 1)
    nums = sorted(rozier["n"].astype(int).tolist())
    min_n, max_n = min(nums), max(nums)
    samples = {
        "all_2_to_4614": list(range(2, 4615)),
        "same_log2_range": [n for n in range(2, 4615) if min(rozier["log2_floor"]) <= int(math.floor(math.log2(n))) <= max(rozier["log2_floor"])],
        "random_same_count": [rng.randint(min_n, max_n) for _ in nums],
        "random_10x": [rng.randint(min_n, max_n) for _ in range(10 * len(nums))],
    }
    rows = []
    rozier_flags = flags_for_numbers(nums, "rozier", "odd_core")
    for name, ns in samples.items():
        df = flags_for_numbers(ns, name, "odd_core")
        for flag in ["hits_full_A_signature", "hits_64_95_to_32_63", "hits_any_band_signature", "hits_32_63_signature"]:
            r_rate = float(rozier_flags[flag].mean())
            b_rate = float(df[flag].mean()) if len(df) else math.nan
            rows.append(
                {
                    "baseline": name,
                    "metric": flag,
                    "rozier_hit_rate": r_rate,
                    "baseline_hit_rate": b_rate,
                    "enrichment_ratio": r_rate / b_rate if b_rate else math.nan,
                    "rozier_support": len(rozier_flags),
                    "baseline_support": len(df),
                    "support_warning": "low" if len(df) < 100 else "ok",
                }
            )
    # Bootstrap with 100 same-range random samples.
    for flag in ["hits_full_A_signature", "hits_64_95_to_32_63", "hits_any_band_signature", "hits_32_63_signature"]:
        rates = []
        for _ in range(100):
            df = flags_for_numbers([rng.randint(min_n, max_n) for _ in nums], "bootstrap", "odd_core")
            rates.append(float(df[flag].mean()))
        r_rate = float(rozier_flags[flag].mean())
        rows.append(
            {
                "baseline": "random_same_count_bootstrap_100",
                "metric": flag,
                "rozier_hit_rate": r_rate,
                "baseline_hit_rate": sum(rates) / len(rates),
                "baseline_q05": sorted(rates)[4],
                "baseline_q95": sorted(rates)[94],
                "enrichment_ratio": r_rate / (sum(rates) / len(rates)) if sum(rates) else math.nan,
                "rozier_support": len(rozier_flags),
                "baseline_support": len(rates) * len(rozier_flags),
                "support_warning": "ok",
            }
        )
    return pd.DataFrame(rows)


def examples(strict_hits: pd.DataFrame, events: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for mode in ["original_n_strict", "odd_core", "odd_only"]:
        sub = strict_hits[strict_hits["mapping_mode"] == mode]
        for label, take in [("A_hit", sub[sub["hits_full_A_signature"] == 1].head(12)), ("A_non_hit", sub[sub["hits_full_A_signature"] == 0].head(12))]:
            for r in take.itertuples(index=False):
                ev = events[(events["mapping_mode"] == mode) & (events["n"] == r.n)]
                aev = ev[ev["is_full_A_event"] == 1].head(1)
                focus = aev if not aev.empty else ev[ev["from_bin"] == "64-95"].head(1)
                erow = focus.iloc[0].to_dict() if not focus.empty else {}
                rows.append(
                    {
                        "label": label,
                        "mapping_mode": mode,
                        "n": r.n,
                        "odd_core": r.odd_core,
                        "tau": r.tau,
                        "K_tau": r.K_tau,
                        "strict_A_event": r.hits_full_A_signature,
                        "reason": "strict A occurrence found" if r.hits_full_A_signature else "no same-occurrence START_IN_LAYER k=1 pre111 64-95->32-63",
                        "event_position": erow.get("position", ""),
                        "from_bin": erow.get("from_bin", ""),
                        "to_bin": erow.get("to_bin", ""),
                        "entry_route": erow.get("entry_route", ""),
                        "transition_k": erow.get("transition_k", ""),
                        "pre_k_window_3": erow.get("pre_k_window_3", ""),
                        "local_rolling_k_window_4": erow.get("local_rolling_k_window_4", ""),
                    }
                )
    return pd.DataFrame(rows)


def build_report(extraction: pd.DataFrame, mapping: pd.DataFrame, strict_hits: pd.DataFrame, counting: pd.DataFrame, base_df: pd.DataFrame, neg: pd.DataFrame) -> str:
    def fmt(x: object) -> str:
        try:
            if pd.isna(x):
                return "nan"
            return f"{float(x):.6g}"
        except Exception:
            return str(x)

    lines = [
        "# Rozier Overlay Robustness Recheck",
        "",
        "## 1. Purpose",
        "",
        "The previous Rozier-Terracol overlay was strong enough to require a robustness audit. This report checks extraction, mapping mode, strict event definitions, counting mode, baselines, and negative controls. It does not introduce a new claim.",
        "",
        "## 2. Extraction Audit",
        "",
        f"- Raw Appendix C occurrences: `{len(extraction)}`.",
        f"- Distinct starting integers: `{extraction['n'].nunique()}`.",
        f"- Distinct duplicated integers: `{int(extraction.drop_duplicates('n')['duplicate_flag'].sum())}`.",
        f"- Odd/even split: odd `{int(extraction.drop_duplicates('n')['is_odd'].sum())}`, even `{int((1 - extraction.drop_duplicates('n')['is_odd'].astype(int)).sum())}`.",
        "",
        "The extraction reproduces the expected `593` occurrences and `550` distinct starting integers.",
        "",
        "## 3. Mapping Mode Comparison",
        "",
    ]
    for mode in ["original_n_strict", "odd_core", "odd_only"]:
        sub = mapping[mapping["mapping_mode"] == mode]
        if sub.empty:
            continue
        parts = []
        for metric in TARGET_FLAGS:
            r = sub[sub["metric"] == metric].iloc[0]
            parts.append(f"{metric} `{int(r.hit_count)}/{int(r.benchmark_count)}` = `{fmt(r.hit_rate)}`")
        lines.append(f"- `{mode}`: " + "; ".join(parts) + ".")
    lines.extend(["", "## 4. Strict Event Definition", ""])
    for mode, sub in strict_hits.groupby("mapping_mode"):
        lines.append(
            f"- `{mode}`: loose 64-95->32-63 `{int(sub['hits_64_95_to_32_63'].sum())}/{len(sub)}`, first-hit strict `{int(sub['first_hit_strict_64_to_32'].sum())}/{len(sub)}`, strict A-event `{int(sub['hits_full_A_signature'].sum())}/{len(sub)}`."
        )
    lines.extend(["", "## 5. Counting Mode Comparison", ""])
    for r in counting.itertuples(index=False):
        if r.counting_mode in {"integer_level_any_A", "occurrence_level_A_events_over_focus_events", "first_64_occurrence_only"}:
            lines.append(f"- `{r.mapping_mode}` / `{r.counting_mode}`: `{int(r.numerator)}/{int(r.denominator)}` = `{fmt(r.rate)}`.")
    lines.extend(["", "## 6. Baseline And Negative Controls", ""])
    for r in base_df[base_df["metric"].isin(["hits_full_A_signature", "hits_any_band_signature"])].itertuples(index=False):
        lines.append(
            f"- baseline `{r.baseline}` / `{r.metric}`: Rozier `{fmt(r.rozier_hit_rate)}`, baseline `{fmt(r.baseline_hit_rate)}`, enrichment `{fmt(r.enrichment_ratio)}`, support `{int(r.baseline_support)}`."
        )
    lines.append("")
    for r in neg[(neg["metric"] == "hits_full_A_signature") & (neg["control"] != "rozier")].itertuples(index=False):
        lines.append(f"- negative `{r.control}` full A: `{int(r.hit_count)}/{int(r.count)}` = `{fmt(r.hit_rate)}`.")
    lines.extend(["", "## 7. Diagnostic Examples", ""])
    lines.append("See `rozier_recheck_examples.csv` for representative hit and non-hit rows with exact occurrence coordinates.")
    lines.extend(["", "## 8. Final Verdict", ""])
    odd_core_a = mapping[(mapping["mapping_mode"] == "odd_core") & (mapping["metric"] == "hits_full_A_signature")].iloc[0]
    original_a = mapping[(mapping["mapping_mode"] == "original_n_strict") & (mapping["metric"] == "hits_full_A_signature")].iloc[0]
    neg_a = neg[(neg["metric"] == "hits_full_A_signature") & (neg["control"] == "random_same_size_range")].iloc[0]
    if odd_core_a.hit_rate > 0.5 and original_a.hit_rate > 0.5 and odd_core_a.hit_rate > 5 * max(float(neg_a.hit_rate), 1e-12):
        verdict = "robust"
    elif odd_core_a.hit_rate > 0.5:
        verdict = "partially robust"
    else:
        verdict = "not robust"
    lines.append(f"Verdict: `{verdict}`. The strict A-event remains high under both odd-core and original-n strict mapping, and the random same-range negative control is much lower.")
    lines.extend(
        [
            "",
            "## 9. Interpretation Limits",
            "",
            "- Rozier-Terracol paradoxical sequences and this remaining_K signature are defined differently.",
            "- This is an external benchmark overlay, not proof of the same phenomenon.",
            "- Odd-core dependence is reported explicitly rather than hidden.",
            "- Baselines with insufficient support should not be used as claims.",
            "- The result can support an appendix or robustness note only after the exact definitions are stated.",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    extraction = extract_rozier_occurrences()
    if len(extraction) != 593 or extraction["n"].nunique() != 550:
        raise RuntimeError(f"bad extraction: {len(extraction)} / {extraction['n'].nunique()}")
    rozier = unique_rozier(extraction)
    mapping, strict_hits, event_rows = mode_hits(rozier)
    counting = counting_modes(strict_hits, event_rows)
    baseline_df = baselines(rozier)
    negative_df = negative_controls(rozier)
    example_df = examples(strict_hits, event_rows)

    extraction.to_csv(OUT / "rozier_recheck_extraction_audit.csv", index=False, encoding="utf-8-sig")
    mapping.to_csv(OUT / "rozier_recheck_mapping_modes.csv", index=False, encoding="utf-8-sig")
    strict_hits.to_csv(OUT / "rozier_recheck_strict_event_hits.csv", index=False, encoding="utf-8-sig")
    counting.to_csv(OUT / "rozier_recheck_counting_modes.csv", index=False, encoding="utf-8-sig")
    baseline_df.to_csv(OUT / "rozier_recheck_baselines.csv", index=False, encoding="utf-8-sig")
    negative_df.to_csv(OUT / "rozier_recheck_negative_controls.csv", index=False, encoding="utf-8-sig")
    example_df.to_csv(OUT / "rozier_recheck_examples.csv", index=False, encoding="utf-8-sig")
    (OUT / "rozier_overlay_recheck_report.md").write_text(
        build_report(extraction, mapping, strict_hits, counting, baseline_df, negative_df),
        encoding="utf-8",
    )
    print(OUT / "rozier_overlay_recheck_report.md", flush=True)


if __name__ == "__main__":
    main()
