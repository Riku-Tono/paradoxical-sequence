from __future__ import annotations

import math
import random
import sys
from collections import defaultdict
from pathlib import Path

import pandas as pd


BASE_WORK = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\codex-codex-remaining-k-chain-64\work")
OUT = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\integer-side-projection-of-64-95\outputs")
sys.path.insert(0, str(BASE_WORK))

import paradoxical_sequence_analysis as base  # noqa: E402


FROM_BIN = "64-95"
TO_BIN = "32-63"
TRANSITION = f"{FROM_BIN} -> {TO_BIN}"
POWERS = [24, 25, 26, 27, 28]
HS = [2, 3, 4, 5, 6]
ACTUAL_SAMPLE_PER_PH = 20_000
SEED = 20260625


def parity_prefix_from_word(word: tuple[int, ...], length: int) -> str:
    bits: list[str] = []
    for k in word:
        bits.append("1")
        bits.extend("0" for _ in range(max(0, k - 1)))
        if len(bits) >= length:
            break
    return "".join(bits[:length]).ljust(length, "E")


def valuation_prefix(word: tuple[int, ...], length: int) -> str:
    return ",".join(str(k) for k in word[:length])


def group_label(group: str, signature: bool) -> str:
    if group == "pass" and signature:
        return "A_signature_pass"
    if group == "pass":
        return "B_non_signature_pass"
    if group == "stay" and signature:
        return "C_signature_stay"
    return "D_non_signature_stay"


def occurrence_rows_for_n(n: int, power: int, h: int, weight: float, word: tuple[int, ...]) -> list[dict[str, object]]:
    info = base.state_info(word, power, h)
    if info is None:
        return []
    path = base.bin_path(word)
    total_k = sum(word)
    prefix_k = 0
    rows: list[dict[str, object]] = []
    for pos, k in enumerate(word):
        _from_idx, from_bin = base.remaining_k_bin(total_k - prefix_k)
        _to_idx, to_bin = base.remaining_k_bin(total_k - prefix_k - k)
        if from_bin != FROM_BIN:
            prefix_k += k
            continue
        group = "pass" if to_bin == TO_BIN else ("stay" if to_bin == FROM_BIN else "other")
        if group == "other":
            prefix_k += k
            continue
        route = base.entry_route(path, pos, FROM_BIN)
        if route != "START_IN_LAYER":
            prefix_k += k
            continue
        pre3 = base.pattern(word[max(0, pos - 2) : pos + 1], cap=True)
        signature = k == 1 and pre3 == "1,1,1"
        log2_n = math.log2(n)
        row = {
            "group": group_label(group, signature),
            "is_signature": int(signature),
            "is_pass": int(group == "pass"),
            "n": n,
            "power": power,
            "h": h,
            "weight": weight,
            "position": pos,
            "transition_k": k,
            "pre_k_window_3": pre3,
            "log2_n": log2_n,
            "log2_floor": int(math.floor(log2_n)),
            "log2_half": math.floor(log2_n * 2) / 2,
            "n_bucket": f"p{power}_h{h}_bits{power-h}",
            "mod16": n % 16,
            "mod32": n % 32,
            "mod64": n % 64,
            "parity_prefix_4": parity_prefix_from_word(word, 4),
            "parity_prefix_6": parity_prefix_from_word(word, 6),
            "valuation_prefix_4": valuation_prefix(word, 4),
            "valuation_prefix_is_1111": int(valuation_prefix(word, 4) == "1,1,1,1"),
            "word_prefix_12": valuation_prefix(word, 12),
        }
        rows.append(row)
        prefix_k += k
    return rows


MATCH_SPECS: list[tuple[str, list[str]]] = [
    ("log2_floor", ["log2_floor"]),
    ("log2_half", ["log2_half"]),
    ("n_bucket", ["n_bucket"]),
    ("mod16", ["mod16"]),
    ("mod32", ["mod32"]),
    ("mod64", ["mod64"]),
    ("parity_prefix_4", ["parity_prefix_4"]),
    ("parity_prefix_6", ["parity_prefix_6"]),
    ("valuation_prefix_4_exact", ["valuation_prefix_4"]),
    ("valuation_prefix_1111_indicator", ["valuation_prefix_is_1111"]),
    ("log2_floor_mod32_parity4", ["log2_floor", "mod32", "parity_prefix_4"]),
    ("log2_floor_mod32_parity6", ["log2_floor", "mod32", "parity_prefix_6"]),
    ("log2_floor_mod64_parity4", ["log2_floor", "mod64", "parity_prefix_4"]),
    ("log2_floor_mod64_parity6", ["log2_floor", "mod64", "parity_prefix_6"]),
    ("n_bucket_mod32_parity4", ["n_bucket", "mod32", "parity_prefix_4"]),
    ("n_bucket_mod64_parity4", ["n_bucket", "mod64", "parity_prefix_4"]),
]


def cell_key_frame(data: pd.DataFrame, columns: list[str]) -> pd.Series:
    if len(columns) == 1:
        return data[columns[0]].astype(str)
    return data[columns].astype(str).agg("|".join, axis=1)


def matched_summary(data: pd.DataFrame, match_name: str, columns: list[str]) -> tuple[dict[str, object], pd.DataFrame]:
    work = data.copy()
    work["match_cell"] = cell_key_frame(work, columns)
    pivot = work.pivot_table(index="match_cell", columns="group", values="weight", aggfunc="sum", fill_value=0.0)
    counts = work.pivot_table(index="match_cell", columns="group", values="n", aggfunc="count", fill_value=0)
    for group in ["A_signature_pass", "B_non_signature_pass", "C_signature_stay", "D_non_signature_stay"]:
        if group not in pivot:
            pivot[group] = 0.0
        if group not in counts:
            counts[group] = 0
    has_a = pivot["A_signature_pass"] > 0
    common = has_a & (pivot["C_signature_stay"] > 0) & (pivot["B_non_signature_pass"] > 0) & (pivot["D_non_signature_stay"] > 0)
    common_pivot = pivot[common].copy()
    common_counts = counts.loc[common].copy()
    total_a = pivot["A_signature_pass"].sum()
    kept_a = common_pivot["A_signature_pass"].sum()
    if common_pivot.empty or kept_a == 0:
        row = {
            "match_name": match_name,
            "match_columns": ",".join(columns),
            "cell_count": int(len(pivot)),
            "common_cell_count": 0,
            "A_support_total": total_a,
            "A_support_kept": 0.0,
            "A_kept_share": 0.0,
            "signature_pass_rate_matched": math.nan,
            "non_signature_pass_rate_matched": math.nan,
            "conditional_delta_after_matching": math.nan,
            "enrichment_ratio": math.nan,
            "predictive_reading": "insufficient_common_support",
        }
        return row, pd.DataFrame()

    a_cell_share = common_pivot["A_signature_pass"] / kept_a
    sig_rate_by_cell = common_pivot["A_signature_pass"] / (common_pivot["A_signature_pass"] + common_pivot["C_signature_stay"])
    nonsig_rate_by_cell = common_pivot["B_non_signature_pass"] / (common_pivot["B_non_signature_pass"] + common_pivot["D_non_signature_stay"])
    sig_rate = float((a_cell_share * sig_rate_by_cell).sum())
    nonsig_rate = float((a_cell_share * nonsig_rate_by_cell).sum())
    delta = sig_rate - nonsig_rate
    enrichment = sig_rate / nonsig_rate if nonsig_rate else math.nan
    reading = "survives" if delta > 0 and enrichment > 1 and kept_a / total_a >= 0.25 else "weak_or_not_supported"
    if kept_a / total_a < 0.25:
        reading = "low_matched_A_support"
    summary = {
        "match_name": match_name,
        "match_columns": ",".join(columns),
        "cell_count": int(len(pivot)),
        "common_cell_count": int(common.sum()),
        "A_support_total": total_a,
        "A_support_kept": kept_a,
        "A_kept_share": kept_a / total_a if total_a else math.nan,
        "signature_pass_rate_matched": sig_rate,
        "non_signature_pass_rate_matched": nonsig_rate,
        "conditional_delta_after_matching": delta,
        "enrichment_ratio": enrichment,
        "matched_A_occurrences": int(common_counts["A_signature_pass"].sum()),
        "matched_C_occurrences": int(common_counts["C_signature_stay"].sum()),
        "matched_B_occurrences": int(common_counts["B_non_signature_pass"].sum()),
        "matched_D_occurrences": int(common_counts["D_non_signature_stay"].sum()),
        "matched_A_support": float(common_pivot["A_signature_pass"].sum()),
        "matched_C_support": float(common_pivot["C_signature_stay"].sum()),
        "matched_B_support": float(common_pivot["B_non_signature_pass"].sum()),
        "matched_D_support": float(common_pivot["D_non_signature_stay"].sum()),
        "predictive_reading": reading,
    }
    cell_rows = common_pivot.reset_index()
    cell_rows["match_name"] = match_name
    cell_rows["match_columns"] = ",".join(columns)
    cell_rows["A_cell_share_in_matched_A"] = cell_rows["A_signature_pass"] / kept_a
    cell_rows["signature_pass_rate_cell"] = cell_rows["A_signature_pass"] / (
        cell_rows["A_signature_pass"] + cell_rows["C_signature_stay"]
    )
    cell_rows["non_signature_pass_rate_cell"] = cell_rows["B_non_signature_pass"] / (
        cell_rows["B_non_signature_pass"] + cell_rows["D_non_signature_stay"]
    )
    cell_rows["cell_delta"] = cell_rows["signature_pass_rate_cell"] - cell_rows["non_signature_pass_rate_cell"]
    cell_rows["cell_enrichment"] = cell_rows["signature_pass_rate_cell"] / cell_rows["non_signature_pass_rate_cell"].replace(0, math.nan)
    for group in ["A_signature_pass", "B_non_signature_pass", "C_signature_stay", "D_non_signature_stay"]:
        cell_rows[f"{group}_occurrences"] = common_counts[group].to_numpy()
    return summary, cell_rows


def build_report(summary: pd.DataFrame) -> str:
    def fmt(x: object) -> str:
        try:
            if pd.isna(x):
                return "nan"
            return f"{float(x):.6g}"
        except Exception:
            return str(x)

    lines = [
        "# Matched-Control Analysis for 64-95 Signature",
        "",
        "## Question",
        "",
        "Does the sequence signature still distinguish pass from stay after controlling for integer-side shadow coordinates such as `log2(n)`, residues, parity prefixes, and valuation prefixes?",
        "",
        "Target A is `64-95 -> 32-63`, `START_IN_LAYER`, `pass`, `transition_k=1`, `pre_k_window_3=1,1,1`.",
        "",
        "## Method",
        "",
        "Each match uses A as the target distribution. Within matched cells that contain all four groups, the report compares `A/(A+C)` against `B/(B+D)`, weighted by A's matched cell distribution. This controls for the selected integer-side coordinate while preserving the A/B/C/D comparison.",
        "",
        "## Result",
        "",
    ]
    preferred = [
        "log2_floor",
        "mod16",
        "mod32",
        "mod64",
        "parity_prefix_4",
        "parity_prefix_6",
        "valuation_prefix_4_exact",
        "valuation_prefix_1111_indicator",
        "log2_floor_mod32_parity4",
        "log2_floor_mod32_parity6",
        "log2_floor_mod64_parity4",
        "log2_floor_mod64_parity6",
    ]
    for name in preferred:
        sub = summary[summary["match_name"] == name]
        if sub.empty:
            continue
        r = sub.iloc[0]
        lines.append(
            f"- `{name}`: signature pass rate `{fmt(r.signature_pass_rate_matched)}`, non-signature pass rate `{fmt(r.non_signature_pass_rate_matched)}`, delta `{fmt(r.conditional_delta_after_matching)}`, enrichment `{fmt(r.enrichment_ratio)}`, A kept `{fmt(r.A_kept_share)}`, reading `{r.predictive_reading}`."
        )
    robust = summary[(summary["conditional_delta_after_matching"] > 0) & (summary["enrichment_ratio"] > 1) & (summary["A_kept_share"] >= 0.25)]
    combined = summary[summary["match_name"].str.contains("log2|n_bucket", regex=True) & summary["match_name"].str.contains("mod", regex=False) & summary["match_name"].str.contains("parity", regex=False)]
    robust_combined = combined[
        (combined["conditional_delta_after_matching"] > 0)
        & (combined["enrichment_ratio"] > 1)
        & (combined["A_kept_share"] >= 0.25)
    ]
    simple = summary[~summary["match_name"].str.contains("log2_floor_mod|n_bucket_mod", regex=True)]
    robust_simple = simple[
        (simple["conditional_delta_after_matching"] > 0)
        & (simple["enrichment_ratio"] > 1)
        & (simple["A_kept_share"] >= 0.25)
    ]
    lines.extend(["", "## Short Answer", ""])
    shadow_simple_names = {
        "log2_floor",
        "log2_half",
        "n_bucket",
        "mod16",
        "mod32",
        "mod64",
        "parity_prefix_4",
        "parity_prefix_6",
        "valuation_prefix_1111_indicator",
    }
    shadow_simple = summary[summary["match_name"].isin(shadow_simple_names)]
    shadow_simple_has_negative = bool((shadow_simple["conditional_delta_after_matching"] <= 0).any())
    if not robust_combined.empty and shadow_simple_has_negative:
        lines.append(
            "Qualified yes. The sequence signature does not survive the simple `log2(n)`, residue, or parity-prefix controls by themselves; those matched deltas are negative. It does survive the supported combined controls using `log2(n)` plus residue plus parity prefix, and it also survives exact matching on the full length-4 valuation prefix. In this sampled matched comparison, the integer-side shadow does not fully explain the A signature, but the survival signal is joint-coordinate dependent."
        )
    elif len(robust) >= 3:
        lines.append(
            "Yes. In this sampled occurrence-weighted projection, the sequence signature survives the main matched controls: after matching on integer-side shadow coordinates, `A/(A+C)` remains above `B/(B+D)` in the supported controls."
        )
    elif not robust.empty:
        lines.append(
            "Weak yes. The signature survives some supported matched controls, but the conclusion should be read as provisional because support or consistency is limited."
        )
    else:
        lines.append(
            "No supported survival signal is visible under these matched controls. The integer-side shadow appears sufficient for this sampled comparison."
        )
    lines.extend(
        [
            "",
            "## Interpretation Limits",
            "",
            "- This is a matched descriptive check, not a causality or mechanism claim.",
            "- Matching removes only the listed integer-side coordinates, not all possible integer structure.",
            "- Cells with low matched A support should be treated as candidates only.",
            "- The answer is only whether the sequence signature remains predictive after these controls.",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    module = base.load_source()
    rng = random.Random(SEED)
    tau_cuts: dict[int, tuple[int, int]] = {}
    rows: list[dict[str, object]] = []

    print("sampling iid for tau cuts", flush=True)
    for h in HS:
        sampled = base.sample_iid(module, h, rng)
        tau_cuts[h] = base.weighted_tau_cuts(sampled)
        print(f"tau cuts h={h}: {tau_cuts[h]}", flush=True)

    print("sampling actual integer occurrences", flush=True)
    for power in POWERS:
        status = base.load_status(power)
        for h in HS:
            _cut1, cut2 = tau_cuts[h]
            lo, _hi, total = module.layer_bounds(power, h)
            escape_indices = [idx for idx in range(lo >> 1, ((_hi >> 1) + 1)) if status[idx] == module.ESCAPE]
            chosen = base.evenly_spaced(escape_indices, ACTUAL_SAMPLE_PER_PH)
            sample_weight = len(escape_indices) / (len(chosen) * total) if chosen else 0.0
            for idx in chosen:
                n = 2 * idx + 1
                word = module.trace_escape(n, 1 << power)
                if len(word) <= cut2:
                    continue
                rows.extend(occurrence_rows_for_n(n, power, h, sample_weight, word))
            print(f"actual power={power} h={h} rows={len(rows)}", flush=True)
        del status

    data = pd.DataFrame(rows)
    if data.empty:
        raise RuntimeError("no occurrence rows")

    summary_rows = []
    cell_frames = []
    for match_name, columns in MATCH_SPECS:
        row, cells = matched_summary(data, match_name, columns)
        summary_rows.append(row)
        if not cells.empty:
            cell_frames.append(cells)
    summary = pd.DataFrame(summary_rows)
    cells = pd.concat(cell_frames, ignore_index=True) if cell_frames else pd.DataFrame()
    summary.to_csv(OUT / "integer_signature_64_95_matched_control.csv", index=False, encoding="utf-8-sig")
    cells.to_csv(OUT / "integer_signature_64_95_matched_cells.csv", index=False, encoding="utf-8-sig")
    (OUT / "integer_signature_64_95_matched_control.md").write_text(build_report(summary), encoding="utf-8")
    print(OUT / "integer_signature_64_95_matched_control.md", flush=True)


if __name__ == "__main__":
    main()
