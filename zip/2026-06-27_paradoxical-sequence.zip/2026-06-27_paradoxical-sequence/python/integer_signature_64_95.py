from __future__ import annotations

import math
import random
import sys
from collections import defaultdict
from pathlib import Path

import pandas as pd


BASE_WORK = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\codex-codex-remaining-k-chain-64\work")
OUT = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\integer-side-projection-of-64-95\outputs")
sys.path.insert(0, str(BASE_WORK))

import paradoxical_sequence_analysis as base  # noqa: E402


FROM_BIN = "64-95"
TO_BIN = "32-63"
TRANSITION = f"{FROM_BIN} -> {TO_BIN}"
POWERS = [24, 25, 26, 27, 28]
HS = [2, 3, 4, 5, 6]
IID_SAMPLES_PER_H = 160_000
ACTUAL_SAMPLE_PER_PH = 20_000
SEED = 20260625
MODULI = [3, 4, 8, 16, 32, 64, 128, 256, 6, 12, 24, 48, 96, 192, 384, 768, 5, 7, 9]
PREFIX_LENS = [4, 6, 8, 10, 12]


def v2(n: int) -> int:
    return (n & -n).bit_length() - 1


def group_label(group: str, signature: bool) -> str:
    if group == "pass" and signature:
        return "A_signature_pass"
    if group == "pass":
        return "B_non_signature_pass"
    if group == "stay" and signature:
        return "C_signature_stay"
    return "D_non_signature_stay"


def parity_prefix_from_word(word: tuple[int, ...], length: int) -> str:
    bits: list[str] = []
    for k in word:
        bits.append("1")
        bits.extend("0" for _ in range(max(0, k - 1)))
        if len(bits) >= length:
            break
    return "".join(bits[:length]).ljust(length, "E")


def word_prefix(word: tuple[int, ...], length: int) -> str:
    return ",".join(str(k) for k in word[:length])


def trace_scale(n: int, n_max: int) -> dict[str, float | int | str]:
    cur = n
    max_value = n
    first_peak_time = 0
    stopping_time = math.nan
    total_stopping_time = math.nan
    steps = 0
    odd_steps = 0
    v_prefix: list[int] = []
    while cur != 1 and steps < 100_000:
        if cur % 2 == 0:
            cur //= 2
            steps += 1
        else:
            raw = 3 * cur + 1
            k = v2(raw)
            if len(v_prefix) < 12:
                v_prefix.append(k)
            cur = raw
            odd_steps += 1
            steps += 1
        if cur > max_value:
            max_value = cur
            first_peak_time = steps
        if math.isnan(stopping_time) and cur < n:
            stopping_time = steps
    if cur == 1:
        total_stopping_time = steps
    return {
        "stopping_time": stopping_time,
        "total_stopping_time": total_stopping_time,
        "escape_length": odd_steps,
        "max_trajectory_value": max_value,
        "log_max_over_log_n": math.log(max_value) / math.log(n) if n > 1 else math.nan,
        "first_peak_time": first_peak_time,
        "valuation_prefix_12": ",".join(str(k) for k in v_prefix),
    }


def occurrence_rows_for_n(n: int, power: int, h: int, weight: float, word: tuple[int, ...]) -> list[dict[str, object]]:
    info = base.state_info(word, power, h)
    if info is None:
        return []
    state, bridge, window, parity = info
    path = base.bin_path(word)
    total_k = sum(word)
    prefix_k = 0
    scale = trace_scale(n, 1 << power)
    rows: list[dict[str, object]] = []
    for pos, k in enumerate(word):
        _from_idx, from_bin = base.remaining_k_bin(total_k - prefix_k)
        _to_idx, to_bin = base.remaining_k_bin(total_k - prefix_k - k)
        if from_bin != FROM_BIN:
            prefix_k += k
            continue
        group = "pass" if to_bin == TO_BIN else ("stay" if to_bin == FROM_BIN else "other")
        if group == "other":
            prefix_k += k
            continue
        route = base.entry_route(path, pos, FROM_BIN)
        if route != "START_IN_LAYER":
            prefix_k += k
            continue
        pre3 = base.pattern(word[max(0, pos - 2) : pos + 1], cap=True)
        pre5 = base.pattern(word[max(0, pos - 4) : pos + 1], cap=True)
        signature = k == 1 and pre3 == "1,1,1"
        label = group_label(group, signature)
        prior_cum_k = sum(word[:pos])
        near = word[max(0, pos - 4) : min(len(word), pos + 5)]
        row = {
            "source": "actual",
            "analysis_unit": "occurrence_weighted_integer_projection",
            "group_id": label[0],
            "group": label,
            "transition": TRANSITION if group == "pass" else "",
            "from_bin": FROM_BIN,
            "entry_route": route,
            "n": n,
            "power": power,
            "h": h,
            "weight": weight,
            "position": pos,
            "tau": len(word),
            "K_tau": total_k,
            "remaining_K": total_k - prefix_k,
            "remaining_K_after": total_k - prefix_k - k,
            "transition_k": k,
            "pre_k_window_3": pre3,
            "pre_k_window_5": pre5,
            "local_rolling_k_window_4": ";".join(
                sorted(
                    {
                        base.pattern(word[start : start + 4], cap=True)
                        for start in range(max(0, pos - 3), min(pos, max(0, len(word) - 4)) + 1)
                    }
                )
            ),
            "cumulative_k_before_transition": prior_cum_k,
            "valuation_near_transition": ",".join(str(x) for x in near),
            "log2_n": math.log2(n),
            "n_bucket": f"p{power}_h{h}_bits{power-h}",
            "v2_n": v2(n),
            "v2_3n_plus_1": v2(3 * n + 1),
            "x_K": total_k - (power - h),
            "focus_state": state,
            "bridge": bridge,
            "xk_window": window,
            "parity": parity,
            "word_prefix_12": word_prefix(word, 12),
            "word": ",".join(str(x) for x in word),
            **scale,
        }
        rows.append(row)
        prefix_k += k
    return rows


def weighted_quantile(values: pd.Series, weights: pd.Series, q: float) -> float:
    if values.empty:
        return math.nan
    df = pd.DataFrame({"value": values.astype(float), "weight": weights.astype(float)}).dropna().sort_values("value")
    if df.empty or df["weight"].sum() == 0:
        return math.nan
    cutoff = q * df["weight"].sum()
    return float(df.loc[df["weight"].cumsum() >= cutoff, "value"].iloc[0])


def weighted_mean(values: pd.Series, weights: pd.Series) -> float:
    df = pd.DataFrame({"value": values.astype(float), "weight": weights.astype(float)}).dropna()
    return float((df["value"] * df["weight"]).sum() / df["weight"].sum()) if not df.empty and df["weight"].sum() else math.nan


def group_summary(rows: pd.DataFrame) -> pd.DataFrame:
    out = []
    total_weight = rows["weight"].sum()
    for group, sub in rows.groupby("group", sort=True):
        log2 = sub["log2_n"]
        w = sub["weight"]
        q33 = weighted_quantile(log2, w, 1 / 3)
        q66 = weighted_quantile(log2, w, 2 / 3)
        out.append(
            {
                "group": group,
                "occurrence_count": len(sub),
                "unique_n": sub["n"].nunique(),
                "weighted_support": w.sum(),
                "mass_share": w.sum() / total_weight if total_weight else math.nan,
                "mean_log2_n": weighted_mean(log2, w),
                "median_log2_n": weighted_quantile(log2, w, 0.5),
                "q10_log2_n": weighted_quantile(log2, w, 0.1),
                "q25_log2_n": weighted_quantile(log2, w, 0.25),
                "q75_log2_n": weighted_quantile(log2, w, 0.75),
                "q90_log2_n": weighted_quantile(log2, w, 0.9),
                "lower_range_share": sub.loc[log2 <= q33, "weight"].sum() / w.sum() if w.sum() else math.nan,
                "middle_range_share": sub.loc[(log2 > q33) & (log2 <= q66), "weight"].sum() / w.sum() if w.sum() else math.nan,
                "upper_range_share": sub.loc[log2 > q66, "weight"].sum() / w.sum() if w.sum() else math.nan,
                "top_n_buckets": ";".join(
                    f"{idx}:{val:.6g}"
                    for idx, val in (sub.groupby("n_bucket")["weight"].sum() / w.sum()).sort_values(ascending=False).head(8).items()
                ),
                "support_note": "low" if len(sub) < 30 or w.sum() < 0.002 else "ok",
            }
        )
    return pd.DataFrame(out)


def categorical_share(rows: pd.DataFrame, column: str, label_column: str = "value") -> pd.DataFrame:
    totals = rows.groupby("group")["weight"].sum().to_dict()
    records = []
    for (group, value), sub in rows.groupby(["group", column], dropna=False):
        support = sub["weight"].sum()
        records.append(
            {
                "coordinate": column,
                "group": group,
                label_column: value,
                "occurrence_count": len(sub),
                "unique_n": sub["n"].nunique(),
                "weighted_support": support,
                "share": support / totals[group] if totals.get(group) else math.nan,
                "support_note": "low" if len(sub) < 15 or support < 0.001 else "ok",
            }
        )
    return pd.DataFrame(records)


def comparison_rows(share_df: pd.DataFrame, value_col: str) -> pd.DataFrame:
    piv = share_df.pivot_table(index=["coordinate", value_col], columns="group", values="share", aggfunc="sum").reset_index()
    for group in ["A_signature_pass", "B_non_signature_pass", "C_signature_stay", "D_non_signature_stay"]:
        if group not in piv:
            piv[group] = 0.0
    for other in ["B_non_signature_pass", "C_signature_stay", "D_non_signature_stay"]:
        piv[f"A_vs_{other}_delta_share"] = piv["A_signature_pass"] - piv[other]
        piv[f"A_vs_{other}_enrichment"] = piv["A_signature_pass"] / piv[other].replace(0, math.nan)
    return piv


def numeric_coord_summary(rows: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    records = []
    for col in columns:
        for group, sub in rows.groupby("group"):
            vals = pd.to_numeric(sub[col], errors="coerce")
            w = sub["weight"]
            records.append(
                {
                    "coordinate": col,
                    "group": group,
                    "occurrence_count": vals.notna().sum(),
                    "weighted_support": sub.loc[vals.notna(), "weight"].sum(),
                    "mean": weighted_mean(vals, w),
                    "median": weighted_quantile(vals, w, 0.5),
                    "q10": weighted_quantile(vals, w, 0.1),
                    "q25": weighted_quantile(vals, w, 0.25),
                    "q75": weighted_quantile(vals, w, 0.75),
                    "q90": weighted_quantile(vals, w, 0.9),
                    "support_note": "low" if vals.notna().sum() < 30 else "ok",
                }
            )
    return pd.DataFrame(records)


def build_report(groups: pd.DataFrame, residue: pd.DataFrame, prefix: pd.DataFrame, stop: pd.DataFrame, valuation: pd.DataFrame, examples: pd.DataFrame) -> str:
    def fmt(x: object) -> str:
        try:
            if pd.isna(x):
                return "nan"
            return f"{float(x):.6g}"
        except Exception:
            return str(x)

    g = {row.group: row for row in groups.itertuples(index=False)}
    lines = [
        "# Integer-Side Projection of 64-95 -> 32-63 Signature",
        "",
        "## 1. Purpose",
        "",
        "This analysis projects the sequence-level signature for `64-95 -> 32-63` back onto actual integer coordinates. It asks whether actual integers carrying the signature are biased in integer-side coordinates. It is not a mechanism proof.",
        "",
        "The analysis unit is an occurrence-weighted actual integer projection inside the same sampled long-word universe used by the previous remaining_K chain analysis. A single integer can contribute more than once if multiple `START_IN_LAYER` occurrences in the initial `64-95` layer qualify.",
        "",
        "## 2. Groups",
        "",
        "- A: `transition = 64-95 -> 32-63`, `entry_route = START_IN_LAYER`, `group = pass`, `transition_k = 1`, `pre_k_window_3 = 1,1,1`.",
        "- B: same pass route, but not the A signature.",
        "- C: `from_bin = 64-95`, `entry_route = START_IN_LAYER`, `group = stay`, with the same signature.",
        "- D: same stay route, but not the signature.",
        "",
        "## 3. Main Findings",
        "",
    ]
    for name in ["A_signature_pass", "B_non_signature_pass", "C_signature_stay", "D_non_signature_stay"]:
        if name in g:
            row = g[name]
            lines.append(
                f"- `{name}`: count `{row.occurrence_count}`, unique n `{row.unique_n}`, weighted support `{fmt(row.weighted_support)}`, mean log2(n) `{fmt(row.mean_log2_n)}`, median log2(n) `{fmt(row.median_log2_n)}` ({row.support_note})."
            )
    if "A_signature_pass" in g and "B_non_signature_pass" in g:
        lines.append(
            f"- A vs B: A has mean log2(n) shift `{fmt(g['A_signature_pass'].mean_log2_n - g['B_non_signature_pass'].mean_log2_n)}` and median shift `{fmt(g['A_signature_pass'].median_log2_n - g['B_non_signature_pass'].median_log2_n)}`."
        )
    if "A_signature_pass" in g and "C_signature_stay" in g:
        lines.append(
            f"- A vs C: A has mean log2(n) shift `{fmt(g['A_signature_pass'].mean_log2_n - g['C_signature_stay'].mean_log2_n)}` and median shift `{fmt(g['A_signature_pass'].median_log2_n - g['C_signature_stay'].median_log2_n)}`."
        )
    lines.extend(["", "## 4. Residue Structure", ""])
    for mod in [3, 8, 16, 32, 64, 128, 256, 384, 5, 7, 9]:
        sub = residue[residue["coordinate"] == f"mod_{mod}"].sort_values("A_signature_pass", ascending=False).head(5)
        if sub.empty:
            continue
        vals = ", ".join(f"{int(r.value)}:{fmt(r.A_signature_pass)}" for r in sub.itertuples(index=False))
        lines.append(f"- A top residues mod {mod}: {vals}.")
    lines.append("")
    lines.append("Residue rows include A-vs-B, A-vs-C, and A-vs-D delta/enrichment columns in `integer_signature_64_95_residue.csv`; cells with small support are marked as candidates, not claims.")
    lines.extend(["", "## 5. Prefix-Cylinder Structure", ""])
    for coord in ["parity_prefix_4", "parity_prefix_6", "parity_prefix_8", "valuation_prefix_4", "valuation_prefix_6"]:
        sub = prefix[prefix["coordinate"] == coord].sort_values("A_signature_pass", ascending=False).head(6)
        if sub.empty:
            continue
        vals = ", ".join(f"`{r.value}`:{fmt(r.A_signature_pass)}" for r in sub.itertuples(index=False))
        lines.append(f"- A top {coord}: {vals}.")
    lines.extend(["", "## 6. Stopping-Time / Scale Coordinates", ""])
    for coord in ["stopping_time", "total_stopping_time", "escape_length", "tau", "K_tau", "remaining_K", "x_K", "log_max_over_log_n", "first_peak_time"]:
        sub = stop[stop["coordinate"] == coord]
        a = sub[sub["group"] == "A_signature_pass"]
        b = sub[sub["group"] == "B_non_signature_pass"]
        c = sub[sub["group"] == "C_signature_stay"]
        if a.empty:
            continue
        text = f"- `{coord}` A mean `{fmt(a.iloc[0]['mean'])}`, median `{fmt(a.iloc[0]['median'])}`"
        if not b.empty:
            text += f"; A-B mean delta `{fmt(a.iloc[0]['mean'] - b.iloc[0]['mean'])}`"
        if not c.empty:
            text += f"; A-C mean delta `{fmt(a.iloc[0]['mean'] - c.iloc[0]['mean'])}`"
        text += "."
        lines.append(text)
    lines.extend(["", "## 7. Valuation Structure", ""])
    for coord in ["v2_n", "v2_3n_plus_1", "transition_k", "cumulative_k_before_transition"]:
        sub = valuation[valuation["coordinate"] == coord]
        a = sub[sub["group"] == "A_signature_pass"]
        b = sub[sub["group"] == "B_non_signature_pass"]
        if a.empty:
            continue
        text = f"- `{coord}` A mean `{fmt(a.iloc[0]['mean'])}`, median `{fmt(a.iloc[0]['median'])}`"
        if not b.empty:
            text += f"; A-B mean delta `{fmt(a.iloc[0]['mean'] - b.iloc[0]['mean'])}`"
        text += "."
        lines.append(text)
    lines.extend(["", "## 8. Representative Integers", ""])
    for r in examples[examples["group"] == "A_signature_pass"].head(12).itertuples(index=False):
        lines.append(
            f"- n `{r.n}` (`p={r.power}`, `h={r.h}`, pos `{r.position}`): log2(n) `{fmt(r.log2_n)}`, remaining_K `{r.remaining_K}`, prefix `{r.word_prefix_12}`."
        )
    lines.extend(
        [
            "",
            "## 9. Interpretation Limits",
            "",
            "- This is an integer-side bias check.",
            "- It does not claim causality or mechanism.",
            "- It does not say that the signature arises from an intrinsic property of the integer.",
            "- Small-support cells are candidate cells only.",
            "- The analysis only checks correspondence between a sequence signature and integer coordinates.",
            "- The cautious reading is that the sequence signature has an integer-side shadow where support is adequate.",
            "",
            "## 10. Next Candidates",
            "",
            "Only the strongest supported residue or prefix cells should be promoted to a next run. Good next candidates are larger-sample rechecks of A-vs-B and A-vs-C for the top mod `2^k` residues and top parity/valuation prefix cylinders listed above.",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    module = base.load_source()
    rng = random.Random(SEED)
    tau_cuts: dict[int, tuple[int, int]] = {}
    rows: list[dict[str, object]] = []

    print("sampling iid for tau cuts", flush=True)
    for h in HS:
        sampled = base.sample_iid(module, h, rng)
        tau_cuts[h] = base.weighted_tau_cuts(sampled)
        print(f"tau cuts h={h}: {tau_cuts[h]}", flush=True)

    print("sampling actual integers", flush=True)
    for power in POWERS:
        status = base.load_status(power)
        for h in HS:
            _cut1, cut2 = tau_cuts[h]
            lo, hi, total = module.layer_bounds(power, h)
            escape_indices = [idx for idx in range(lo >> 1, (hi >> 1) + 1) if status[idx] == module.ESCAPE]
            chosen = base.evenly_spaced(escape_indices, ACTUAL_SAMPLE_PER_PH)
            sample_weight = len(escape_indices) / (len(chosen) * total) if chosen else 0.0
            for idx in chosen:
                n = 2 * idx + 1
                word = module.trace_escape(n, 1 << power)
                if len(word) <= cut2:
                    continue
                rows.extend(occurrence_rows_for_n(n, power, h, sample_weight, word))
            print(f"actual power={power} h={h} done rows={len(rows)}", flush=True)
        del status

    data = pd.DataFrame(rows)
    if data.empty:
        raise RuntimeError("no rows produced")

    groups = group_summary(data)

    residue_frames = []
    for mod in MODULI:
        col = f"mod_{mod}"
        data[col] = data["n"].astype(object).map(lambda n, m=mod: int(n) % m)
        frame = categorical_share(data, col)
        residue_frames.append(comparison_rows(frame, "value"))
    residue = pd.concat(residue_frames, ignore_index=True).sort_values(["coordinate", "A_vs_B_non_signature_pass_delta_share"], ascending=[True, False])

    prefix_frames = []
    for length in PREFIX_LENS:
        data[f"parity_prefix_{length}"] = data["word"].map(lambda text, l=length: parity_prefix_from_word(tuple(int(x) for x in text.split(",")), l))
        data[f"valuation_prefix_{length}"] = data["word"].map(lambda text, l=length: ",".join(text.split(",")[:l]))
        for col in [f"parity_prefix_{length}", f"valuation_prefix_{length}"]:
            frame = categorical_share(data, col)
            prefix_frames.append(comparison_rows(frame, "value"))
    prefix = pd.concat(prefix_frames, ignore_index=True).sort_values(["coordinate", "A_vs_B_non_signature_pass_delta_share"], ascending=[True, False])

    stop_cols = [
        "stopping_time",
        "total_stopping_time",
        "escape_length",
        "tau",
        "K_tau",
        "power",
        "h",
        "x_K",
        "remaining_K",
        "log_max_over_log_n",
        "first_peak_time",
        "max_trajectory_value",
    ]
    stopping = numeric_coord_summary(data, stop_cols)
    val_cols = ["v2_n", "v2_3n_plus_1", "transition_k", "cumulative_k_before_transition"]
    valuation = numeric_coord_summary(data, val_cols)
    val_prefix = categorical_share(data, "valuation_near_transition")

    examples = (
        data.sort_values(["group", "weight", "n"], ascending=[True, False, True])
        .groupby("group", group_keys=False)
        .head(40)
        .copy()
    )

    groups.to_csv(OUT / "integer_signature_64_95_groups.csv", index=False, encoding="utf-8-sig")
    residue.to_csv(OUT / "integer_signature_64_95_residue.csv", index=False, encoding="utf-8-sig")
    prefix.to_csv(OUT / "integer_signature_64_95_prefix.csv", index=False, encoding="utf-8-sig")
    stopping.to_csv(OUT / "integer_signature_64_95_stopping_coords.csv", index=False, encoding="utf-8-sig")
    pd.concat([valuation, val_prefix.rename(columns={"value": "category"})], ignore_index=True).to_csv(
        OUT / "integer_signature_64_95_valuation.csv", index=False, encoding="utf-8-sig"
    )
    examples.to_csv(OUT / "integer_signature_64_95_examples.csv", index=False, encoding="utf-8-sig")
    (OUT / "integer_signature_64_95_report.md").write_text(
        build_report(groups, residue, prefix, stopping, valuation, examples),
        encoding="utf-8",
    )
    print(OUT / "integer_signature_64_95_report.md", flush=True)


if __name__ == "__main__":
    main()
