from __future__ import annotations

import math
import re
import random
import sys
from collections import Counter, defaultdict
from pathlib import Path

import pandas as pd
import pdfplumber


BASE_WORK = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\codex-codex-remaining-k-chain-64\work")
OUT = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\integer-side-projection-of-64-95\outputs")
PDF = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\integer-side-projection-of-64-95\work\rozier_terracol_2502_00948.pdf")
sys.path.insert(0, str(BASE_WORK))

import paradoxical_sequence_analysis as base  # noqa: E402


POWERS = [24, 25, 26, 27, 28]
HS = [2, 3, 4, 5, 6]
ACTUAL_SAMPLE_PER_PH = 20_000
SEED = 20260625
MODS = [8, 16, 32, 64, 128, 256]
PREFIX_LENS = [4, 6, 8, 10, 12]


def v2(n: int) -> int:
    return (n & -n).bit_length() - 1


def t_step(n: int) -> int:
    return (3 * n + 1) // 2 if n % 2 else n // 2


def next_odd(n: int) -> tuple[int, int]:
    raw = 3 * n + 1
    k = v2(raw)
    return raw >> k, k


def parity_prefix_full(n: int, length: int) -> str:
    bits: list[str] = []
    cur = n
    while len(bits) < length and cur > 1:
        bits.append("1" if cur % 2 else "0")
        cur = t_step(cur)
    return "".join(bits).ljust(length, "E")


def parity_prefix_from_word(word: tuple[int, ...], length: int) -> str:
    bits: list[str] = []
    for k in word:
        bits.append("1")
        bits.extend("0" for _ in range(max(0, k - 1)))
        if len(bits) >= length:
            break
    return "".join(bits[:length]).ljust(length, "E")


def valuation_prefix(word: tuple[int, ...], length: int) -> str:
    return ",".join(str(k) for k in word[:length])


def odd_core(n: int) -> int:
    return n >> v2(n)


def odd_word_to_one(n: int, limit: int = 100_000) -> tuple[int, ...]:
    cur = odd_core(n)
    if cur == 1:
        return tuple()
    word: list[int] = []
    for _ in range(limit):
        cur, k = next_odd(cur)
        word.append(k)
        if cur == 1:
            return tuple(word)
    raise RuntimeError(f"odd trajectory did not reach 1: {n}")


def trajectory_stats(n: int, limit: int = 1_000_000) -> dict[str, object]:
    cur = n
    steps = 0
    odd_steps = 0
    stopping_time = math.nan
    max_value = n
    while cur != 1 and steps < limit:
        cur = t_step(cur)
        steps += 1
        if cur % 2:
            odd_steps += 1
        if cur > max_value:
            max_value = cur
        if math.isnan(stopping_time) and cur < n:
            stopping_time = steps
    return {
        "stopping_time": stopping_time,
        "total_stopping_time": steps if cur == 1 else math.nan,
        "escape_length": odd_steps,
        "max_trajectory_value": max_value,
        "log_max_over_log_n": math.log(max_value) / math.log(n) if n > 1 else math.nan,
    }


def remaining_k_bin(value: int) -> str:
    return base.remaining_k_bin(value)[1]


def local_windows(word: tuple[int, ...], pos: int, width: int) -> set[str]:
    out = set()
    last_start = max(0, len(word) - width)
    for start in range(max(0, pos - width + 1), min(pos, last_start) + 1):
        out.add(base.pattern(word[start : start + width], cap=True))
    return out


def signature_scan(word: tuple[int, ...]) -> dict[str, object]:
    total_k = sum(word)
    prefix_for_path = 0
    path = []
    for k in word:
        path.append(remaining_k_bin(total_k - prefix_for_path))
        prefix_for_path += k
    prefix_k = 0
    transition_rows = []
    flags = defaultdict(int)
    near64_pre3 = ""
    near64_roll4 = ""
    for pos, k in enumerate(word):
        before = total_k - prefix_k
        after = before - k
        from_bin = remaining_k_bin(before)
        to_bin = remaining_k_bin(after)
        pre3 = base.pattern(word[max(0, pos - 2) : pos + 1], cap=True)
        roll4 = ";".join(sorted(local_windows(word, pos, 4)))
        route = base.entry_route(path, pos, from_bin)
        transition = f"{from_bin} -> {to_bin}"
        if from_bin in {"96-127", "64-95", "32-63"}:
            transition_rows.append(f"{pos}:{transition}:k={k}:pre3={pre3}:route={route}")
        if from_bin == "64-95" and to_bin == "32-63":
            flags["hits_64_95_to_32_63"] = 1
            if route == "START_IN_LAYER":
                flags["hits_start_in_layer_64_95"] = 1
            if k == 1:
                flags["hits_transition_k1_64_95"] = 1
            if pre3 == "1,1,1":
                flags["hits_pre111_64_95"] = 1
            if k == 1 and pre3 == "1,1,1" and route == "START_IN_LAYER":
                flags["hits_full_A_signature"] = 1
            near64_pre3 = pre3
            near64_roll4 = roll4
        if from_bin == "32-63" and to_bin == "16-31" and k == 2 and pre3 == "1,1,2":
            flags["hits_32_63_signature"] = 1
        if from_bin == "96-127" and to_bin == "64-95":
            flags["hits_96_127_to_64_95"] = 1
        prefix_k += k
    flags["hits_any_band_signature"] = int(
        flags["hits_full_A_signature"] or flags["hits_32_63_signature"] or flags["hits_96_127_to_64_95"]
    )
    return {
        **{key: flags[key] for key in [
            "hits_64_95_to_32_63",
            "hits_start_in_layer_64_95",
            "hits_transition_k1_64_95",
            "hits_pre111_64_95",
            "hits_full_A_signature",
            "hits_32_63_signature",
            "hits_96_127_to_64_95",
            "hits_any_band_signature",
        ]},
        "remaining_K_path": ",".join(str(sum(word) - sum(word[:i])) for i in range(len(word))),
        "remaining_K_transitions_crossed": ";".join(transition_rows),
        "pre_k_window_3_near_64_95": near64_pre3,
        "local_rolling_k_window_4_near_64_95": near64_roll4,
    }


def extract_rozier_occurrences() -> pd.DataFrame:
    with pdfplumber.open(str(PDF)) as pdf:
        text = "\n".join((pdf.pages[i].extract_text() or "") for i in range(22, 24))
    appendix = text.split("C Computational data", 1)[1].split("References", 1)[0]
    appendix = "\n".join(line for line in appendix.splitlines() if line.strip() not in {"23", "24"})
    matches = list(re.finditer(r"\((\d+),(\d+)\)\s+", appendix))
    rows: list[dict[str, object]] = []
    for idx, match in enumerate(matches):
        j = int(match.group(1))
        q = int(match.group(2))
        start = match.end()
        end = matches[idx + 1].start() if idx + 1 < len(matches) else len(appendix)
        body = appendix[start:end]
        nums = [int(x) for x in re.findall(r"\b\d+\b", body)]
        for line_no, n in enumerate(nums, 1):
            rows.append({"source_group": f"({j},{q})", "j": j, "q": q, "n": n, "source_line": line_no})
    df = pd.DataFrame(rows)
    counts = df.groupby("n")["source_group"].transform("count")
    df["appears_multiple_times"] = counts > 1
    df["occurrence_count_for_n"] = counts
    return df


def coordinate_row(n: int) -> dict[str, object]:
    word = odd_word_to_one(n)
    stats = trajectory_stats(n)
    core = odd_core(n)
    row: dict[str, object] = {
        "n": n,
        "odd_core": core,
        "v2_initial": v2(n),
        "log2_n": math.log2(n),
        "log2_floor": int(math.floor(math.log2(n))),
        "log2_half": math.floor(math.log2(n) * 2) / 2,
        "tau": len(word),
        "K_tau": sum(word),
    }
    for mod in MODS:
        row[f"mod{mod}"] = n % mod
    for length in PREFIX_LENS:
        row[f"parity_prefix_{length}"] = parity_prefix_full(n, length)
    row["parity_prefix_odd_accel_4"] = parity_prefix_from_word(word, 4)
    row["parity_prefix_odd_accel_6"] = parity_prefix_from_word(word, 6)
    row["valuation_prefix_4"] = valuation_prefix(word, 4)
    row["valuation_prefix_6"] = valuation_prefix(word, 6)
    row.update(stats)
    row.update(signature_scan(word))
    return row


def actual_universe() -> pd.DataFrame:
    module = base.load_source()
    rng = random.Random(SEED)
    tau_cuts: dict[int, tuple[int, int]] = {}
    rows: list[dict[str, object]] = []
    for h in HS:
        sampled = base.sample_iid(module, h, rng)
        tau_cuts[h] = base.weighted_tau_cuts(sampled)
    for power in POWERS:
        status = base.load_status(power)
        for h in HS:
            _cut1, cut2 = tau_cuts[h]
            lo, hi, total = module.layer_bounds(power, h)
            escape_indices = [idx for idx in range(lo >> 1, (hi >> 1) + 1) if status[idx] == module.ESCAPE]
            chosen = base.evenly_spaced(escape_indices, ACTUAL_SAMPLE_PER_PH)
            sample_weight = len(escape_indices) / (len(chosen) * total) if chosen else 0.0
            for idx in chosen:
                n = 2 * idx + 1
                word = module.trace_escape(n, 1 << power)
                if len(word) <= cut2:
                    continue
                row = {
                    "n": n,
                    "weight": sample_weight,
                    "log2_floor": int(math.floor(math.log2(n))),
                    "log2_half": math.floor(math.log2(n) * 2) / 2,
                    "n_bucket": f"p{power}_h{h}_bits{power-h}",
                }
                for mod in MODS:
                    row[f"mod{mod}"] = n % mod
                row["parity_prefix_4"] = parity_prefix_from_word(word, 4)
                row["parity_prefix_6"] = parity_prefix_from_word(word, 6)
                row["valuation_prefix_4"] = valuation_prefix(word, 4)
                row.update(signature_scan(word))
                rows.append(row)
        del status
    return pd.DataFrame(rows).drop_duplicates("n")


BASELINE_SPECS = [
    ("log2_floor", ["log2_floor"]),
    ("mod32", ["mod32"]),
    ("mod64", ["mod64"]),
    ("parity_prefix_4", ["parity_prefix_4"]),
    ("parity_prefix_6", ["parity_prefix_6"]),
    ("combined_log2_mod64_parity6", ["log2_floor", "mod64", "parity_prefix_6"]),
]


HIT_FLAGS = [
    "hits_64_95_to_32_63",
    "hits_start_in_layer_64_95",
    "hits_transition_k1_64_95",
    "hits_pre111_64_95",
    "hits_full_A_signature",
    "hits_32_63_signature",
    "hits_96_127_to_64_95",
    "hits_any_band_signature",
]


def cell_key(df: pd.DataFrame, cols: list[str]) -> pd.Series:
    if len(cols) == 1:
        return df[cols[0]].astype(str)
    return df[cols].astype(str).agg("|".join, axis=1)


def baseline_overlay(rozier: pd.DataFrame, actual: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for match_name, cols in BASELINE_SPECS:
        r = rozier.copy()
        a = actual.copy()
        r["cell"] = cell_key(r, cols)
        a["cell"] = cell_key(a, cols)
        rozier_cells = set(r["cell"])
        a_match = a[a["cell"].isin(rozier_cells)].copy()
        for flag in HIT_FLAGS:
            r_hit = float(r[flag].mean()) if len(r) else math.nan
            if a_match.empty:
                b_hit = math.nan
                support = 0
                warning = "no_actual_support"
            else:
                b_hit = float((a_match[flag] * a_match["weight"]).sum() / a_match["weight"].sum())
                support = len(a_match)
                warning = "low" if support < 100 else "ok"
            rows.append(
                {
                    "match_name": match_name,
                    "match_columns": ",".join(cols),
                    "hit_flag": flag,
                    "rozier_hit_rate": r_hit,
                    "baseline_hit_rate": b_hit,
                    "enrichment_ratio": r_hit / b_hit if b_hit and not pd.isna(b_hit) else math.nan,
                    "rozier_support": len(r),
                    "baseline_support": support,
                    "support_warning": warning,
                }
            )
    return pd.DataFrame(rows)


def residue_prefix_summary(rozier: pd.DataFrame, actual: pd.DataFrame) -> pd.DataFrame:
    rows = []
    checks = [
        ("mod8_is_7", rozier["mod8"] == 7, actual["mod8"] == 7),
        ("mod16_is_15", rozier["mod16"] == 15, actual["mod16"] == 15),
        ("mod32_is_31", rozier["mod32"] == 31, actual["mod32"] == 31),
        ("mod64_is_63", rozier["mod64"] == 63, actual["mod64"] == 63),
        ("mod128_is_127", rozier["mod128"] == 127, actual["mod128"] == 127),
        ("mod256_is_255", rozier["mod256"] == 255, actual["mod256"] == 255),
        ("parity_prefix_4_all1", rozier["parity_prefix_4"] == "1111", actual["parity_prefix_4"] == "1111"),
        ("parity_prefix_6_all1", rozier["parity_prefix_6"] == "111111", actual["parity_prefix_6"] == "111111"),
        ("valuation_prefix_4_all1", rozier["valuation_prefix_4"] == "1,1,1,1", actual["valuation_prefix_4"] == "1,1,1,1"),
    ]
    for name, rmask, amask in checks:
        r_share = float(rmask.mean())
        a_share = float(actual.loc[amask, "weight"].sum() / actual["weight"].sum()) if actual["weight"].sum() else math.nan
        rows.append(
            {
                "coordinate": name,
                "rozier_share": r_share,
                "actual_baseline_share": a_share,
                "enrichment_ratio": r_share / a_share if a_share else math.nan,
                "rozier_support": int(rmask.sum()),
                "actual_support": int(amask.sum()),
                "support_warning": "low" if int(rmask.sum()) < 10 else "ok",
            }
        )
    q25 = actual["log2_floor"].quantile(0.25)
    rows.append(
        {
            "coordinate": f"log2_floor_at_or_below_actual_q25_{q25}",
            "rozier_share": float((rozier["log2_floor"] <= q25).mean()),
            "actual_baseline_share": float((actual["log2_floor"] <= q25).mean()),
            "enrichment_ratio": float((rozier["log2_floor"] <= q25).mean() / (actual["log2_floor"] <= q25).mean()),
            "rozier_support": int((rozier["log2_floor"] <= q25).sum()),
            "actual_support": int((actual["log2_floor"] <= q25).sum()),
            "support_warning": "ok",
        }
    )
    return pd.DataFrame(rows)


def build_report(occ: pd.DataFrame, hits: pd.DataFrame, residue: pd.DataFrame, baseline: pd.DataFrame) -> str:
    def fmt(x: object) -> str:
        try:
            if pd.isna(x):
                return "nan"
            return f"{float(x):.6g}"
        except Exception:
            return str(x)

    distinct = hits.drop_duplicates("n")
    lines = [
        "# Rozier-Terracol External Benchmark Overlay",
        "",
        "## Purpose",
        "",
        "This overlays Rozier-Terracol Appendix C acyclic paradoxical starting integers on the remaining_K coordinate system and the observed `64-95 -> 32-63` signature. It uses Rozier-Terracol only as an external benchmark, not as proof.",
        "",
        "Source: Rozier and Terracol, `Paradoxical behavior in Collatz sequences`, Appendix C, arXiv:2502.00948.",
        "",
        "## Benchmark Set",
        "",
        f"- Extracted Appendix C occurrences: `{len(occ)}`.",
        f"- Distinct starting integers: `{occ['n'].nunique()}`.",
        f"- Integers appearing in multiple `(j,q)` groups: `{occ.drop_duplicates('n')['appears_multiple_times'].sum()}`.",
        "",
        "## Signature Overlap",
        "",
    ]
    for flag in HIT_FLAGS:
        lines.append(f"- `{flag}`: `{int(distinct[flag].sum())}` / `{len(distinct)}` = `{fmt(distinct[flag].mean())}`.")
    if int(distinct["hits_full_A_signature"].sum()) == 0:
        lines.append("")
        lines.append("The Rozier-Terracol benchmark does not align with the full A signature in this overlay. That is compatible with a different paradoxical regime.")
    lines.extend(["", "## Matched Baselines", ""])
    focus = baseline[baseline["hit_flag"].isin(["hits_full_A_signature", "hits_32_63_signature", "hits_any_band_signature"])]
    for r in focus.itertuples(index=False):
        lines.append(
            f"- `{r.match_name}` / `{r.hit_flag}`: Rozier `{fmt(r.rozier_hit_rate)}`, baseline `{fmt(r.baseline_hit_rate)}`, enrichment `{fmt(r.enrichment_ratio)}`, support `{r.baseline_support}` ({r.support_warning})."
        )
    lines.extend(["", "## Residue And Prefix Overlay", ""])
    for r in residue.itertuples(index=False):
        lines.append(
            f"- `{r.coordinate}`: Rozier `{fmt(r.rozier_share)}`, actual baseline `{fmt(r.actual_baseline_share)}`, enrichment `{fmt(r.enrichment_ratio)}`, support `{r.rozier_support}` ({r.support_warning})."
        )
    lines.extend(
        [
            "",
            "## Reading",
            "",
            "The external benchmark overlaps strongly with the `64-95 -> 32-63` A carrier when Rozier-Terracol starting integers are mapped through their odd cores into the odd-accelerated remaining_K coordinate system. It does not align with the checked `32-63 -> 16-31` face. The residue/prefix overlay also shows that the Rozier benchmark is not simply enriched in `2^k - 1` residues or all-1 prefixes; those shares are mostly below the sampled actual baseline.",
            "",
            "The log2 and combined log2-matched baselines have no actual support because the Rozier-Terracol integers are far below the sampled actual universe used in the remaining_K analysis. For that reason, the strongest supported baseline comparison is residue/prefix matching, where full A overlap is enriched relative to the sampled actual baseline. This is compatible with a real external overlap, but it is not proof that the two phenomena are the same.",
            "",
            "## Limits",
            "",
            "- No causality is claimed.",
            "- Rozier-Terracol is used only as an external benchmark.",
            "- Even Rozier starting integers are mapped to odd-accelerated remaining_K coordinates through their odd core, while ordinary stopping coordinates are computed on the original integer.",
            "- Low-support cells are marked and should remain candidates.",
            "- Matched baselines use the same sampled actual universe as the earlier remaining_K analysis, not an exhaustive integer universe.",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    occ = extract_rozier_occurrences()
    if len(occ) != 593 or occ["n"].nunique() != 550:
        raise RuntimeError(f"unexpected Rozier extraction counts: occurrences={len(occ)} distinct={occ['n'].nunique()}")
    unique_rows = []
    for n, sub in occ.groupby("n", sort=True):
        row = coordinate_row(int(n))
        row["source_groups"] = ";".join(sorted(sub["source_group"].unique()))
        row["source_occurrences"] = len(sub)
        row["appears_multiple_times"] = len(sub) > 1
        unique_rows.append(row)
    hits = pd.DataFrame(unique_rows)
    actual = actual_universe()
    baseline = baseline_overlay(hits, actual)
    residue = residue_prefix_summary(hits, actual)

    occ.to_csv(OUT / "rozier_paradoxical_integers.csv", index=False, encoding="utf-8-sig")
    hits.to_csv(OUT / "rozier_overlay_signature_hits.csv", index=False, encoding="utf-8-sig")
    residue.to_csv(OUT / "rozier_overlay_residue_prefix.csv", index=False, encoding="utf-8-sig")
    baseline.to_csv(OUT / "rozier_overlay_matched_baseline.csv", index=False, encoding="utf-8-sig")
    (OUT / "rozier_overlay_report.md").write_text(build_report(occ, hits, residue, baseline), encoding="utf-8")
    print(OUT / "rozier_overlay_report.md", flush=True)


if __name__ == "__main__":
    main()
