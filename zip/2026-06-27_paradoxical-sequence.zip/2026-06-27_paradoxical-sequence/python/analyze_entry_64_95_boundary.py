from __future__ import annotations

import csv
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path

import pandas as pd


BASE_WORK = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\codex-codex-remaining-k-chain-64\work")
CLASSIFICATION = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-27\integer-side-projection-of-64-95\outputs\rozier_nonhit_classification.csv"
)
OUT = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\task-analyze-the-12-trajectories-that\outputs")
sys.path.insert(0, str(BASE_WORK))

import paradoxical_sequence_analysis as base  # noqa: E402


TARGET_FROM = "64-95"
TARGET_TO = "32-63"
WATCH_BANDS = ("32-63", "64-95", "96-127")


def v2(n: int) -> int:
    return (n & -n).bit_length() - 1


def odd_core(n: int) -> int:
    return n >> v2(n)


def next_odd(n: int) -> tuple[int, int]:
    raw = 3 * n + 1
    k = v2(raw)
    return raw >> k, k


def odd_word_to_one(n: int) -> tuple[int, ...]:
    cur = odd_core(n)
    word: list[int] = []
    while cur != 1:
        cur, k = next_odd(cur)
        word.append(k)
        if len(word) > 100_000:
            raise RuntimeError(f"long trajectory: {n}")
    return tuple(word)


def event_word_original_n_strict(n: int) -> tuple[int, ...]:
    init = v2(n)
    tail = odd_word_to_one(n)
    return ((init,) if init else tuple()) + tail


def remaining_k_bin(value: int) -> str:
    return base.remaining_k_bin(value)[1]


def pattern(values: tuple[int, ...] | list[int]) -> str:
    return base.pattern(values, cap=True)


def raw_pattern(values: tuple[int, ...] | list[int]) -> str:
    return base.pattern(values, cap=False)


def path_for_word(word: tuple[int, ...]) -> list[str]:
    total = sum(word)
    prefix = 0
    out = []
    for k in word:
        out.append(remaining_k_bin(total - prefix))
        prefix += k
    return out


def local_windows(word: tuple[int, ...], pos: int, width: int) -> tuple[str, ...]:
    out = set()
    last_start = max(0, len(word) - width)
    for start in range(max(0, pos - width + 1), min(pos, last_start) + 1):
        out.add(pattern(word[start : start + width]))
    return tuple(sorted(out))


def t_step(n: int) -> int:
    return (3 * n + 1) // 2 if n % 2 else n // 2


def parity_prefix_full(n: int, length: int) -> str:
    bits: list[str] = []
    cur = n
    while len(bits) < length and cur > 1:
        bits.append("1" if cur % 2 else "0")
        cur = t_step(cur)
    return "".join(bits).ljust(length, "E")


def scan_events(n: int) -> tuple[tuple[int, ...], list[dict[str, object]]]:
    word = event_word_original_n_strict(n)
    path = path_for_word(word)
    total = sum(word)
    prefix = 0
    rows: list[dict[str, object]] = []
    for pos, k in enumerate(word):
        before = total - prefix
        after = before - k
        from_bin = remaining_k_bin(before)
        to_bin = remaining_k_bin(after)
        rows.append(
            {
                "trajectory_id": n,
                "n": n,
                "odd_core": odd_core(n),
                "position": pos,
                "word_length": len(word),
                "total_K": total,
                "pre_remaining_K": before,
                "post_remaining_K": after,
                "from_bin": from_bin,
                "to_bin": to_bin,
                "transition": f"{from_bin} -> {to_bin}",
                "transition_k": k,
                "transition_k_cat": base.kcat(k),
                "entry_route": base.entry_route(path, pos, from_bin),
                "pre_k_window_3": pattern(word[max(0, pos - 2) : pos + 1]),
                "pre_k_window_5": pattern(word[max(0, pos - 4) : pos + 1]),
                "local_rolling_k_window_4": ";".join(local_windows(word, pos, 4)),
            }
        )
        prefix += k
    return word, rows


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def median(values: list[int]) -> float:
    if not values:
        return math.nan
    s = sorted(values)
    mid = len(s) // 2
    if len(s) % 2:
        return float(s[mid])
    return (s[mid - 1] + s[mid]) / 2


def threshold_bin(value: int) -> str:
    if 48 <= value <= 55:
        return "48-55"
    if 56 <= value <= 63:
        return "56-63"
    if 64 <= value <= 71:
        return "64-71"
    if 72 <= value <= 95:
        return "72-95"
    return "outside"


def mean_bool(rows: list[dict[str, object]], key: str) -> float:
    return sum(int(r[key]) for r in rows) / len(rows) if rows else math.nan


def mean_num(rows: list[dict[str, object]], key: str) -> float:
    return sum(float(r[key]) for r in rows) / len(rows) if rows else math.nan


def control_row(n: int, word: tuple[int, ...], max_remaining_k: int, group: str) -> dict[str, object]:
    return {
        "group": group,
        "trajectory_id": n,
        "original_n": n,
        "odd_core": odd_core(n),
        "log2_n": math.log2(n),
        "valuation_word_length": len(word),
        "total_K": sum(word),
        "max_remaining_K": max_remaining_k,
        "parity_prefix_4": parity_prefix_full(n, 4),
        "parity_prefix_6": parity_prefix_full(n, 6),
        "valuation_prefix_4": raw_pattern(word[:4]),
        "valuation_prefix_6": raw_pattern(word[:6]),
        "mod8": n % 8,
        "mod16": n % 16,
        "mod32": n % 32,
        "mod64": n % 64,
    }


def main() -> None:
    OUT.mkdir(exist_ok=True)
    classified = pd.read_csv(CLASSIFICATION)
    universe = classified[classified["mode"] == "original_n_strict"].copy()
    ids = sorted(int(x) for x in universe["n_original"].unique())
    if len(ids) != 550:
        raise RuntimeError(f"expected 550 original_n_strict trajectories, got {len(ids)}")

    words: dict[int, tuple[int, ...]] = {}
    events_by_id: dict[int, list[dict[str, object]]] = {}
    for n in ids:
        word, events = scan_events(n)
        words[n] = word
        events_by_id[n] = events

    profile_rows: list[dict[str, object]] = []
    for n in ids:
        events = events_by_id[n]
        from_bins = {str(e["from_bin"]) for e in events}
        has_target = any(e["from_bin"] == TARGET_FROM and e["to_bin"] == TARGET_TO for e in events)
        max_k = max(int(e["pre_remaining_K"]) for e in events) if events else 0
        profile_rows.append(
            {
                "trajectory_id": n,
                "original_n": n,
                "odd_core": odd_core(n),
                "max_remaining_K": max_k,
                "max_remaining_K_bin": remaining_k_bin(max_k),
                "enters_32_63": int("32-63" in from_bins),
                "enters_64_95": int("64-95" in from_bins),
                "enters_96_127": int("96-127" in from_bins),
                "has_64_95_to_32_63": int(has_target),
            }
        )
    write_csv(OUT / "step1_max_remaining_K_profile.csv", profile_rows)

    by_n = {r["trajectory_id"]: r for r in profile_rows}
    g0 = [r for r in profile_rows if not int(r["enters_64_95"])]
    g1 = [r for r in profile_rows if int(r["enters_64_95"])]
    g2: list[dict[str, object]] = []
    g3: list[dict[str, object]] = []

    first_entry_rows: list[dict[str, object]] = []
    for r in g1:
        n = int(r["trajectory_id"])
        first = next(e for e in events_by_id[n] if e["from_bin"] == TARGET_FROM)
        first_pass = int(first["to_bin"] == TARGET_TO)
        if first_pass:
            g2.append(r)
        if not int(r["has_64_95_to_32_63"]):
            g3.append(r)
        first_entry_rows.append(
            {
                "trajectory_id": n,
                "n": n,
                "odd_core": odd_core(n),
                "first_64_95_index": first["position"],
                "pre_remaining_K": first["pre_remaining_K"],
                "post_remaining_K": first["post_remaining_K"],
                "transition": first["transition"],
                "transition_k": first["transition_k"],
                "entry_route": first["entry_route"],
                "pre_k_window_3": first["pre_k_window_3"],
                "pre_k_window_5": first["pre_k_window_5"],
                "local_rolling_k_window_4": first["local_rolling_k_window_4"],
                "does_first_entry_event_pass_to_32_63": first_pass,
                "has_A_event_anywhere": int(
                    any(
                        e["from_bin"] == TARGET_FROM
                        and e["to_bin"] == TARGET_TO
                        and e["entry_route"] == "START_IN_LAYER"
                        and e["transition_k"] == 1
                        and e["pre_k_window_3"] == "1,1,1"
                        for e in events_by_id[n]
                    )
                ),
            }
        )
    write_csv(OUT / "step3_first_64_95_entry.csv", first_entry_rows)

    previous_12 = [7, 9, 18, 19, 25, 91, 121, 242, 243, 484, 485, 486]
    collapse_rows: list[dict[str, object]] = []
    for n in previous_12:
        word = words[n]
        band_sequence = [str(e["from_bin"]) for e in events_by_id[n]]
        if events_by_id[n]:
            band_sequence.append(str(events_by_id[n][-1]["to_bin"]))
        collapse_rows.append(
            {
                "n": n,
                "odd_core": odd_core(n),
                "trajectory_id": n,
                "full_valuation_word": raw_pattern(word),
                "remaining_K_band_sequence": " | ".join(band_sequence),
            }
        )
    write_csv(OUT / "step2_odd_core_collapse.csv", collapse_rows)

    b_low = [r for r in g0 if r["max_remaining_K_bin"] == "32-63"]
    b_entry = g1
    control_rows = [
        control_row(int(r["trajectory_id"]), words[int(r["trajectory_id"])], int(r["max_remaining_K"]), "B_low")
        for r in b_low
    ]
    control_rows.extend(
        control_row(int(r["trajectory_id"]), words[int(r["trajectory_id"])], int(r["max_remaining_K"]), "B_entry")
        for r in b_entry
    )
    write_csv(OUT / "step4_boundary_controls.csv", control_rows)

    g0_highest_rows: list[dict[str, object]] = []
    for r in g0:
        n = int(r["trajectory_id"])
        events = events_by_id[n]
        highest = max(events, key=lambda e: (int(e["pre_remaining_K"]), -int(e["position"])))
        pos = int(highest["position"])
        next_transitions = [str(e["transition"]) for e in events[pos + 1 : pos + 4]]
        g0_highest_rows.append(
            {
                "trajectory_id": n,
                "n": n,
                "odd_core": odd_core(n),
                "highest_remaining_K": highest["pre_remaining_K"],
                "highest_remaining_K_bin": highest["from_bin"],
                "index_of_highest_remaining_K": highest["position"],
                "transition_at_highest": highest["transition"],
                "transition_k_at_highest": highest["transition_k"],
                "entry_route_at_highest": highest["entry_route"],
                "pre_k_window_3_at_highest": highest["pre_k_window_3"],
                "local_rolling_k_window_4_at_highest": highest["local_rolling_k_window_4"],
                "next_3_transitions_after_highest": " | ".join(next_transitions),
            }
        )
    write_csv(OUT / "step5_G0_highest_events.csv", g0_highest_rows)

    threshold_source: list[dict[str, object]] = []
    for r in profile_rows:
        n = int(r["trajectory_id"])
        word = words[n]
        threshold_source.append(
            {
                "trajectory_id": n,
                "max_remaining_K": int(r["max_remaining_K"]),
                "threshold_bin": threshold_bin(int(r["max_remaining_K"])),
                "word_length": len(word),
                "total_K": sum(word),
                "valuation_prefix_4_all1": int(tuple(word[:4]) == (1, 1, 1, 1)),
                "parity_prefix_1111": int(parity_prefix_full(n, 4) == "1111"),
                "mod16_eq_15": int(n % 16 == 15),
                "mod32_eq_31": int(n % 32 == 31),
            }
        )
    threshold_rows: list[dict[str, object]] = []
    for label in ["48-55", "56-63", "64-71", "72-95"]:
        rows = [r for r in threshold_source if r["threshold_bin"] == label]
        threshold_rows.append(
            {
                "max_remaining_K_bin": label,
                "trajectory_count": len(rows),
                "mean_word_length": mean_num(rows, "word_length"),
                "mean_total_K": mean_num(rows, "total_K"),
                "share_all1_valuation_prefix_len4": mean_bool(rows, "valuation_prefix_4_all1"),
                "share_parity_prefix_1111": mean_bool(rows, "parity_prefix_1111"),
                "share_mod16_eq_15": mean_bool(rows, "mod16_eq_15"),
                "share_mod32_eq_31": mean_bool(rows, "mod32_eq_31"),
            }
        )
    write_csv(OUT / "step6_threshold_counts.csv", threshold_rows)

    first_summaries = {
        "transition": Counter(str(r["transition"]) for r in first_entry_rows),
        "transition_k": Counter(str(r["transition_k"]) for r in first_entry_rows),
        "entry_route": Counter(str(r["entry_route"]) for r in first_entry_rows),
        "pre_k_window_3": Counter(str(r["pre_k_window_3"]) for r in first_entry_rows),
    }
    g0_max_values = [int(r["max_remaining_K"]) for r in g0]
    g0_bin_counts = Counter(str(r["max_remaining_K_bin"]) for r in g0)
    odd_core_groups = defaultdict(list)
    for row in collapse_rows:
        odd_core_groups[int(row["odd_core"])].append(int(row["n"]))
    duplicate_groups = {core: members for core, members in odd_core_groups.items() if len(members) > 1}

    def top_lines(counter: Counter[str], limit: int = 10) -> list[str]:
        return [f"- `{k}`: {v}" for k, v in counter.most_common(limit)]

    b_low_summary = [r for r in control_rows if r["group"] == "B_low"]
    b_entry_summary = [r for r in control_rows if r["group"] == "B_entry"]

    def coord_summary(rows: list[dict[str, object]]) -> dict[str, object]:
        return {
            "count": len(rows),
            "mean_log2_n": mean_num(rows, "log2_n"),
            "mean_word_length": mean_num(rows, "valuation_word_length"),
            "mean_total_K": mean_num(rows, "total_K"),
            "share_parity_1111": sum(1 for r in rows if r["parity_prefix_4"] == "1111") / len(rows) if rows else math.nan,
            "share_valuation_1111": sum(1 for r in rows if r["valuation_prefix_4"] == "1,1,1,1") / len(rows) if rows else math.nan,
            "share_mod16_15": sum(1 for r in rows if int(r["mod16"]) == 15) / len(rows) if rows else math.nan,
            "share_mod32_31": sum(1 for r in rows if int(r["mod32"]) == 31) / len(rows) if rows else math.nan,
        }

    b_low_coord = coord_summary(b_low_summary)
    b_entry_coord = coord_summary(b_entry_summary)
    first_pass_count = sum(int(r["does_first_entry_event_pass_to_32_63"]) for r in first_entry_rows)
    first_a_like = sum(
        1
        for r in first_entry_rows
        if r["does_first_entry_event_pass_to_32_63"]
        and r["entry_route"] == "START_IN_LAYER"
        and int(r["transition_k"]) == 1
        and r["pre_k_window_3"] == "1,1,1"
    )
    a_anywhere = sum(int(r["has_A_event_anywhere"]) for r in first_entry_rows)

    report = [
        "# Entry boundary into remaining_K band 64-95",
        "",
        "Observational analysis only. Dataset: `original_n_strict` rows from the same Rozier-overlay trajectory set used in the previous report; event scanner definitions are reused from the remaining_K pipeline.",
        "",
        "## Group sizes",
        "",
        f"- total trajectories: `{len(ids)}`",
        f"- G0 never enters `64-95`: `{len(g0)}`",
        f"- G1 enters `64-95`: `{len(g1)}`",
        f"- G2 first `64-95` event passes to `32-63`: `{len(g2)}`",
        f"- G3 enters `64-95` but never has `64-95 -> 32-63`: `{len(g3)}`",
        "",
        "## Step 1. Max remaining_K profile",
        "",
        f"G0 max_remaining_K min/median/max: `{min(g0_max_values)}` / `{median(g0_max_values):.1f}` / `{max(g0_max_values)}`.",
        "",
        "G0 max_remaining_K_bin counts:",
        *[f"- `{k}`: {v}" for k, v in sorted(g0_bin_counts.items())],
        "",
        "Reading: the 12 G0 cases are not all clustered just below 64; five are below `32-63`, and seven are in `32-63`.",
        "",
        "## Step 2. Odd-core collapse",
        "",
        f"The 12 rows collapse to `{len(odd_core_groups)}` distinct odd cores.",
    ]
    if duplicate_groups:
        report.append("")
        report.append("Duplicate odd-core groups:")
        for core, members in sorted(duplicate_groups.items()):
            report.append(f"- odd_core `{core}`: {members}")
    report.extend(
        [
            "",
            "## Step 3. First-entry analysis",
            "",
            f"First `64-95` event passes immediately to `32-63` in `{first_pass_count}/{len(first_entry_rows)}` G1 trajectories.",
            f"A-like at first entry (`pass`, `START_IN_LAYER`, `transition_k=1`, `pre111`) occurs in `{first_a_like}/{len(first_entry_rows)}` G1 trajectories.",
            f"A signature anywhere in trajectories that enter `64-95`: `{a_anywhere}/{len(first_entry_rows)}`.",
            "",
            "First-entry transition counts:",
            *top_lines(first_summaries["transition"]),
            "",
            "First-entry transition_k counts:",
            *top_lines(first_summaries["transition_k"]),
            "",
            "First-entry entry_route counts:",
            *top_lines(first_summaries["entry_route"]),
            "",
            "First-entry pre_k_window_3 counts:",
            *top_lines(first_summaries["pre_k_window_3"]),
            "",
            "## Step 4. Boundary-near controls",
            "",
            f"B_low size: `{len(b_low_summary)}`. B_entry size: `{len(b_entry_summary)}`.",
            "",
            f"B_low summary: mean log2(n) `{b_low_coord['mean_log2_n']:.3f}`, mean word length `{b_low_coord['mean_word_length']:.3f}`, mean total_K `{b_low_coord['mean_total_K']:.3f}`, share valuation prefix 1,1,1,1 `{b_low_coord['share_valuation_1111']:.3f}`, share parity 1111 `{b_low_coord['share_parity_1111']:.3f}`, share mod16=15 `{b_low_coord['share_mod16_15']:.3f}`, share mod32=31 `{b_low_coord['share_mod32_31']:.3f}`.",
            f"B_entry summary: mean log2(n) `{b_entry_coord['mean_log2_n']:.3f}`, mean word length `{b_entry_coord['mean_word_length']:.3f}`, mean total_K `{b_entry_coord['mean_total_K']:.3f}`, share valuation prefix 1,1,1,1 `{b_entry_coord['share_valuation_1111']:.3f}`, share parity 1111 `{b_entry_coord['share_parity_1111']:.3f}`, share mod16=15 `{b_entry_coord['share_mod16_15']:.3f}`, share mod32=31 `{b_entry_coord['share_mod32_31']:.3f}`.",
            "",
            "Because B_low has only seven cases, these coordinate contrasts should be read as low-support diagnostics only.",
            "",
            "## Step 5. Transition just below the boundary",
            "",
            "For G0, highest remaining_K events are listed in `step5_G0_highest_events.csv`. The short G0 cases immediately move downstream from their highest event; the longer G0 cases start in `32-63` and usually stay in `32-63` before later moving down.",
            "",
            "## Step 6. Threshold counts",
            "",
        ]
    )
    for row in threshold_rows:
        report.append(
            f"- `{row['max_remaining_K_bin']}`: count `{row['trajectory_count']}`, mean word length `{float(row['mean_word_length']):.3f}`, mean total_K `{float(row['mean_total_K']):.3f}`, all-1 valuation prefix4 `{float(row['share_all1_valuation_prefix_len4']):.3f}`, parity1111 `{float(row['share_parity_prefix_1111']):.3f}`, mod16=15 `{float(row['share_mod16_eq_15']):.3f}`, mod32=31 `{float(row['share_mod32_eq_31']):.3f}`."
        )
    report.extend(
        [
            "",
            "## Final descriptive answers",
            "",
            "1. Yes. The 12 no-transition trajectories are truly outside the `64-95` layer: all have `enters_64_95 = 0`.",
            f"2. They are not 12 independent odd-core trajectories. They collapse to `{len(odd_core_groups)}` odd cores; duplicates appear under powers of two.",
            "3. The entrance is gradual in this coordinate audit rather than a clean sharp integer-side break. The threshold rows show count and mean-size changes, but no single residue/prefix flag cleanly separates the boundary.",
            f"4. The typical first-entry signature is dominated by the observed first-entry counts above; most first `64-95` events are `64-95 -> 64-95` stays, with `transition_k=1` common.",
            f"5. A does not usually appear at first entry: first-entry A-like events are `{first_a_like}/{len(first_entry_rows)}`. A-anywhere is `{a_anywhere}/{len(first_entry_rows)}`, so A is mostly a later-inside-layer event in this dataset.",
            "6. There is no strong integer-side shadow at the 64 boundary in these simple coordinates. The B_low group is small, so this is a descriptive non-finding, not a proof of invisibility.",
            "7. These 12 should be treated as boundary non-entrants and low-K/shorter cases, not near-A failures inside the `64-95` layer.",
            "",
            "## Output files",
            "",
            "- `step1_max_remaining_K_profile.csv`",
            "- `step2_odd_core_collapse.csv`",
            "- `step3_first_64_95_entry.csv`",
            "- `step4_boundary_controls.csv`",
            "- `step5_G0_highest_events.csv`",
            "- `step6_threshold_counts.csv`",
        ]
    )
    (OUT / "entry_64_95_boundary_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(OUT / "entry_64_95_boundary_report.md")


if __name__ == "__main__":
    main()
