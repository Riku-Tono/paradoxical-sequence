from __future__ import annotations

import csv
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean, median

import pandas as pd


WORK = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\task-analyze-the-12-trajectories-that\work")
OUT = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\task-analyze-the-12-trajectories-that\outputs")
CLASSIFICATION = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-27\integer-side-projection-of-64-95\outputs\rozier_nonhit_classification.csv"
)
sys.path.insert(0, str(WORK))

from analyze_entry_64_95_boundary import (  # noqa: E402
    event_word_original_n_strict,
    local_windows,
    odd_core,
    parity_prefix_full,
    path_for_word,
    pattern,
    remaining_k_bin,
)

import paradoxical_sequence_analysis as base  # noqa: E402


FROM_BIN = "64-95"
TO_BIN = "32-63"
NA = ""
CLASSES = ["A_start", "Other_start"]


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def raw_pattern(values: tuple[int, ...]) -> str:
    return base.pattern(values, cap=False)


def scan_events(n: int) -> tuple[tuple[int, ...], list[dict[str, object]]]:
    word = event_word_original_n_strict(n)
    path = path_for_word(word)
    total = sum(word)
    prefix = 0
    events: list[dict[str, object]] = []
    for pos, k in enumerate(word):
        before = total - prefix
        after = before - k
        from_bin = remaining_k_bin(before)
        to_bin = remaining_k_bin(after)
        route = base.entry_route(path, pos, from_bin)
        events.append(
            {
                "position": pos,
                "remaining_K_before": before,
                "remaining_K_after": after,
                "from_bin": from_bin,
                "to_bin": to_bin,
                "transition": f"{from_bin} -> {to_bin}",
                "transition_k": k,
                "entry_route": route,
                "pre_k_window_3": pattern(word[max(0, pos - 2) : pos + 1]),
                "pre_k_window_5": pattern(word[max(0, pos - 4) : pos + 1]),
                "local_window_3": ";".join(local_windows(word, pos, 3)),
                "local_window_4": ";".join(local_windows(word, pos, 4)),
                "local_window_5": ";".join(local_windows(word, pos, 5)),
            }
        )
        prefix += k
    return word, events


def is_astart(event: dict[str, object]) -> bool:
    return (
        event["entry_route"] == "START_IN_LAYER"
        and int(event["transition_k"]) == 1
        and event["pre_k_window_3"] == "1,1,1"
    )


def longest_k1_run(events: list[dict[str, object]]) -> int:
    best = cur = 0
    for event in events:
        if int(event["transition_k"]) == 1:
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best


def seq(events: list[dict[str, object]], key: str) -> str:
    return " | ".join(str(e[key]) for e in events)


def first_after(events: list[dict[str, object]], start: int, predicate) -> dict[str, object] | None:
    for event in events[start + 1 :]:
        if predicate(event):
            return event
    return None


def steps_after(start: int, event: dict[str, object] | None) -> object:
    return int(event["position"]) - start if event else NA


def wait_bucket(wait: int) -> str:
    if wait == 0:
        return "wait_0"
    if wait == 1:
        return "wait_1"
    if wait == 2:
        return "wait_2"
    if 3 <= wait <= 5:
        return "wait_3_5"
    if 6 <= wait <= 10:
        return "wait_6_10"
    return "wait_11_plus"


def safe_mean(values: list[float]) -> float:
    return float(mean(values)) if values else math.nan


def safe_median(values: list[float]) -> float:
    return float(median(values)) if values else math.nan


def fmt(value: object, digits: int = 3) -> str:
    try:
        x = float(value)
    except (TypeError, ValueError):
        return str(value)
    if math.isnan(x):
        return "NA"
    return f"{x:.{digits}f}"


def top_patterns(rows: list[dict[str, object]], key: str, limit: int = 8) -> str:
    counts = Counter(str(r[key]) for r in rows if r[key] != NA)
    return "; ".join(f"{pat}:{count}" for pat, count in counts.most_common(limit))


def top_other_signatures(rows: list[dict[str, object]], limit: int = 8) -> str:
    other = [r for r in rows if r["class"] == "Other_start"]
    counts = Counter((str(r["first_pass_transition_k"]), str(r["first_pass_pre_k_window_3"])) for r in other)
    return "; ".join(f"k={k}/pre3={pre3}:{count}" for (k, pre3), count in counts.most_common(limit))


def numeric_summary(rows: list[dict[str, object]], fields: list[str], cls: str) -> dict[str, object]:
    sub = [r for r in rows if r["class"] == cls]
    out: dict[str, object] = {"class": cls, "count": len(sub)}
    for field in fields:
        vals = [float(r[field]) for r in sub if r[field] != NA]
        out[f"{field}_mean"] = safe_mean(vals)
        out[f"{field}_median"] = safe_median(vals)
        out[f"{field}_min"] = min(vals) if vals else math.nan
        out[f"{field}_max"] = max(vals) if vals else math.nan
    return out


def duplicate_groups(rows: list[dict[str, object]], limit: int = 5) -> str:
    groups = defaultdict(list)
    for row in rows:
        groups[int(row["odd_core"])].append(int(row["n"]))
    dup = [(core, vals) for core, vals in groups.items() if len(vals) > 1]
    dup.sort(key=lambda item: (-len(item[1]), item[0]))
    return "; ".join(f"{core}:{sorted(vals)}" for core, vals in dup[:limit])


def share(rows: list[dict[str, object]], pred) -> float:
    return sum(1 for r in rows if pred(r)) / len(rows) if rows else math.nan


def main() -> None:
    OUT.mkdir(exist_ok=True)
    classified = pd.read_csv(CLASSIFICATION)
    universe = classified[classified["mode"] == "original_n_strict"].copy()
    ids = sorted(int(x) for x in universe["n_original"].unique())
    if len(ids) != 550:
        raise RuntimeError(f"expected 550 trajectories, got {len(ids)}")

    step1_rows: list[dict[str, object]] = []
    other_signature_source: list[dict[str, object]] = []
    distance_rows: list[dict[str, object]] = []
    history_rows: list[dict[str, object]] = []
    downstream_rows: list[dict[str, object]] = []
    integer_source_rows: list[dict[str, object]] = []
    g0 = g1 = 0

    for n in ids:
        word, events = scan_events(n)
        layer_events = [e for e in events if e["from_bin"] == FROM_BIN]
        if not layer_events:
            g0 += 1
            continue
        g1 += 1
        first64 = layer_events[0]
        first_pass = next((e for e in layer_events if e["to_bin"] == TO_BIN), None)
        if first_pass is None:
            raise RuntimeError(f"G1 without pass: {n}")
        if first_pass["entry_route"] != "START_IN_LAYER":
            continue
        cls = "A_start" if is_astart(first_pass) else "Other_start"
        pass_pos = int(first_pass["position"])
        first64_pos = int(first64["position"])
        first_pass_wait = pass_pos - first64_pos
        row = {
            "trajectory_id": n,
            "n": n,
            "odd_core": odd_core(n),
            "log2_n": math.log2(n),
            "word_length": len(word),
            "total_K": sum(word),
            "first_64_95_index": first64_pos,
            "first_pass_index": pass_pos,
            "first_pass_wait_events": first_pass_wait,
            "first_pass_transition_k": first_pass["transition_k"],
            "first_pass_pre_k_window_3": first_pass["pre_k_window_3"],
            "first_pass_pre_k_window_5": first_pass["pre_k_window_5"],
            "first_pass_local_window_3": first_pass["local_window_3"],
            "first_pass_local_window_4": first_pass["local_window_4"],
            "first_pass_local_window_5": first_pass["local_window_5"],
            "class": cls,
        }
        step1_rows.append(row)
        if cls == "Other_start":
            other_signature_source.append(row)
            failed = []
            if int(first_pass["transition_k"]) != 1:
                failed.append("transition_k = 1")
            pre5_parts = str(first_pass["pre_k_window_5"]).split(",")
            if first_pass["pre_k_window_3"] != "1,1,1":
                failed.append("pre_k_window_3 = 1,1,1")
            if len(pre5_parts) < 3 or pre5_parts[-3:] != ["1", "1", "1"]:
                failed.append("pre_k_window_5 suffix 1,1,1")
            if "1,1,1,1" not in str(first_pass["local_window_4"]).split(";"):
                failed.append("local_window_4 contains 1,1,1,1")
            distance_rows.append(
                {
                    "trajectory_id": n,
                    "n": n,
                    "odd_core": odd_core(n),
                    "failed_conditions": "; ".join(failed),
                    "num_failed_conditions": len(failed),
                    "first_pass_transition_k": first_pass["transition_k"],
                    "first_pass_pre_k_window_3": first_pass["pre_k_window_3"],
                    "first_pass_pre_k_window_5": first_pass["pre_k_window_5"],
                    "first_pass_local_window_4": first_pass["local_window_4"],
                }
            )

        window = [e for e in layer_events if first64_pos <= int(e["position"]) <= pass_pos]
        num_k1 = sum(1 for e in window if int(e["transition_k"]) == 1)
        first_pre111 = next((e for e in window if e["pre_k_window_3"] == "1,1,1"), None)
        history_rows.append(
            {
                "trajectory_id": n,
                "n": n,
                "odd_core": odd_core(n),
                "class": cls,
                "first_pass_wait_events": first_pass_wait,
                "num_events_in_64_95_before_pass": len(window),
                "num_stays_64_95_before_pass": sum(1 for e in window if e["to_bin"] == FROM_BIN),
                "k_sequence_before_pass": seq(window, "transition_k"),
                "pre3_sequence_before_pass": seq(window, "pre_k_window_3"),
                "local4_sequence_before_pass": seq(window, "local_window_4"),
                "num_k1_before_pass": num_k1,
                "share_k1_before_pass": num_k1 / len(window),
                "longest_k1_run_before_pass": longest_k1_run(window),
                "has_pre111_before_pass": int(first_pre111 is not None),
                "first_pre111_index_relative_to_entry": int(first_pre111["position"]) - first64_pos if first_pre111 else NA,
                "distance_from_first_pre111_to_pass": pass_pos - int(first_pre111["position"]) if first_pre111 else NA,
                "last_3_k_before_pass": seq(window[-3:], "transition_k"),
                "last_5_k_before_pass": seq(window[-5:], "transition_k"),
                "last_7_k_before_pass": seq(window[-7:], "transition_k"),
            }
        )

        first_32_to_16 = first_after(events, pass_pos, lambda e: e["from_bin"] == "32-63" and e["to_bin"] == "16-31")
        downstream_rows.append(
            {
                "trajectory_id": n,
                "n": n,
                "odd_core": odd_core(n),
                "class": cls,
                "next_3_transition_sequence": seq(events[pass_pos + 1 : pass_pos + 4], "transition"),
                "next_5_transition_sequence": seq(events[pass_pos + 1 : pass_pos + 6], "transition"),
                "steps_to_32_63_to_16_31": steps_after(pass_pos, first_32_to_16),
                "steps_to_below_32": steps_after(pass_pos, first_after(events, pass_pos, lambda e: int(e["remaining_K_after"]) < 32)),
                "steps_to_below_16": steps_after(pass_pos, first_after(events, pass_pos, lambda e: int(e["remaining_K_after"]) < 16)),
                "first_32_63_to_16_31_transition_k": first_32_to_16["transition_k"] if first_32_to_16 else NA,
                "first_32_63_to_16_31_pre_k_window_3": first_32_to_16["pre_k_window_3"] if first_32_to_16 else NA,
            }
        )

        integer_source_rows.append(
            {
                **row,
                "mod8": n % 8,
                "mod16": n % 16,
                "mod32": n % 32,
                "mod64": n % 64,
                "parity_prefix_4": parity_prefix_full(n, 4),
                "parity_prefix_6": parity_prefix_full(n, 6),
                "valuation_prefix_4": raw_pattern(word[:4]),
                "valuation_prefix_6": raw_pattern(word[:6]),
            }
        )

    counts = Counter(r["class"] for r in step1_rows)
    if g0 != 12 or g1 != 538 or counts["A_start"] != 365 or counts["Other_start"] != 66:
        raise RuntimeError(f"unexpected counts: G0={g0}, G1={g1}, classes={counts}")

    write_csv(OUT / "startface_step1_first_pass_table.csv", step1_rows)

    sig_rows: list[dict[str, object]] = []
    sig_defs = [
        ("transition_k", lambda r: str(r["first_pass_transition_k"])),
        ("pre_k_window_3", lambda r: str(r["first_pass_pre_k_window_3"])),
        ("pre_k_window_5", lambda r: str(r["first_pass_pre_k_window_5"])),
        ("local_window_3", lambda r: str(r["first_pass_local_window_3"])),
        ("local_window_4", lambda r: str(r["first_pass_local_window_4"])),
        ("local_window_5", lambda r: str(r["first_pass_local_window_5"])),
        ("transition_k + pre_k_window_3", lambda r: f"{r['first_pass_transition_k']} | {r['first_pass_pre_k_window_3']}"),
        ("transition_k + pre_k_window_5", lambda r: f"{r['first_pass_transition_k']} | {r['first_pass_pre_k_window_5']}"),
        ("transition_k + local_window_4", lambda r: f"{r['first_pass_transition_k']} | {r['first_pass_local_window_4']}"),
    ]
    for feature, getter in sig_defs:
        for value, count in Counter(getter(r) for r in other_signature_source).most_common(20):
            sig_rows.append({"feature": feature, "signature": value, "count": count})
    write_csv(OUT / "startface_step2_other_start_signature_counts.csv", sig_rows)
    write_csv(OUT / "startface_step3_other_start_A_distance.csv", distance_rows)
    write_csv(OUT / "startface_step4_prepass_history.csv", history_rows)

    hist_summary_rows: list[dict[str, object]] = []
    numeric_fields = [
        "first_pass_wait_events",
        "num_events_in_64_95_before_pass",
        "num_stays_64_95_before_pass",
        "num_k1_before_pass",
        "share_k1_before_pass",
        "longest_k1_run_before_pass",
        "has_pre111_before_pass",
        "first_pre111_index_relative_to_entry",
        "distance_from_first_pre111_to_pass",
    ]
    for cls in CLASSES:
        base_row = numeric_summary(history_rows, numeric_fields, cls)
        sub = [r for r in history_rows if r["class"] == cls]
        base_row["top_k_sequence_before_pass"] = top_patterns(sub, "k_sequence_before_pass")
        base_row["top_last_3_k_before_pass"] = top_patterns(sub, "last_3_k_before_pass")
        base_row["top_last_5_k_before_pass"] = top_patterns(sub, "last_5_k_before_pass")
        base_row["top_last_7_k_before_pass"] = top_patterns(sub, "last_7_k_before_pass")
        hist_summary_rows.append(base_row)
    write_csv(OUT / "startface_step4_prepass_history_summary.csv", hist_summary_rows)

    wait_rows: list[dict[str, object]] = []
    for bucket in ["wait_0", "wait_1", "wait_2", "wait_3_5", "wait_6_10", "wait_11_plus"]:
        sub = [r for r in history_rows if wait_bucket(int(r["first_pass_wait_events"])) == bucket]
        a_count = sum(1 for r in sub if r["class"] == "A_start")
        o_count = sum(1 for r in sub if r["class"] == "Other_start")
        wait_rows.append(
            {
                "wait_bucket": bucket,
                "total_count": len(sub),
                "A_start_count": a_count,
                "Other_start_count": o_count,
                "A_start_rate": a_count / len(sub) if sub else math.nan,
                "median_longest_k1_run_before_pass": safe_median([float(r["longest_k1_run_before_pass"]) for r in sub]),
                "share_has_pre111_before_pass": share(sub, lambda r: int(r["has_pre111_before_pass"]) == 1),
                "share_first_pass_transition_k_eq_1": share(
                    [r for r in step1_rows if wait_bucket(int(r["first_pass_wait_events"])) == bucket],
                    lambda r: int(r["first_pass_transition_k"]) == 1,
                ),
                "share_first_pass_pre_k_window_3_111": share(
                    [r for r in step1_rows if wait_bucket(int(r["first_pass_wait_events"])) == bucket],
                    lambda r: r["first_pass_pre_k_window_3"] == "1,1,1",
                ),
                "top_Other_start_signatures_in_bucket": top_other_signatures(
                    [r for r in step1_rows if wait_bucket(int(r["first_pass_wait_events"])) == bucket]
                ),
            }
        )
    write_csv(OUT / "startface_step5_wait_feature_interaction.csv", wait_rows)

    write_csv(OUT / "startface_step6_downstream_comparison.csv", downstream_rows)
    down_summary_rows: list[dict[str, object]] = []
    for cls in CLASSES:
        sub = [r for r in downstream_rows if r["class"] == cls]
        row = numeric_summary(
            downstream_rows,
            ["steps_to_32_63_to_16_31", "steps_to_below_32", "steps_to_below_16"],
            cls,
        )
        row["top_next_3_transition_sequence"] = top_patterns(sub, "next_3_transition_sequence")
        row["top_next_5_transition_sequence"] = top_patterns(sub, "next_5_transition_sequence")
        row["top_first_32_63_to_16_31_k_pre3"] = "; ".join(
            f"k={k}/pre3={pre3}:{count}"
            for (k, pre3), count in Counter(
                (str(r["first_32_63_to_16_31_transition_k"]), str(r["first_32_63_to_16_31_pre_k_window_3"]))
                for r in sub
            ).most_common(8)
        )
        down_summary_rows.append(row)
    write_csv(OUT / "startface_step6_downstream_summary.csv", down_summary_rows)

    int_rows: list[dict[str, object]] = []
    for cls in CLASSES:
        sub = [r for r in integer_source_rows if r["class"] == cls]
        row: dict[str, object] = {
            "class": cls,
            "count": len(sub),
            "distinct_odd_core_count": len({int(r["odd_core"]) for r in sub}),
        }
        for field in ["log2_n", "word_length", "total_K", "first_pass_wait_events"]:
            vals = [float(r[field]) for r in sub]
            row[f"mean_{field}"] = safe_mean(vals)
            row[f"median_{field}"] = safe_median(vals)
        row["share_mod8_eq_7"] = share(sub, lambda r: int(r["mod8"]) == 7)
        row["share_mod16_eq_15"] = share(sub, lambda r: int(r["mod16"]) == 15)
        row["share_mod32_eq_31"] = share(sub, lambda r: int(r["mod32"]) == 31)
        row["share_mod64_eq_63"] = share(sub, lambda r: int(r["mod64"]) == 63)
        row["share_parity_prefix_4_1111"] = share(sub, lambda r: r["parity_prefix_4"] == "1111")
        row["share_parity_prefix_6_111111"] = share(sub, lambda r: r["parity_prefix_6"] == "111111")
        row["share_valuation_prefix_4_1111"] = share(sub, lambda r: r["valuation_prefix_4"] == "1,1,1,1")
        row["share_valuation_prefix_6_111111"] = share(sub, lambda r: r["valuation_prefix_6"] == "1,1,1,1,1,1")
        int_rows.append(row)
    write_csv(OUT / "startface_step7_integer_prefix_summary.csv", int_rows)

    odd_rows: list[dict[str, object]] = []
    for cls in CLASSES:
        sub = [r for r in integer_source_rows if r["class"] == cls]
        odd_rows.append(
            {
                "class": cls,
                "row_count": len(sub),
                "distinct_odd_core_count": len({int(r["odd_core"]) for r in sub}),
                "largest_odd_core_duplicate_groups": duplicate_groups(sub),
                "class_count_after_odd_core_collapse": len({int(r["odd_core"]) for r in sub}),
            }
        )
    write_csv(OUT / "startface_step8_odd_core_collapse.csv", odd_rows)

    other_top = [r for r in sig_rows if r["feature"] == "transition_k + pre_k_window_3"][:8]
    distance_counts = Counter()
    for row in distance_rows:
        for cond in str(row["failed_conditions"]).split("; "):
            if cond:
                distance_counts[cond] += 1
    a_hist = next(r for r in hist_summary_rows if r["class"] == "A_start")
    o_hist = next(r for r in hist_summary_rows if r["class"] == "Other_start")
    a_down = next(r for r in down_summary_rows if r["class"] == "A_start")
    o_down = next(r for r in down_summary_rows if r["class"] == "Other_start")
    a_int = next(r for r in int_rows if r["class"] == "A_start")
    o_int = next(r for r in int_rows if r["class"] == "Other_start")
    a_odd = next(r for r in odd_rows if r["class"] == "A_start")
    o_odd = next(r for r in odd_rows if r["class"] == "Other_start")

    report = [
        "# A_start vs Other_start within START_IN_LAYER first-pass trajectories",
        "",
        "Observational analysis only. Dataset and scanner mode: `original_n_strict`, same 550-trajectory universe as previous reports.",
        "",
        "## Verified counts",
        "",
        f"- total trajectories: `550`",
        f"- G0 never enters `64-95`: `{g0}`",
        f"- G1 enters `64-95`: `{g1}`",
        f"- START_IN_LAYER first-pass rows: `{len(step1_rows)}`",
        f"- A_start: `{counts['A_start']}`",
        f"- Other_start: `{counts['Other_start']}`",
        "",
        "## Dominant Other_start signatures",
        "",
    ]
    for row in other_top:
        report.append(f"- `{row['signature']}`: {row['count']}")
    report.extend(
        [
            "",
            "Failed A-condition counts among Other_start:",
            *[f"- `{cond}`: {count}" for cond, count in distance_counts.most_common()],
            "",
            "## Pre-pass history",
            "",
            f"- A_start median wait: `{fmt(a_hist['first_pass_wait_events_median'])}`; Other_start median wait: `{fmt(o_hist['first_pass_wait_events_median'])}`.",
            f"- A_start median longest k=1 run: `{fmt(a_hist['longest_k1_run_before_pass_median'])}`; Other_start: `{fmt(o_hist['longest_k1_run_before_pass_median'])}`.",
            f"- A_start pre111-before-pass share: `{fmt(a_hist['has_pre111_before_pass_mean'])}`; Other_start: `{fmt(o_hist['has_pre111_before_pass_mean'])}`.",
            f"- Other_start top last-5 k patterns: `{o_hist['top_last_5_k_before_pass']}`.",
            "",
            "## Downstream",
            "",
            f"- A_start median steps to `32-63 -> 16-31`: `{fmt(a_down['steps_to_32_63_to_16_31_median'])}`; Other_start: `{fmt(o_down['steps_to_32_63_to_16_31_median'])}`.",
            f"- A_start top next-5 transition sequence: `{a_down['top_next_5_transition_sequence']}`.",
            f"- Other_start top next-5 transition sequence: `{o_down['top_next_5_transition_sequence']}`.",
            "",
            "## Integer / odd-core",
            "",
            f"- A_start mean/median log2(n): `{fmt(a_int['mean_log2_n'])}` / `{fmt(a_int['median_log2_n'])}`; Other_start: `{fmt(o_int['mean_log2_n'])}` / `{fmt(o_int['median_log2_n'])}`.",
            f"- A_start row/distinct odd_core: `{a_odd['row_count']}` / `{a_odd['distinct_odd_core_count']}`; Other_start: `{o_odd['row_count']}` / `{o_odd['distinct_odd_core_count']}`.",
            "",
            "## Final descriptive answers",
            "",
            "1. Other_start is dominated by a small number of deformations from A_start, especially the route-preserving cases where the pass is START_IN_LAYER but the final k/pre3 face is not `k=1` and `pre111` together.",
            "2. Other_start is not a completely unrelated residual, but it is more heterogeneous than A_start; the signature-count table should be used to separate the main deformations from low-count tails.",
            "3. The dominant failed condition is listed above from `startface_step3_other_start_A_distance.csv`; in this run, failures of the pass-local all-1 context are the main separator.",
            "4. Other_start usually lacks pre111 throughout the pre-pass window in this sample; only a small minority has pre111 earlier before losing it at pass. The history table separates never-developed, earlier-developed, and lost-before-pass cases.",
            "5. Wait time is strongly descriptive but not sufficient alone. Other_start concentrates in short waits, while longer waits are mostly A_start; the cleanest split is wait time plus the final local k/pre3 pattern at pass.",
            "6. Downstream behavior after entering `32-63` is broadly similar at the band level; Other_start mostly continues through the same `32-63` stay corridor and next-boundary timing is close.",
            "7. Other_start has some integer/prefix differences from A_start, but the simple prefix/residue coordinates do not by themselves provide a clean split.",
            "8. Other_start is best treated as a separate START_IN_LAYER pass face family, with a dominant near-A deformation plus a low-count heterogeneous tail.",
            "",
            "## Output files",
            "",
            "- `startface_step1_first_pass_table.csv`",
            "- `startface_step2_other_start_signature_counts.csv`",
            "- `startface_step3_other_start_A_distance.csv`",
            "- `startface_step4_prepass_history.csv`",
            "- `startface_step4_prepass_history_summary.csv`",
            "- `startface_step5_wait_feature_interaction.csv`",
            "- `startface_step6_downstream_comparison.csv`",
            "- `startface_step6_downstream_summary.csv`",
            "- `startface_step7_integer_prefix_summary.csv`",
            "- `startface_step8_odd_core_collapse.csv`",
        ]
    )
    (OUT / "startface_Astart_Otherstart_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(OUT / "startface_Astart_Otherstart_report.md")


if __name__ == "__main__":
    main()
