from __future__ import annotations

import csv
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean, median

import pandas as pd


WORK = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\task-analyze-the-12-trajectories-that\work")
OUT = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\task-analyze-the-12-trajectories-that\outputs")
CLASSIFICATION = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-27\integer-side-projection-of-64-95\outputs\rozier_nonhit_classification.csv"
)
sys.path.insert(0, str(WORK))

from analyze_entry_64_95_boundary import (  # noqa: E402
    event_word_original_n_strict,
    local_windows,
    odd_core,
    parity_prefix_full,
    path_for_word,
    pattern,
    remaining_k_bin,
)

import paradoxical_sequence_analysis as base  # noqa: E402


FROM_BIN = "64-95"
TO_BIN = "32-63"
NA = ""


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def scan_events(n: int) -> tuple[tuple[int, ...], list[dict[str, object]]]:
    word = event_word_original_n_strict(n)
    path = path_for_word(word)
    total = sum(word)
    prefix = 0
    events: list[dict[str, object]] = []
    for pos, k in enumerate(word):
        before = total - prefix
        after = before - k
        from_bin = remaining_k_bin(before)
        to_bin = remaining_k_bin(after)
        pre3 = pattern(word[max(0, pos - 2) : pos + 1])
        route = base.entry_route(path, pos, from_bin)
        local4 = ";".join(local_windows(word, pos, 4))
        is_pass = from_bin == FROM_BIN and to_bin == TO_BIN
        is_a = is_pass and route == "START_IN_LAYER" and k == 1 and pre3 == "1,1,1"
        events.append(
            {
                "position": pos,
                "remaining_K_before": before,
                "remaining_K_after": after,
                "from_bin": from_bin,
                "to_bin": to_bin,
                "transition": f"{from_bin} -> {to_bin}",
                "transition_k": k,
                "entry_route": route,
                "pre_k_window_3": pre3,
                "pre_k_window_5": pattern(word[max(0, pos - 4) : pos + 1]),
                "local_rolling_k_window_4": local4,
                "is_64_95_event": int(from_bin == FROM_BIN),
                "is_64_95_to_32_63_pass": int(is_pass),
                "is_A": int(is_a),
            }
        )
        prefix += k
    return word, events


def longest_k1_run(events: list[dict[str, object]]) -> int:
    best = 0
    cur = 0
    for event in events:
        if int(event["transition_k"]) == 1:
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best


def stats_for_window(events: list[dict[str, object]]) -> dict[str, object]:
    if not events:
        return {
            "num_events": 0,
            "num_stays": 0,
            "num_k1": 0,
            "share_k1": math.nan,
            "longest_k1_run": 0,
            "has_pre111": 0,
            "last_5_k": "",
        }
    num_k1 = sum(1 for e in events if int(e["transition_k"]) == 1)
    return {
        "num_events": len(events),
        "num_stays": sum(1 for e in events if e["from_bin"] == FROM_BIN and e["to_bin"] == FROM_BIN),
        "num_k1": num_k1,
        "share_k1": num_k1 / len(events),
        "longest_k1_run": longest_k1_run(events),
        "has_pre111": int(any(e["pre_k_window_3"] == "1,1,1" for e in events)),
        "last_5_k": ",".join(str(e["transition_k"]) for e in events[-5:]),
    }


def event_fields(prefix: str, event: dict[str, object] | None, include_index: bool = False) -> dict[str, object]:
    out: dict[str, object] = {}
    if include_index:
        out[f"{prefix}_index"] = event["position"] if event else NA
    out[f"{prefix}_transition"] = event["transition"] if event else NA
    out[f"{prefix}_transition_k"] = event["transition_k"] if event else NA
    out[f"{prefix}_entry_route"] = event["entry_route"] if event else NA
    out[f"{prefix}_pre_k_window_3"] = event["pre_k_window_3"] if event else NA
    out[f"{prefix}_local_window_4"] = event["local_rolling_k_window_4"] if event else NA
    return out


def safe_median(values: list[float]) -> float:
    return float(median(values)) if values else math.nan


def safe_mean(values: list[float]) -> float:
    return float(mean(values)) if values else math.nan


def group_summary(label: str, rows: list[dict[str, object]]) -> dict[str, object]:
    waits = [float(r["first_pass_wait_events"]) for r in rows if r["first_pass_wait_events"] != NA]
    stays = [float(r["num_stays_64_95_before_first_pass"]) for r in rows]
    runs = [float(r["longest_k1_run_before_first_pass"]) for r in rows]
    count = len(rows)
    return {
        "group": label,
        "count": count,
        "median_first_pass_wait_events": safe_median(waits),
        "mean_first_pass_wait_events": safe_mean(waits),
        "min_first_pass_wait_events": min(waits) if waits else math.nan,
        "max_first_pass_wait_events": max(waits) if waits else math.nan,
        "median_num_stays_64_95_before_first_pass": safe_median(stays),
        "mean_num_stays_64_95_before_first_pass": safe_mean(stays),
        "median_longest_k1_run_before_first_pass": safe_median(runs),
        "mean_longest_k1_run_before_first_pass": safe_mean(runs),
        "share_has_pre111_before_first_pass": sum(int(r["has_pre111_before_first_pass"]) for r in rows) / count if count else math.nan,
        "share_first_pass_transition_k_eq_1": sum(int(r["first_pass_transition_k"] == 1) for r in rows) / count if count else math.nan,
        "share_first_pass_entry_route_START_IN_LAYER": sum(int(r["first_pass_entry_route"] == "START_IN_LAYER") for r in rows) / count if count else math.nan,
        "share_first_pass_pre_k_window_3_111": sum(int(r["first_pass_pre_k_window_3"] == "1,1,1") for r in rows) / count if count else math.nan,
    }


def wait_bucket(wait: int) -> str:
    if wait == 0:
        return "wait_0"
    if wait == 1:
        return "wait_1"
    if wait == 2:
        return "wait_2"
    if 3 <= wait <= 5:
        return "wait_3_5"
    if 6 <= wait <= 10:
        return "wait_6_10"
    return "wait_11_plus"


def top_patterns(rows: list[dict[str, object]], key: str, limit: int = 10) -> str:
    counts = Counter(str(r[key]) for r in rows if r[key] != NA)
    return "; ".join(f"{pat}:{count}" for pat, count in counts.most_common(limit))


def threshold_row(name: str, rows: list[dict[str, object]], predicate) -> dict[str, object]:
    inside = [r for r in rows if predicate(r)]
    outside = [r for r in rows if not predicate(r)]
    in_rate = sum(int(r["A_hit"]) for r in inside) / len(inside) if inside else math.nan
    out_rate = sum(int(r["A_hit"]) for r in outside) / len(outside) if outside else math.nan
    return {
        "threshold": name,
        "support": len(inside),
        "outside_support": len(outside),
        "A_hit_rate_inside_threshold": in_rate,
        "A_hit_rate_outside_threshold": out_rate,
        "difference": in_rate - out_rate if inside and outside else math.nan,
    }


def fmt(value: object, digits: int = 3) -> str:
    try:
        x = float(value)
    except (TypeError, ValueError):
        return str(value)
    if math.isnan(x):
        return "NA"
    return f"{x:.{digits}f}"


def main() -> None:
    OUT.mkdir(exist_ok=True)
    classified = pd.read_csv(CLASSIFICATION)
    universe = classified[classified["mode"] == "original_n_strict"].copy()
    ids = sorted(int(x) for x in universe["n_original"].unique())
    if len(ids) != 550:
        raise RuntimeError(f"expected 550 trajectories, got {len(ids)}")

    rows: list[dict[str, object]] = []
    first_pass_events: list[dict[str, object]] = []
    timing_rows: list[dict[str, object]] = []
    count_g0 = 0
    count_g1 = 0
    count_a = 0

    for n in ids:
        word, events = scan_events(n)
        layer_events = [e for e in events if e["from_bin"] == FROM_BIN]
        if not layer_events:
            count_g0 += 1
            continue
        count_g1 += 1
        first64 = layer_events[0]
        pass_events = [e for e in layer_events if e["is_64_95_to_32_63_pass"]]
        first_pass = pass_events[0] if pass_events else None
        a_events = [e for e in layer_events if e["is_A"]]
        first_a = a_events[0] if a_events else None
        a_hit = int(first_a is not None)
        count_a += a_hit
        pass_window = [e for e in layer_events if first_pass and int(first64["position"]) <= int(e["position"]) <= int(first_pass["position"])]
        a_window = [e for e in layer_events if first_a and int(first64["position"]) <= int(e["position"]) <= int(first_a["position"])]
        pass_stats = stats_for_window(pass_window)
        a_stats = stats_for_window(a_window) if first_a else None

        row = {
            "trajectory_id": n,
            "n": n,
            "odd_core": odd_core(n),
            "log2_n": math.log2(n),
            "word_length": len(word),
            "total_K": sum(word),
            "first_64_95_index": first64["position"],
            **event_fields("first_64_95", first64),
            "first_pass_index": first_pass["position"] if first_pass else NA,
            "first_pass_wait_events": int(first_pass["position"]) - int(first64["position"]) if first_pass else NA,
            "first_pass_transition_k": first_pass["transition_k"] if first_pass else NA,
            "first_pass_entry_route": first_pass["entry_route"] if first_pass else NA,
            "first_pass_pre_k_window_3": first_pass["pre_k_window_3"] if first_pass else NA,
            "first_pass_local_window_4": first_pass["local_rolling_k_window_4"] if first_pass else NA,
            "first_pass_is_A": int(first_pass["is_A"]) if first_pass else 0,
            "A_hit": a_hit,
            "first_A_index": first_a["position"] if first_a else NA,
            "A_wait_events": int(first_a["position"]) - int(first64["position"]) if first_a else NA,
            "num_events_in_64_95_before_first_pass": pass_stats["num_events"],
            "num_stays_64_95_before_first_pass": pass_stats["num_stays"],
            "num_k1_before_first_pass": pass_stats["num_k1"],
            "share_k1_before_first_pass": pass_stats["share_k1"],
            "longest_k1_run_before_first_pass": pass_stats["longest_k1_run"],
            "has_pre111_before_first_pass": pass_stats["has_pre111"],
            "num_events_in_64_95_before_A": a_stats["num_events"] if a_stats else NA,
            "num_stays_64_95_before_A": a_stats["num_stays"] if a_stats else NA,
            "num_k1_before_A": a_stats["num_k1"] if a_stats else NA,
            "share_k1_before_A": a_stats["share_k1"] if a_stats else NA,
            "longest_k1_run_before_A": a_stats["longest_k1_run"] if a_stats else NA,
            "has_pre111_before_A": a_stats["has_pre111"] if a_stats else NA,
            "last_5_k_before_first_pass": pass_stats["last_5_k"],
            "last_5_k_before_A": a_stats["last_5_k"] if a_stats else NA,
        }
        rows.append(row)

        if first_pass:
            first_pass_events.append(
                {
                    "trajectory_id": n,
                    "A_group": "A_hit" if a_hit else "A_miss",
                    "entry_route": first_pass["entry_route"],
                    "transition_k": first_pass["transition_k"],
                    "pre_k_window_3": first_pass["pre_k_window_3"],
                    "local_window_4": first_pass["local_rolling_k_window_4"],
                    "first_pass_is_A": int(first_pass["is_A"]),
                }
            )
        if first_a:
            passes_before_a = sum(
                1
                for e in layer_events
                if e["is_64_95_to_32_63_pass"] and int(e["position"]) < int(first_a["position"])
            )
            stays_before_a = sum(
                1
                for e in layer_events
                if e["to_bin"] == FROM_BIN and int(e["position"]) < int(first_a["position"])
            )
            timing_rows.append(
                {
                    "trajectory_id": n,
                    "A_wait_events": row["A_wait_events"],
                    "A_wait_minus_first_pass_wait": int(row["A_wait_events"]) - int(row["first_pass_wait_events"]),
                    "first_A_equals_first_pass": int(row["first_A_index"] == row["first_pass_index"]),
                    "A_occurs_before_first_pass": int(int(row["first_A_index"]) < int(row["first_pass_index"])),
                    "A_occurs_after_first_pass": int(int(row["first_A_index"]) > int(row["first_pass_index"])),
                    "num_64_95_to_32_63_passes_before_A": passes_before_a,
                    "num_64_95_stays_before_A": stays_before_a,
                }
            )

    if count_g0 != 12 or count_g1 != 538 or count_a != 365:
        raise RuntimeError(f"unexpected counts: G0={count_g0}, G1={count_g1}, A={count_a}")

    write_csv(OUT / "joint_wait_feature_per_trajectory.csv", rows)

    hit_rows = [r for r in rows if int(r["A_hit"])]
    miss_rows = [r for r in rows if not int(r["A_hit"])]
    summary_rows = [group_summary("A_hit", hit_rows), group_summary("A_miss", miss_rows)]
    write_csv(OUT / "Ahit_vs_Amiss_wait_feature_summary.csv", summary_rows)

    strata_rows: list[dict[str, object]] = []
    bucket_order = ["wait_0", "wait_1", "wait_2", "wait_3_5", "wait_6_10", "wait_11_plus"]
    for bucket in bucket_order:
        sub = [r for r in rows if wait_bucket(int(r["first_pass_wait_events"])) == bucket]
        count = len(sub)
        strata_rows.append(
            {
                "wait_bucket": bucket,
                "trajectory_count": count,
                "A_hit_count": sum(int(r["A_hit"]) for r in sub),
                "A_hit_rate": sum(int(r["A_hit"]) for r in sub) / count if count else math.nan,
                "median_longest_k1_run_before_first_pass": safe_median([float(r["longest_k1_run_before_first_pass"]) for r in sub]),
                "share_has_pre111_before_first_pass": sum(int(r["has_pre111_before_first_pass"]) for r in sub) / count if count else math.nan,
                "share_first_pass_transition_k_eq_1": sum(int(r["first_pass_transition_k"] == 1) for r in sub) / count if count else math.nan,
                "share_first_pass_entry_route_START_IN_LAYER": sum(int(r["first_pass_entry_route"] == "START_IN_LAYER") for r in sub) / count if count else math.nan,
                "share_first_pass_pre_k_window_3_111": sum(int(r["first_pass_pre_k_window_3"] == "1,1,1") for r in sub) / count if count else math.nan,
                "top10_first_pass_pre_k_window_3": top_patterns(sub, "first_pass_pre_k_window_3"),
                "top10_last_5_k_before_first_pass": top_patterns(sub, "last_5_k_before_first_pass"),
            }
        )
    write_csv(OUT / "wait_strata_feature_table.csv", strata_rows)

    sig_rows: list[dict[str, object]] = []
    for group in ["all_G1", "A_hit", "A_miss"]:
        source = first_pass_events if group == "all_G1" else [e for e in first_pass_events if e["A_group"] == group]
        counts = Counter(
            (
                e["entry_route"],
                str(e["transition_k"]),
                e["pre_k_window_3"],
                e["local_window_4"],
                str(e["first_pass_is_A"]),
            )
            for e in source
        )
        for (route, tk, pre3, local4, is_a), count in counts.most_common():
            sig_rows.append(
                {
                    "group": group,
                    "entry_route": route,
                    "transition_k": tk,
                    "pre_k_window_3": pre3,
                    "local_window_4": local4,
                    "first_pass_is_A": is_a,
                    "count": count,
                }
            )
    write_csv(OUT / "first_pass_signature_counts.csv", sig_rows)
    write_csv(OUT / "A_event_timing_summary.csv", timing_rows)

    threshold_rows = [
        threshold_row("longest_k1_run_before_first_pass >= 3", rows, lambda r: int(r["longest_k1_run_before_first_pass"]) >= 3),
        threshold_row("has_pre111_before_first_pass", rows, lambda r: int(r["has_pre111_before_first_pass"]) == 1),
        threshold_row("share_k1_before_first_pass >= 0.5", rows, lambda r: float(r["share_k1_before_first_pass"]) >= 0.5),
        threshold_row("first_pass_transition_k = 1", rows, lambda r: int(r["first_pass_transition_k"]) == 1),
        threshold_row("first_pass_entry_route = START_IN_LAYER", rows, lambda r: r["first_pass_entry_route"] == "START_IN_LAYER"),
    ]
    write_csv(OUT / "feature_threshold_Ahit_rates.csv", threshold_rows)

    amiss_aggregate = Counter(
        (
            r["entry_route"],
            str(r["transition_k"]),
            r["pre_k_window_3"],
            str(r["first_pass_is_A"]),
        )
        for r in first_pass_events
        if r["A_group"] == "A_miss"
    )
    all_timing_equal = sum(int(r["first_A_equals_first_pass"]) for r in timing_rows)
    after_first = sum(int(r["A_occurs_after_first_pass"]) for r in timing_rows)
    before_first = sum(int(r["A_occurs_before_first_pass"]) for r in timing_rows)

    report = [
        "# Joint waiting-time and within-layer feature analysis",
        "",
        "Observational analysis only. Dataset and scanner mode: `original_n_strict`, same 550-trajectory universe as the previous boundary report.",
        "",
        "## Verified counts",
        "",
        f"- total trajectories: `550`",
        f"- G0 never enters `64-95`: `{count_g0}`",
        f"- G1 enters `64-95`: `{count_g1}`",
        f"- A-anywhere among G1: `{count_a}`",
        f"- A-miss among G1: `{len(miss_rows)}`",
        "",
        "## A-hit vs A-miss summary",
        "",
    ]
    for row in summary_rows:
        report.append(
            f"- `{row['group']}` count `{row['count']}`; median first-pass wait `{fmt(row['median_first_pass_wait_events'])}`, mean `{fmt(row['mean_first_pass_wait_events'])}`, min/max `{fmt(row['min_first_pass_wait_events'], 0)}`/`{fmt(row['max_first_pass_wait_events'], 0)}`; median longest k=1 run `{fmt(row['median_longest_k1_run_before_first_pass'])}`; pre111-before-pass share `{fmt(row['share_has_pre111_before_first_pass'])}`; first-pass k=1 share `{fmt(row['share_first_pass_transition_k_eq_1'])}`."
        )
    report.extend(
        [
            "",
            "## Waiting-time strata",
            "",
        ]
    )
    for row in strata_rows:
        report.append(
            f"- `{row['wait_bucket']}`: count `{row['trajectory_count']}`, A-hit rate `{fmt(row['A_hit_rate'])}`, median k=1 run `{fmt(row['median_longest_k1_run_before_first_pass'])}`, pre111 share `{fmt(row['share_has_pre111_before_first_pass'])}`."
        )
    report.extend(
        [
            "",
            "## First-pass timing of A",
            "",
            f"Among A-hit trajectories, first A equals first `64-95 -> 32-63` pass in `{all_timing_equal}/{len(timing_rows)}` rows.",
            f"A before first pass: `{before_first}`. A after first pass: `{after_first}`.",
            "",
            "## Dominant A-miss first-pass signatures",
            "",
        ]
    )
    for (route, tk, pre3, is_a), count in amiss_aggregate.most_common(10):
        report.append(
            f"- route `{route}`, k `{tk}`, pre3 `{pre3}`, first_pass_is_A `{is_a}`: `{count}`"
        )
    report.extend(
        [
            "",
            "## Feature thresholds",
            "",
        ]
    )
    for row in threshold_rows:
        report.append(
            f"- `{row['threshold']}`: support `{row['support']}`, inside A-hit rate `{fmt(row['A_hit_rate_inside_threshold'])}`, outside `{fmt(row['A_hit_rate_outside_threshold'])}`, difference `{fmt(row['difference'])}`."
        )
    report.extend(
        [
            "",
            "## Final descriptive answers",
            "",
            f"1. Trajectories typically wait inside `64-95` for several events before first passing: all-G1 median first-pass wait is `{fmt(group_summary('all', rows)['median_first_pass_wait_events'])}` events and mean is `{fmt(group_summary('all', rows)['mean_first_pass_wait_events'])}`.",
            f"2. In this scanner, A is the first `64-95 -> 32-63` pass whenever it occurs: `{all_timing_equal}/{len(timing_rows)}` A-hit rows have `first_A_index = first_pass_index`.",
            f"3. A-hit trajectories do not wait longer overall in this dataset: median first-pass wait is `{fmt(summary_rows[0]['median_first_pass_wait_events'])}` for A-hit vs `{fmt(summary_rows[1]['median_first_pass_wait_events'])}` for A-miss, and the mean is also lower for A-hit. The wait-strata table is non-monotone: A-hit rate peaks in `wait_6_10` and then drops in `wait_11_plus`.",
            "4. A-hit rows show stronger within-layer all-1 context descriptively: higher pre111-before-pass share and longer k=1 runs than A-miss rows in the summary table.",
            "5. A-miss first passes are recurring non-A signatures. The largest aggregate class is `INFLOW_FROM_96-127`, `transition_k=1`, `pre_k_window_3=1,1,1`, which is non-A because the entry route is not `START_IN_LAYER`; secondary A-miss classes include START_IN_LAYER passes with non-pre111 windows.",
            "6. Waiting time alone does not describe A-hit cleanly. The waiting strata are informative, but the feature thresholds show that local features, especially pre111 and first-pass k=1 / START_IN_LAYER, carry additional separation.",
            "7. In these observations A is best described as a within-layer first-pass signature after a wait/stay period, not an entry signature. It is one pass signature among several, with a distinctive all-1 local face.",
            "",
            "## Output files",
            "",
            "- `joint_wait_feature_per_trajectory.csv`",
            "- `Ahit_vs_Amiss_wait_feature_summary.csv`",
            "- `wait_strata_feature_table.csv`",
            "- `first_pass_signature_counts.csv`",
            "- `A_event_timing_summary.csv`",
            "- `feature_threshold_Ahit_rates.csv`",
        ]
    )
    (OUT / "joint_wait_feature_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(OUT / "joint_wait_feature_report.md")


if __name__ == "__main__":
    main()
