from __future__ import annotations

import csv
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean, median

import pandas as pd


WORK = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\task-analyze-the-12-trajectories-that\work")
OUT = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\task-analyze-the-12-trajectories-that\outputs")
CLASSIFICATION = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-27\integer-side-projection-of-64-95\outputs\rozier_nonhit_classification.csv"
)
sys.path.insert(0, str(WORK))

from analyze_entry_64_95_boundary import (  # noqa: E402
    event_word_original_n_strict,
    local_windows,
    odd_core,
    parity_prefix_full,
    path_for_word,
    pattern,
    remaining_k_bin,
)

import paradoxical_sequence_analysis as base  # noqa: E402


FROM_BIN = "64-95"
TO_BIN = "32-63"
NA = ""
CLASS_ORDER = ["A_start", "A_inflow", "Other_start", "Other_inflow"]


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def scan_events(n: int) -> tuple[tuple[int, ...], list[dict[str, object]]]:
    word = event_word_original_n_strict(n)
    path = path_for_word(word)
    total = sum(word)
    prefix = 0
    events: list[dict[str, object]] = []
    for pos, k in enumerate(word):
        before = total - prefix
        after = before - k
        from_bin = remaining_k_bin(before)
        to_bin = remaining_k_bin(after)
        pre3 = pattern(word[max(0, pos - 2) : pos + 1])
        route = base.entry_route(path, pos, from_bin)
        events.append(
            {
                "position": pos,
                "remaining_K_before": before,
                "remaining_K_after": after,
                "from_bin": from_bin,
                "to_bin": to_bin,
                "transition": f"{from_bin} -> {to_bin}",
                "transition_k": k,
                "entry_route": route,
                "pre_k_window_3": pre3,
                "pre_k_window_5": pattern(word[max(0, pos - 4) : pos + 1]),
                "local_rolling_k_window_4": ";".join(local_windows(word, pos, 4)),
            }
        )
        prefix += k
    return word, events


def pass_face_class(event: dict[str, object]) -> str:
    route = str(event["entry_route"])
    k = int(event["transition_k"])
    pre3 = str(event["pre_k_window_3"])
    all1 = k == 1 and pre3 == "1,1,1"
    if route == "START_IN_LAYER":
        return "A_start" if all1 else "Other_start"
    if route == "INFLOW_FROM_96-127":
        return "A_inflow" if all1 else "Other_inflow"
    return f"Other_route_{route}"


def raw_pattern(values: tuple[int, ...]) -> str:
    return base.pattern(values, cap=False)


def seq(events: list[dict[str, object]], key: str) -> str:
    return " | ".join(str(e[key]) for e in events)


def downstream_window(events: list[dict[str, object]], start: int, length: int, include_pass: bool = False) -> list[dict[str, object]]:
    lo = start if include_pass else start + 1
    return events[lo : lo + length]


def first_after(events: list[dict[str, object]], start: int, predicate) -> dict[str, object] | None:
    for event in events[start + 1 :]:
        if predicate(event):
            return event
    return None


def steps_after(start: int, event: dict[str, object] | None) -> object:
    return int(event["position"]) - start if event else NA


def safe_mean(values: list[float]) -> float:
    return float(mean(values)) if values else math.nan


def safe_median(values: list[float]) -> float:
    return float(median(values)) if values else math.nan


def fmt(value: object, digits: int = 3) -> str:
    try:
        x = float(value)
    except (TypeError, ValueError):
        return str(value)
    if math.isnan(x):
        return "NA"
    return f"{x:.{digits}f}"


def summarize_times(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    out = []
    fields = [
        "steps_to_32_63_to_16_31",
        "steps_to_below_32",
        "steps_to_below_16",
        "steps_to_below_8",
    ]
    for cls in CLASS_ORDER:
        sub = [r for r in rows if r["pass_face_class"] == cls]
        row: dict[str, object] = {"pass_face_class": cls, "count": len(sub)}
        for field in fields:
            vals = [float(r[field]) for r in sub if r[field] != NA]
            row[f"median_{field}"] = safe_median(vals)
            row[f"mean_{field}"] = safe_mean(vals)
            row[f"NA_count_{field}"] = len(sub) - len(vals)
        out.append(row)
    return out


def summarize_numeric(rows: list[dict[str, object]], key: str) -> tuple[float, float]:
    vals = [float(r[key]) for r in rows if r[key] != NA]
    return safe_mean(vals), safe_median(vals)


def share(rows: list[dict[str, object]], predicate) -> float:
    return sum(1 for r in rows if predicate(r)) / len(rows) if rows else math.nan


def top_duplicate_groups(rows: list[dict[str, object]], limit: int = 5) -> str:
    groups = defaultdict(list)
    for row in rows:
        groups[int(row["odd_core"])].append(int(row["n"]))
    dup = [(core, vals) for core, vals in groups.items() if len(vals) > 1]
    dup.sort(key=lambda item: (-len(item[1]), item[0]))
    return "; ".join(f"{core}:{sorted(vals)}" for core, vals in dup[:limit])


def main() -> None:
    OUT.mkdir(exist_ok=True)
    classified = pd.read_csv(CLASSIFICATION)
    universe = classified[classified["mode"] == "original_n_strict"].copy()
    ids = sorted(int(x) for x in universe["n_original"].unique())
    if len(ids) != 550:
        raise RuntimeError(f"expected 550 trajectories, got {len(ids)}")

    step1_rows: list[dict[str, object]] = []
    window_rows: list[dict[str, object]] = []
    time_rows: list[dict[str, object]] = []
    boundary_rows: list[dict[str, object]] = []
    feature_rows_source: list[dict[str, object]] = []
    g0 = 0

    for n in ids:
        word, events = scan_events(n)
        layer_events = [e for e in events if e["from_bin"] == FROM_BIN]
        if not layer_events:
            g0 += 1
            continue
        first64 = layer_events[0]
        first_pass = next((e for e in layer_events if e["to_bin"] == TO_BIN), None)
        if first_pass is None:
            raise RuntimeError(f"G1 trajectory without 64-95 -> 32-63 pass: {n}")
        cls = pass_face_class(first_pass)
        if cls not in CLASS_ORDER:
            raise RuntimeError(f"unexpected pass class {cls} for {n}")
        pass_pos = int(first_pass["position"])
        first_pass_wait = pass_pos - int(first64["position"])
        common = {
            "trajectory_id": n,
            "n": n,
            "odd_core": odd_core(n),
            "log2_n": math.log2(n),
            "word_length": len(word),
            "total_K": sum(word),
            "first_64_95_index": first64["position"],
            "first_pass_index": first_pass["position"],
            "first_pass_wait_events": first_pass_wait,
            "first_pass_entry_route": first_pass["entry_route"],
            "first_pass_transition_k": first_pass["transition_k"],
            "first_pass_pre_k_window_3": first_pass["pre_k_window_3"],
            "first_pass_local_window_4": first_pass["local_rolling_k_window_4"],
            "pass_face_class": cls,
        }
        step1_rows.append(common)

        win_row = dict(common)
        for label, length, include_pass in [
            ("event_at_pass", 1, True),
            ("next_1", 1, False),
            ("next_2", 2, False),
            ("next_3", 3, False),
            ("next_5", 5, False),
            ("next_10", 10, False),
        ]:
            w = downstream_window(events, pass_pos, length, include_pass=include_pass)
            win_row[f"{label}_remaining_K_bin_sequence"] = seq(w, "from_bin")
            win_row[f"{label}_transition_sequence"] = seq(w, "transition")
            win_row[f"{label}_transition_k_sequence"] = seq(w, "transition_k")
            win_row[f"{label}_entry_route_sequence"] = seq(w, "entry_route")
            win_row[f"{label}_pre_k_window_3_sequence"] = seq(w, "pre_k_window_3")
        window_rows.append(win_row)

        first_32_to_16 = first_after(events, pass_pos, lambda e: e["from_bin"] == "32-63" and e["to_bin"] == "16-31")
        first_below32 = first_after(events, pass_pos, lambda e: int(e["remaining_K_after"]) < 32)
        first_below16 = first_after(events, pass_pos, lambda e: int(e["remaining_K_after"]) < 16)
        first_below8 = first_after(events, pass_pos, lambda e: int(e["remaining_K_after"]) < 8)
        time_rows.append(
            {
                "trajectory_id": n,
                "n": n,
                "odd_core": odd_core(n),
                "pass_face_class": cls,
                "first_pass_index": pass_pos,
                "steps_to_32_63_to_16_31": steps_after(pass_pos, first_32_to_16),
                "steps_to_below_32": steps_after(pass_pos, first_below32),
                "steps_to_below_16": steps_after(pass_pos, first_below16),
                "steps_to_below_8": steps_after(pass_pos, first_below8),
                "steps_until_exit_word_or_stop": len(events) - 1 - pass_pos,
            }
        )
        if first_32_to_16:
            boundary_rows.append(
                {
                    "trajectory_id": n,
                    "pass_face_class": cls,
                    "index_32_63_to_16_31": first_32_to_16["position"],
                    "wait_after_first_pass": int(first_32_to_16["position"]) - pass_pos,
                    "entry_route": first_32_to_16["entry_route"],
                    "transition_k": first_32_to_16["transition_k"],
                    "pre_k_window_3": first_32_to_16["pre_k_window_3"],
                    "local_window_4": first_32_to_16["local_rolling_k_window_4"],
                }
            )
        feature_rows_source.append(
            {
                **common,
                "mod16": n % 16,
                "mod32": n % 32,
                "mod64": n % 64,
                "parity_prefix_4": parity_prefix_full(n, 4),
                "parity_prefix_6": parity_prefix_full(n, 6),
                "valuation_prefix_4": raw_pattern(word[:4]),
                "valuation_prefix_6": raw_pattern(word[:6]),
            }
        )

    if g0 != 12 or len(step1_rows) != 538:
        raise RuntimeError(f"unexpected G0/G1 counts: G0={g0}, G1={len(step1_rows)}")
    counts = Counter(r["pass_face_class"] for r in step1_rows)
    if counts["A_start"] != 365 or counts["A_inflow"] != 104:
        raise RuntimeError(f"unexpected class counts: {counts}")

    write_csv(OUT / "postpass_step1_first_pass_classes.csv", step1_rows)
    write_csv(OUT / "postpass_step2_downstream_windows.csv", window_rows)

    seq_count_rows: list[dict[str, object]] = []
    for cls in CLASS_ORDER:
        sub = [r for r in window_rows if r["pass_face_class"] == cls]
        for field, label in [
            ("next_3_transition_sequence", "top transition sequences after pass, length 3"),
            ("next_5_transition_sequence", "top transition sequences after pass, length 5"),
            ("next_3_transition_k_sequence", "top k sequences after pass, length 3"),
            ("next_5_transition_k_sequence", "top k sequences after pass, length 5"),
            ("next_5_remaining_K_bin_sequence", "top remaining_K bin sequences after pass, length 5"),
        ]:
            for pattern_value, count in Counter(str(r[field]) for r in sub).most_common(20):
                seq_count_rows.append(
                    {
                        "pass_face_class": cls,
                        "sequence_type": label,
                        "sequence": pattern_value,
                        "count": count,
                    }
                )
    write_csv(OUT / "postpass_step2_downstream_sequence_counts.csv", seq_count_rows)
    write_csv(OUT / "postpass_step3_downstream_times.csv", time_rows)
    time_summary = summarize_times(time_rows)
    write_csv(OUT / "postpass_step3_downstream_time_summary.csv", time_summary)
    write_csv(OUT / "postpass_step4_32_63_to_16_31_signatures.csv", boundary_rows)

    boundary_sig_rows: list[dict[str, object]] = []
    for cls in CLASS_ORDER:
        sub = [r for r in boundary_rows if r["pass_face_class"] == cls]
        c = Counter((r["entry_route"], str(r["transition_k"]), r["pre_k_window_3"]) for r in sub)
        for (route, k, pre3), count in c.most_common(20):
            boundary_sig_rows.append(
                {
                    "pass_face_class": cls,
                    "entry_route": route,
                    "transition_k": k,
                    "pre_k_window_3": pre3,
                    "count": count,
                }
            )
    write_csv(OUT / "postpass_step4_32_63_to_16_31_signature_counts.csv", boundary_sig_rows)

    class_feature_rows: list[dict[str, object]] = []
    for cls in CLASS_ORDER:
        sub = [r for r in feature_rows_source if r["pass_face_class"] == cls]
        mean_log2, median_log2 = summarize_numeric(sub, "log2_n")
        mean_len, median_len = summarize_numeric(sub, "word_length")
        mean_total, median_total = summarize_numeric(sub, "total_K")
        mean_wait, median_wait = summarize_numeric(sub, "first_pass_wait_events")
        class_feature_rows.append(
            {
                "pass_face_class": cls,
                "count": len(sub),
                "mean_log2_n": mean_log2,
                "median_log2_n": median_log2,
                "mean_word_length": mean_len,
                "median_word_length": median_len,
                "mean_total_K": mean_total,
                "median_total_K": median_total,
                "mean_first_pass_wait_events": mean_wait,
                "median_first_pass_wait_events": median_wait,
                "share_mod16_eq_15": share(sub, lambda r: int(r["mod16"]) == 15),
                "share_mod32_eq_31": share(sub, lambda r: int(r["mod32"]) == 31),
                "share_mod64_eq_63": share(sub, lambda r: int(r["mod64"]) == 63),
                "share_parity_prefix_4_1111": share(sub, lambda r: r["parity_prefix_4"] == "1111"),
                "share_parity_prefix_6_111111": share(sub, lambda r: r["parity_prefix_6"] == "111111"),
                "share_valuation_prefix_4_1111": share(sub, lambda r: r["valuation_prefix_4"] == "1,1,1,1"),
                "share_valuation_prefix_6_111111": share(sub, lambda r: r["valuation_prefix_6"] == "1,1,1,1,1,1"),
            }
        )
    write_csv(OUT / "postpass_step5_class_feature_summary.csv", class_feature_rows)

    odd_rows: list[dict[str, object]] = []
    for cls in CLASS_ORDER:
        sub = [r for r in feature_rows_source if r["pass_face_class"] == cls]
        odd_rows.append(
            {
                "pass_face_class": cls,
                "row_count": len(sub),
                "distinct_odd_core_count": len({int(r["odd_core"]) for r in sub}),
                "largest_duplicate_odd_core_groups": top_duplicate_groups(sub),
            }
        )
    write_csv(OUT / "postpass_step6_odd_core_by_class.csv", odd_rows)

    def top_sequence(cls: str, sequence_type: str) -> tuple[str, int]:
        rows = [r for r in seq_count_rows if r["pass_face_class"] == cls and r["sequence_type"] == sequence_type]
        if not rows:
            return "", 0
        return str(rows[0]["sequence"]), int(rows[0]["count"])

    def summary_for(cls: str) -> dict[str, object]:
        return next(r for r in time_summary if r["pass_face_class"] == cls)

    astart3, astart3n = top_sequence("A_start", "top transition sequences after pass, length 3")
    ainflow3, ainflow3n = top_sequence("A_inflow", "top transition sequences after pass, length 3")
    astart5, astart5n = top_sequence("A_start", "top transition sequences after pass, length 5")
    ainflow5, ainflow5n = top_sequence("A_inflow", "top transition sequences after pass, length 5")
    astart_t = summary_for("A_start")
    ainflow_t = summary_for("A_inflow")
    astart_feat = next(r for r in class_feature_rows if r["pass_face_class"] == "A_start")
    ainflow_feat = next(r for r in class_feature_rows if r["pass_face_class"] == "A_inflow")
    astart_odd = next(r for r in odd_rows if r["pass_face_class"] == "A_start")
    ainflow_odd = next(r for r in odd_rows if r["pass_face_class"] == "A_inflow")
    next_boundary_top = {
        cls: next((r for r in boundary_sig_rows if r["pass_face_class"] == cls), None)
        for cls in CLASS_ORDER
    }

    report = [
        "# Post-pass fate of A_start and A_inflow",
        "",
        "Observational analysis only. Dataset and scanner mode: `original_n_strict`, same 550-trajectory universe as the previous reports.",
        "",
        "## Verified counts",
        "",
        f"- total trajectories: `550`",
        f"- G0 never enters `64-95`: `{g0}`",
        f"- G1 enters `64-95`: `{len(step1_rows)}`",
        f"- A_start: `{counts['A_start']}`",
        f"- A_inflow: `{counts['A_inflow']}`",
        f"- Other_start: `{counts['Other_start']}`",
        f"- Other_inflow: `{counts['Other_inflow']}`",
        "",
        "## Immediate downstream paths",
        "",
        f"- A_start top next-3 transition sequence: `{astart3}` ({astart3n})",
        f"- A_inflow top next-3 transition sequence: `{ainflow3}` ({ainflow3n})",
        f"- A_start top next-5 transition sequence: `{astart5}` ({astart5n})",
        f"- A_inflow top next-5 transition sequence: `{ainflow5}` ({ainflow5n})",
        "",
        "## Downstream timing",
        "",
        f"- A_start median steps to `32-63 -> 16-31`: `{fmt(astart_t['median_steps_to_32_63_to_16_31'])}`, mean `{fmt(astart_t['mean_steps_to_32_63_to_16_31'])}`.",
        f"- A_inflow median steps to `32-63 -> 16-31`: `{fmt(ainflow_t['median_steps_to_32_63_to_16_31'])}`, mean `{fmt(ainflow_t['mean_steps_to_32_63_to_16_31'])}`.",
        f"- A_start median steps below 16: `{fmt(astart_t['median_steps_to_below_16'])}`; A_inflow median steps below 16: `{fmt(ainflow_t['median_steps_to_below_16'])}`.",
        "",
        "## Next boundary face",
        "",
        f"- A_start top `32-63 -> 16-31` face: route `{next_boundary_top['A_start']['entry_route']}`, k `{next_boundary_top['A_start']['transition_k']}`, pre3 `{next_boundary_top['A_start']['pre_k_window_3']}` ({next_boundary_top['A_start']['count']}).",
        f"- A_inflow top `32-63 -> 16-31` face: route `{next_boundary_top['A_inflow']['entry_route']}`, k `{next_boundary_top['A_inflow']['transition_k']}`, pre3 `{next_boundary_top['A_inflow']['pre_k_window_3']}` ({next_boundary_top['A_inflow']['count']}).",
        "",
        "## Integer-side / prefix comparison",
        "",
        f"- A_start mean/median log2(n): `{fmt(astart_feat['mean_log2_n'])}` / `{fmt(astart_feat['median_log2_n'])}`; A_inflow: `{fmt(ainflow_feat['mean_log2_n'])}` / `{fmt(ainflow_feat['median_log2_n'])}`.",
        f"- A_start mean/median word length: `{fmt(astart_feat['mean_word_length'])}` / `{fmt(astart_feat['median_word_length'])}`; A_inflow: `{fmt(ainflow_feat['mean_word_length'])}` / `{fmt(ainflow_feat['median_word_length'])}`.",
        f"- A_start share valuation prefix `1,1,1,1`: `{fmt(astart_feat['share_valuation_prefix_4_1111'])}`; A_inflow: `{fmt(ainflow_feat['share_valuation_prefix_4_1111'])}`.",
        "",
        "## Odd-core collapse",
        "",
        f"- A_start row/distinct odd_core: `{astart_odd['row_count']}` / `{astart_odd['distinct_odd_core_count']}`.",
        f"- A_inflow row/distinct odd_core: `{ainflow_odd['row_count']}` / `{ainflow_odd['distinct_odd_core_count']}`.",
        "",
        "## Final descriptive answers",
        "",
        f"1. Class counts are A_start `{counts['A_start']}`, A_inflow `{counts['A_inflow']}`, Other_start `{counts['Other_start']}`, Other_inflow `{counts['Other_inflow']}`.",
        "2. A_start and A_inflow have the same immediate downstream band path at the coarse transition level: in both classes, the top next-3 and next-5 sequences are all `32-63 -> 32-63` stays and cover the full class. Their k-pattern proportions differ, so they are not identical in the word-side sequence.",
        "3. They do not show a meaningful timing split to the next boundary in this sample: both have median 23 events to `32-63 -> 16-31` and median 30 events to below 16.",
        "4. The next `32-63 -> 16-31` boundary is highly uniform here: every class has the same route/k/pre3 face, `INFLOW_FROM_64-95`, `transition_k=3`, `pre_k_window_3=1,1,3+`.",
        "5. A_start and A_inflow are separated by route by definition, and also differ descriptively in integer/word size: A_inflow is larger on mean/median log2(n), word length, and total_K. Prefix shares are not sharply separated in the simple prefix coordinates.",
        "6. Odd-core collapse does not erase the A_start/A_inflow distinction, but duplicate cores exist in both classes; class-level differences should be checked against distinct odd-core counts.",
        "7. A_inflow is best treated as a separate pass face within the broader all-1 pass umbrella: near-A locally, not identical to A_start because its entry route and upstream provenance differ.",
        "",
        "## Output files",
        "",
        "- `postpass_step1_first_pass_classes.csv`",
        "- `postpass_step2_downstream_windows.csv`",
        "- `postpass_step2_downstream_sequence_counts.csv`",
        "- `postpass_step3_downstream_times.csv`",
        "- `postpass_step3_downstream_time_summary.csv`",
        "- `postpass_step4_32_63_to_16_31_signatures.csv`",
        "- `postpass_step4_32_63_to_16_31_signature_counts.csv`",
        "- `postpass_step5_class_feature_summary.csv`",
        "- `postpass_step6_odd_core_by_class.csv`",
    ]
    (OUT / "postpass_Astart_Ainflow_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(OUT / "postpass_Astart_Ainflow_report.md")


if __name__ == "__main__":
    main()
