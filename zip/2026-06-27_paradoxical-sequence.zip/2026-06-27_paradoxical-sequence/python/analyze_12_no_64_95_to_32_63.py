from __future__ import annotations

import csv
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path

import pandas as pd


BASE_WORK = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\codex-codex-remaining-k-chain-64\work")
CLASSIFICATION = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-27\integer-side-projection-of-64-95\outputs\rozier_nonhit_classification.csv"
)
OUT = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\task-analyze-the-12-trajectories-that\outputs")
sys.path.insert(0, str(BASE_WORK))

import paradoxical_sequence_analysis as base  # noqa: E402


FROM_BIN = "64-95"
TO_BIN = "32-63"


def v2(n: int) -> int:
    return (n & -n).bit_length() - 1


def next_odd(n: int) -> tuple[int, int]:
    raw = 3 * n + 1
    k = v2(raw)
    return raw >> k, k


def odd_core(n: int) -> int:
    return n >> v2(n)


def odd_word_to_one(n: int) -> tuple[int, ...]:
    cur = odd_core(n)
    word: list[int] = []
    while cur != 1:
        cur, k = next_odd(cur)
        word.append(k)
        if len(word) > 100_000:
            raise RuntimeError(f"long trajectory: {n}")
    return tuple(word)


def event_word_original_n_strict(n: int) -> tuple[int, ...]:
    init = v2(n)
    tail = odd_word_to_one(n)
    return ((init,) if init else tuple()) + tail


def remaining_k_bin(value: int) -> str:
    return base.remaining_k_bin(value)[1]


def pattern(values: tuple[int, ...]) -> str:
    return base.pattern(values, cap=True)


def path_for_word(word: tuple[int, ...]) -> list[str]:
    total = sum(word)
    prefix = 0
    path = []
    for k in word:
        path.append(remaining_k_bin(total - prefix))
        prefix += k
    return path


def local_windows(word: tuple[int, ...], pos: int, width: int) -> tuple[str, ...]:
    out = set()
    last_start = max(0, len(word) - width)
    for start in range(max(0, pos - width + 1), min(pos, last_start) + 1):
        out.add(pattern(word[start : start + width]))
    return tuple(sorted(out))


def scan_events(n: int) -> list[dict[str, object]]:
    word = event_word_original_n_strict(n)
    path = path_for_word(word)
    total = sum(word)
    prefix = 0
    rows: list[dict[str, object]] = []
    for pos, k in enumerate(word):
        before = total - prefix
        after = before - k
        from_bin = remaining_k_bin(before)
        to_bin = remaining_k_bin(after)
        row = {
            "trajectory": n,
            "position": pos,
            "word_length": len(word),
            "remaining_K_before": before,
            "remaining_K_after": after,
            "from_bin": from_bin,
            "to_bin": to_bin,
            "transition": f"{from_bin} -> {to_bin}",
            "entry_route": base.entry_route(path, pos, from_bin),
            "transition_k": k,
            "transition_k_cat": base.kcat(k),
            "pre_k_window_3": pattern(word[max(0, pos - 2) : pos + 1]),
            "local_rolling_k_window_4": ";".join(local_windows(word, pos, 4)),
            "is_target_transition": int(from_bin == FROM_BIN and to_bin == TO_BIN),
        }
        rows.append(row)
        prefix += k
    return rows


def lcs_len(a: tuple[str, ...], b: tuple[str, ...]) -> int:
    prev = [0] * (len(b) + 1)
    for av in a:
        cur = [0]
        for j, bv in enumerate(b, 1):
            cur.append(prev[j - 1] + 1 if av == bv else max(prev[j], cur[-1]))
        prev = cur
    return prev[-1]


def common_prefix_len(a: tuple[str, ...], b: tuple[str, ...]) -> int:
    out = 0
    for av, bv in zip(a, b):
        if av != bv:
            break
        out += 1
    return out


def common_suffix_len(a: tuple[str, ...], b: tuple[str, ...]) -> int:
    return common_prefix_len(tuple(reversed(a)), tuple(reversed(b)))


def seqs_for(events: list[dict[str, object]]) -> dict[str, tuple[str, ...]]:
    band_state = tuple([str(e["from_bin"]) for e in events] + [str(events[-1]["to_bin"])])
    return {
        "remaining_K_band_sequence": band_state,
        "entry_route_sequence": tuple(str(e["entry_route"]) for e in events),
        "transition_k_sequence": tuple(str(e["transition_k"]) for e in events),
        "pre_k_window_3_sequence": tuple(str(e["pre_k_window_3"]) for e in events),
        "local_rolling_k_window_4_sequence": tuple(str(e["local_rolling_k_window_4"]) for e in events),
    }


def best_near_a_anchor(events: list[dict[str, object]]) -> tuple[int | None, int, str]:
    best_pos = None
    best_score = -1
    for e in events:
        if e["from_bin"] != FROM_BIN:
            continue
        score = 1
        score += int(e["entry_route"] == "START_IN_LAYER")
        score += int(e["transition_k"] == 1)
        score += int(e["pre_k_window_3"] == "1,1,1")
        if score > best_score:
            best_score = score
            best_pos = int(e["position"])
    if best_pos is not None:
        return best_pos, max(best_score, 0), "best_64_95_occurrence"
    if not events:
        return None, 0, "no_events"
    # If the trajectory never enters 64-95, anchor at the highest remaining_K
    # event: this is the closest available before-region to the absent A layer.
    best = max(events, key=lambda e: (int(e["remaining_K_before"]), -int(e["position"])))
    return int(best["position"]), 0, "highest_remaining_K_no_64_95"


def abrupt_label(before: dict[str, object] | None, during: dict[str, object], after: dict[str, object] | None) -> str:
    notes = []
    if before is not None and before["to_bin"] != during["to_bin"]:
        notes.append(f"pre_to_anchor_to_bin {before['to_bin']}->{during['to_bin']}")
    if after is not None and during["to_bin"] != after["to_bin"]:
        notes.append(f"anchor_to_post_to_bin {during['to_bin']}->{after['to_bin']}")
    if before is not None and before["transition_k"] != during["transition_k"]:
        notes.append(f"pre_to_anchor_k {before['transition_k']}->{during['transition_k']}")
    if after is not None and during["transition_k"] != after["transition_k"]:
        notes.append(f"anchor_to_post_k {during['transition_k']}->{after['transition_k']}")
    return "; ".join(notes)


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    OUT.mkdir(exist_ok=True)
    classified = pd.read_csv(CLASSIFICATION)
    target = classified[(classified["mode"] == "original_n_strict") & (classified["hits_64_95_to_32_63"] == 0)].copy()
    target = target.sort_values("n_original")
    ids = [int(x) for x in target["n_original"]]
    if len(ids) != 12:
        raise RuntimeError(f"expected 12 original_n_strict no-hit trajectories, got {len(ids)}: {ids}")

    by_id = {n: scan_events(n) for n in ids}
    all_events = [row for n in ids for row in by_id[n]]
    write_csv(OUT / "no_64_95_to_32_63_events.csv", all_events)

    verify_rows = []
    for n in ids:
        events = by_id[n]
        target_hits = [e for e in events if e["is_target_transition"]]
        verify_rows.append(
            {
                "trajectory": n,
                "word_length": len(events),
                "K_tau": sum(int(e["transition_k"]) for e in events),
                "contains_64_95_to_32_63": int(bool(target_hits)),
                "target_hit_count": len(target_hits),
            }
        )
    write_csv(OUT / "step1_verified_exclusion.csv", verify_rows)

    seq_rows = []
    seqs = {}
    for n in ids:
        seqs[n] = seqs_for(by_id[n])
        row = {"trajectory": n}
        for key, seq in seqs[n].items():
            row[key] = " | ".join(seq)
        seq_rows.append(row)
    write_csv(OUT / "step2_trajectory_sequences.csv", seq_rows)

    compare_rows = []
    features = list(next(iter(seqs.values())).keys())
    for i, a in enumerate(ids):
        for b in ids[i + 1 :]:
            row = {"trajectory_a": a, "trajectory_b": b}
            for feature in features:
                sa = seqs[a][feature]
                sb = seqs[b][feature]
                row[f"{feature}_identical"] = int(sa == sb)
                row[f"{feature}_lcs_len"] = lcs_len(sa, sb)
                row[f"{feature}_common_prefix_len"] = common_prefix_len(sa, sb)
                row[f"{feature}_common_suffix_len"] = common_suffix_len(sa, sb)
            compare_rows.append(row)
    write_csv(OUT / "step2_pairwise_raw_comparison.csv", compare_rows)

    identical_rows = []
    for feature in features:
        groups = defaultdict(list)
        for n in ids:
            groups[seqs[n][feature]].append(n)
        for seq, members in groups.items():
            if len(members) > 1:
                identical_rows.append({"feature": feature, "members": ",".join(map(str, members)), "sequence": " | ".join(seq)})
    write_csv(OUT / "step2_identical_sequences.csv", identical_rows)

    transition_counts = Counter(str(e["transition"]) for e in all_events)
    transition_rows = [
        {"transition": tr, "frequency": count}
        for tr, count in sorted(transition_counts.items(), key=lambda item: (-item[1], item[0]))
    ]
    write_csv(OUT / "step3_transition_frequencies.csv", transition_rows)

    cluster_groups = defaultdict(list)
    for n in ids:
        profile = (
            seqs[n]["transition_k_sequence"],
            seqs[n]["entry_route_sequence"],
            seqs[n]["pre_k_window_3_sequence"],
            seqs[n]["local_rolling_k_window_4_sequence"],
        )
        cluster_groups[profile].append(n)
    cluster_rows = []
    for idx, (profile, members) in enumerate(cluster_groups.items(), 1):
        cluster_rows.append(
            {
                "cluster_id": f"C{idx}",
                "size": len(members),
                "members": ",".join(map(str, members)),
                "transition_k_profile": " | ".join(profile[0]),
                "entry_route_profile": " | ".join(profile[1]),
                "pre_k_window_3_profile": " | ".join(profile[2]),
                "local_window_profile": " | ".join(profile[3]),
            }
        )
    write_csv(OUT / "step4_signature_clusters.csv", cluster_rows)

    near_rows = []
    for n in ids:
        events = by_id[n]
        reaches = any(e["from_bin"] == FROM_BIN for e in events)
        start = any(e["from_bin"] == FROM_BIN and e["entry_route"] == "START_IN_LAYER" for e in events)
        tk1 = any(e["from_bin"] == FROM_BIN and e["transition_k"] == 1 for e in events)
        pre111 = any(e["from_bin"] == FROM_BIN and e["pre_k_window_3"] == "1,1,1" for e in events)
        conditions = {
            "reaches 64-95": reaches,
            "START_IN_LAYER": start,
            "transition_k = 1": tk1,
            "pre_k_window_3 = (1,1,1)": pre111,
        }
        missing = [name for name, ok in conditions.items() if not ok]
        near_rows.append(
            {
                "trajectory": n,
                "conditions_satisfied": sum(conditions.values()),
                "missing_conditions": "; ".join(missing) if missing else "",
                "reaches_64_95": int(reaches),
                "START_IN_LAYER": int(start),
                "transition_k_1": int(tk1),
                "pre_k_window_3_111": int(pre111),
            }
        )
    near_rows.sort(key=lambda r: (-int(r["conditions_satisfied"]), int(r["trajectory"])))
    write_csv(OUT / "step5_near_A_distance.csv", near_rows)

    time_rows = []
    time_summary = []
    for n in ids:
        events = by_id[n]
        anchor, score, anchor_type = best_near_a_anchor(events)
        if anchor is None:
            continue
        lo = max(0, anchor - 3)
        hi = min(len(events) - 1, anchor + 3)
        for pos in range(lo, hi + 1):
            e = events[pos]
            phase = "during" if pos == anchor else ("before" if pos < anchor else "after")
            time_rows.append(
                {
                    "trajectory": n,
                    "anchor_position": anchor,
                    "anchor_type": anchor_type,
                    "phase": phase,
                    "position": pos,
                    "remaining_K_before": e["remaining_K_before"],
                    "remaining_K_after": e["remaining_K_after"],
                    "from_bin": e["from_bin"],
                    "to_bin": e["to_bin"],
                    "transition_k": e["transition_k"],
                    "entry_route": e["entry_route"],
                    "pre_k_window_3": e["pre_k_window_3"],
                    "local_rolling_k_window_4": e["local_rolling_k_window_4"],
                }
            )
        before = events[anchor - 1] if anchor > 0 else None
        during = events[anchor]
        after = events[anchor + 1] if anchor + 1 < len(events) else None
        time_summary.append(
            {
                "trajectory": n,
                "anchor_position": anchor,
                "anchor_type": anchor_type,
                "anchor_near_A_score": score,
                "anchor_transition": during["transition"],
                "anchor_transition_k": during["transition_k"],
                "anchor_entry_route": during["entry_route"],
                "anchor_pre_k_window_3": during["pre_k_window_3"],
                "observed_before_during_after_change": abrupt_label(before, during, after),
            }
        )
    write_csv(OUT / "step6_time_order_windows.csv", time_rows)
    write_csv(OUT / "step6_time_order_summary.csv", time_summary)

    no_multi_clusters = all(row["size"] == 1 for row in cluster_rows)
    dominant_missing = Counter()
    for row in near_rows:
        for missing in str(row["missing_conditions"]).split("; "):
            if missing:
                dominant_missing[missing] += 1

    report = [
        "# Twelve trajectories with no 64-95 -> 32-63 transition",
        "",
        "Observational pass only. Event definitions are the prior remaining_K scanner definitions, using the `original_n_strict` mode because that reproduces the expected 12-count exclusion set.",
        "",
        "## Step 1. Verified exclusion",
        "",
        f"Count: {len(ids)} trajectories.",
        "",
        ", ".join(map(str, ids)),
        "",
        "Every listed trajectory has `target_hit_count = 0` in `step1_verified_exclusion.csv`.",
        "",
        "## Step 2. Raw sequence and pairwise outputs",
        "",
        "- `step2_trajectory_sequences.csv` contains the full per-trajectory sequences.",
        "- `step2_pairwise_raw_comparison.csv` contains all 66 pairwise comparisons with identity, LCS length, common-prefix length, and common-suffix length for every requested sequence family.",
        "- `step2_identical_sequences.csv` contains only exact repeated sequences.",
        "",
        "## Step 3. Alternative transition frequencies",
        "",
    ]
    for row in transition_rows[:20]:
        report.append(f"- `{row['transition']}`: {row['frequency']}")
    report.extend(
        [
            "",
            "## Step 4. Signature clustering",
            "",
        ]
    )
    if no_multi_clusters:
        report.append("Every trajectory is unique under the combined transition_k / entry_route / pre_k_window_3 / local-window profile.")
    else:
        for row in cluster_rows:
            if row["size"] > 1:
                report.append(f"- `{row['cluster_id']}` size {row['size']}: {row['members']}")
    report.extend(
        [
            "",
            "## Step 5. Near-A distance",
            "",
        ]
    )
    for row in near_rows:
        missing = row["missing_conditions"] or "none"
        report.append(f"- `{row['trajectory']}`: {row['conditions_satisfied']}/4; missing {missing}")
    report.extend(
        [
            "",
            "Missing-condition counts:",
        ]
    )
    for name, count in dominant_missing.most_common():
        report.append(f"- `{name}`: {count}")
    report.extend(
        [
            "",
            "## Step 6. Time-order comparison",
            "",
            "`step6_time_order_windows.csv` gives before/during/after windows around the best available A-region anchor. In this run every anchor is `highest_remaining_K_no_64_95`, because no trajectory enters the `64-95` band. `step6_time_order_summary.csv` gives the compact observed change labels.",
            "",
            "## Final descriptive answers",
            "",
            "1. The 12 share a broad exclusion fact rather than a common alternative corridor: all remain below `64-95`. The dominant observed movement is repeated `32-63 -> 32-63` stay behavior among the longer cases, not a replacement `64-95` corridor.",
            "2. They are fundamentally different from A under the requested four-condition distance: every trajectory scores 0/4 because none reaches `64-95` at all.",
            "3. The dominating missing condition is `reaches 64-95`; once that is absent, `START_IN_LAYER`, `transition_k = 1`, and `pre_k_window_3 = (1,1,1)` at `64-95` are also absent for all 12.",
            "4. There is no evidence here of a second canonical signature. The combined signature profiles are all singleton clusters in this 12-trajectory set.",
            "5. The set is heterogeneous under the requested clustering. It is structurally coherent only in the coarse sense that all 12 never enter the A source band.",
            "",
        ]
    )
    (OUT / "no_64_95_to_32_63_report.md").write_text("\n".join(report), encoding="utf-8")
    print(OUT / "no_64_95_to_32_63_report.md")


if __name__ == "__main__":
    main()
