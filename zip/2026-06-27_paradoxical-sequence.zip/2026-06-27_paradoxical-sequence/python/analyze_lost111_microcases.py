from __future__ import annotations

import csv
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean, median

import pandas as pd


WORK = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\task-analyze-the-12-trajectories-that\work")
OUT = Path(r"C:\Users\yauki\Documents\Codex\2026-06-27\task-analyze-the-12-trajectories-that\outputs")
CLASSIFICATION = Path(
    r"C:\Users\yauki\Documents\Codex\2026-06-27\integer-side-projection-of-64-95\outputs\rozier_nonhit_classification.csv"
)
sys.path.insert(0, str(WORK))

from analyze_entry_64_95_boundary import (  # noqa: E402
    event_word_original_n_strict,
    local_windows,
    odd_core,
    path_for_word,
    pattern,
    remaining_k_bin,
)

import paradoxical_sequence_analysis as base  # noqa: E402


FROM_BIN = "64-95"
TO_BIN = "32-63"
NA = ""


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def scan_events(n: int) -> tuple[tuple[int, ...], list[dict[str, object]]]:
    word = event_word_original_n_strict(n)
    path = path_for_word(word)
    total = sum(word)
    prefix = 0
    events: list[dict[str, object]] = []
    for pos, k in enumerate(word):
        before = total - prefix
        after = before - k
        from_bin = remaining_k_bin(before)
        to_bin = remaining_k_bin(after)
        route = base.entry_route(path, pos, from_bin)
        events.append(
            {
                "position": pos,
                "remaining_K": before,
                "remaining_K_after": after,
                "remaining_K_bin": from_bin,
                "from_bin": from_bin,
                "to_bin": to_bin,
                "transition": f"{from_bin} -> {to_bin}",
                "transition_k": k,
                "entry_route": route,
                "pre_k_window_3": pattern(word[max(0, pos - 2) : pos + 1]),
                "pre_k_window_5": pattern(word[max(0, pos - 4) : pos + 1]),
                "local_window_4": ";".join(local_windows(word, pos, 4)),
            }
        )
        prefix += k
    return word, events


def pass_face_class(event: dict[str, object]) -> str:
    route = str(event["entry_route"])
    all1_pass = int(event["transition_k"]) == 1 and event["pre_k_window_3"] == "1,1,1"
    if route == "START_IN_LAYER":
        return "A_start" if all1_pass else "Other_start"
    if route == "INFLOW_FROM_96-127":
        return "A_inflow" if all1_pass else "Other_inflow"
    return f"Other_route_{route}"


def current_run_lengths(window: list[dict[str, object]]) -> list[tuple[int, int]]:
    cur = 0
    best = 0
    out = []
    for event in window:
        if int(event["transition_k"]) == 1:
            cur += 1
        else:
            cur = 0
        best = max(best, cur)
        out.append((cur, best))
    return out


def window_for(events: list[dict[str, object]]) -> tuple[list[dict[str, object]], dict[str, object], dict[str, object]]:
    layer = [e for e in events if e["from_bin"] == FROM_BIN]
    first64 = layer[0]
    first_pass = next(e for e in layer if e["to_bin"] == TO_BIN)
    lo = int(first64["position"])
    hi = int(first_pass["position"])
    return [e for e in layer if lo <= int(e["position"]) <= hi], first64, first_pass


def timeline_rows(n: int, cls: str, window: list[dict[str, object]]) -> list[dict[str, object]]:
    runs = current_run_lengths(window)
    rows = []
    for idx, (event, (cur, best)) in enumerate(zip(window, runs)):
        rows.append(
            {
                "trajectory_id": n,
                "class": cls,
                "event_index": idx,
                "global_position": event["position"],
                "remaining_K": event["remaining_K"],
                "remaining_K_bin": event["remaining_K_bin"],
                "transition": event["transition"],
                "transition_k": event["transition_k"],
                "entry_route": event["entry_route"],
                "pre_k_window_3": event["pre_k_window_3"],
                "pre_k_window_5": event["pre_k_window_5"],
                "local_window_4": event["local_window_4"],
                "current_k1_run": cur,
                "longest_k1_run_so_far": best,
                "currently_111": "yes" if cur >= 3 else "no",
                "currently_1111": "yes" if cur >= 4 else "no",
                "is_pass_event": int(idx == len(window) - 1),
            }
        )
    return rows


def first_index(rows: list[dict[str, object]], pred) -> int | None:
    for row in rows:
        if pred(row):
            return int(row["event_index"])
    return None


def first_break_after_111(rows: list[dict[str, object]], formation_idx: int) -> int | None:
    for row in rows:
        idx = int(row["event_index"])
        if idx > formation_idx and row["currently_111"] == "no":
            return idx
    return None


def classify_break(prev_row: dict[str, object], break_row: dict[str, object]) -> str:
    cur_pre3 = str(break_row["pre_k_window_3"])
    if cur_pre3 in {"2,1,1", "3+,1,1", "1,1,2", "1,1,3+"}:
        return f"111 -> {cur_pre3}"
    if "1,1,1" in str(break_row["local_window_4"]).split(";"):
        return f"111 left pre3 but remains local4 ({cur_pre3})"
    if int(break_row["transition_k"]) != 1:
        return f"break_by_k={break_row['transition_k']} ({cur_pre3})"
    if str(prev_row["pre_k_window_3"]) == "1,1,1":
        return f"window_shift ({cur_pre3})"
    return f"other ({cur_pre3})"


def raw_seq(rows: list[dict[str, object]], key: str, limit: int = 10) -> str:
    return " | ".join(str(r[key]) for r in rows[-limit:])


def prefix_len(a: list[dict[str, object]], b: list[dict[str, object]], keys: list[str]) -> int:
    out = 0
    for ar, br in zip(a, b):
        if any(str(ar[k]) != str(br[k]) for k in keys):
            break
        out += 1
    return out


def suffix_len(a: list[dict[str, object]], b: list[dict[str, object]], keys: list[str]) -> int:
    return prefix_len(list(reversed(a)), list(reversed(b)), keys)


def first_diff(a: list[dict[str, object]], b: list[dict[str, object]], keys: list[str]) -> tuple[int | None, str]:
    for idx, (ar, br) in enumerate(zip(a, b)):
        for key in keys:
            if str(ar[key]) != str(br[key]):
                return idx, key
    if len(a) != len(b):
        return min(len(a), len(b)), "length"
    return None, ""


def match_score(lost: dict[str, object], keep: dict[str, object], scales: dict[str, float]) -> float:
    exact_bonus = -5.0 if int(lost["odd_core"]) == int(keep["odd_core"]) else 0.0
    fields = ["log2_n", "total_K", "first_pass_wait", "word_length"]
    return exact_bonus + sum(abs(float(lost[f]) - float(keep[f])) / scales[f] for f in fields)


def fmt(value: object, digits: int = 3) -> str:
    try:
        x = float(value)
    except (TypeError, ValueError):
        return str(value)
    if math.isnan(x):
        return "NA"
    return f"{x:.{digits}f}"


def main() -> None:
    OUT.mkdir(exist_ok=True)
    classified = pd.read_csv(CLASSIFICATION)
    ids = sorted(int(x) for x in classified[classified["mode"] == "original_n_strict"]["n_original"].unique())
    records: dict[int, dict[str, object]] = {}

    for n in ids:
        word, events = scan_events(n)
        if not any(e["from_bin"] == FROM_BIN for e in events):
            continue
        window, first64, first_pass = window_for(events)
        cls = pass_face_class(first_pass)
        if cls not in {"A_start", "Other_start"}:
            continue
        rows = timeline_rows(n, cls, window)
        first111 = first_index(rows, lambda r: r["currently_111"] == "yes")
        lost111 = False
        break_idx = None
        if first111 is not None and rows[-1]["currently_111"] == "no":
            break_idx = first_break_after_111(rows, first111)
            lost111 = break_idx is not None
        records[n] = {
            "trajectory_id": n,
            "n": n,
            "odd_core": odd_core(n),
            "class": cls,
            "word_length": len(word),
            "total_K": sum(word),
            "log2_n": math.log2(n),
            "first_64_95_index": first64["position"],
            "first_pass_index": first_pass["position"],
            "first_pass_wait": int(first_pass["position"]) - int(first64["position"]),
            "first_pass_transition_k": first_pass["transition_k"],
            "first_pass_pre3": first_pass["pre_k_window_3"],
            "first111_index": first111 if first111 is not None else NA,
            "break_index": break_idx if break_idx is not None else NA,
            "lost111": int(lost111),
            "timeline": rows,
        }

    lost = [r for r in records.values() if r["class"] == "Other_start" and int(r["lost111"]) == 1]
    keep_candidates = [r for r in records.values() if r["class"] == "A_start"]
    if len(lost) != 8:
        raise RuntimeError(f"expected 8 Lost111 trajectories, got {len(lost)}")

    scales = {}
    for field in ["log2_n", "total_K", "first_pass_wait", "word_length"]:
        vals = [float(r[field]) for r in keep_candidates + lost]
        scales[field] = max(max(vals) - min(vals), 1.0)

    matches = []
    used_keep = set()
    for lr in sorted(lost, key=lambda r: int(r["n"])):
        pool = [k for k in keep_candidates if int(k["n"]) not in used_keep]
        best = min(pool, key=lambda k: match_score(lr, k, scales))
        used_keep.add(int(best["n"]))
        matches.append((lr, best, match_score(lr, best, scales)))

    selected_timeline: list[dict[str, object]] = []
    for lr, kr, _score in matches:
        for group, rec in [("Lost111", lr), ("Keep111", kr)]:
            for row in rec["timeline"]:
                enriched = {"comparison_group": group, **row}
                selected_timeline.append(enriched)
    write_csv(OUT / "lost111_step1_full_timeline.csv", selected_timeline)

    break_rows = []
    for lr in lost:
        rows = lr["timeline"]
        formation_idx = int(lr["first111_index"])
        break_idx = int(lr["break_index"])
        pass_idx = len(rows) - 1
        break_rows.append(
            {
                "trajectory_id": lr["n"],
                "formation_event_index": formation_idx,
                "break_event_index": break_idx,
                "pass_event_index": pass_idx,
                "distance_formation_to_break": break_idx - formation_idx,
                "distance_break_to_pass": pass_idx - break_idx,
                "formation_pre3": rows[formation_idx]["pre_k_window_3"],
                "break_pre3": rows[break_idx]["pre_k_window_3"],
                "pass_pre3": rows[pass_idx]["pre_k_window_3"],
                "formation_transition_k": rows[formation_idx]["transition_k"],
                "break_transition_k": rows[break_idx]["transition_k"],
                "pass_transition_k": rows[pass_idx]["transition_k"],
                "break_category": classify_break(rows[break_idx - 1], rows[break_idx]),
            }
        )
    write_csv(OUT / "lost111_step2_break_events.csv", break_rows)

    category_rows = [
        {"break_category": cat, "count": count}
        for cat, count in Counter(r["break_category"] for r in break_rows).most_common()
    ]
    write_csv(OUT / "lost111_step3_break_category_counts.csv", category_rows)

    pair_rows = []
    diff_rows = []
    keys = ["transition_k", "pre_k_window_3", "remaining_K_bin", "entry_route", "local_window_4"]
    for pair_id, (lr, kr, score) in enumerate(matches, 1):
        lt = lr["timeline"]
        kt = kr["timeline"]
        pfx = prefix_len(lt, kt, keys)
        sfx = suffix_len(lt, kt, keys)
        diff_idx, diff_key = first_diff(lt, kt, keys)
        pair_rows.append(
            {
                "pair_id": pair_id,
                "lost_trajectory": lr["n"],
                "keep_trajectory": kr["n"],
                "lost_odd_core": lr["odd_core"],
                "keep_odd_core": kr["odd_core"],
                "match_score": score,
                "abs_log2_n": abs(float(lr["log2_n"]) - float(kr["log2_n"])),
                "abs_total_K": abs(float(lr["total_K"]) - float(kr["total_K"])),
                "abs_first_pass_wait": abs(float(lr["first_pass_wait"]) - float(kr["first_pass_wait"])),
                "abs_word_length": abs(float(lr["word_length"]) - float(kr["word_length"])),
                "lost_last10_k": raw_seq(lt, "transition_k"),
                "keep_last10_k": raw_seq(kt, "transition_k"),
                "lost_last10_pre3": raw_seq(lt, "pre_k_window_3"),
                "keep_last10_pre3": raw_seq(kt, "pre_k_window_3"),
                "lost_last10_local4": raw_seq(lt, "local_window_4"),
                "keep_last10_local4": raw_seq(kt, "local_window_4"),
                "lost_last10_remaining_K_bins": raw_seq(lt, "remaining_K_bin"),
                "keep_last10_remaining_K_bins": raw_seq(kt, "remaining_K_bin"),
                "largest_identical_prefix": pfx,
                "largest_identical_suffix": sfx,
                "first_differing_event": diff_idx if diff_idx is not None else NA,
                "field_responsible": diff_key,
            }
        )
        diff_rows.append(
            {
                "pair_id": pair_id,
                "lost_trajectory": lr["n"],
                "keep_trajectory": kr["n"],
                "largest_identical_suffix": sfx,
                "largest_identical_prefix": pfx,
                "first_differing_event": diff_idx if diff_idx is not None else NA,
                "field_responsible": diff_key,
                "transition_k": int(diff_key == "transition_k"),
                "pre3": int(diff_key == "pre_k_window_3"),
                "remaining_K": int(diff_key == "remaining_K_bin"),
                "route": int(diff_key == "entry_route"),
                "window_shift": int(diff_key == "local_window_4"),
            }
        )
    write_csv(OUT / "lost111_step4_matched_pair_comparison.csv", pair_rows)
    write_csv(OUT / "lost111_step5_earliest_divergence.csv", diff_rows)

    cf_rows = []
    for lr in lost:
        pass_row = lr["timeline"][-1]
        non_pre111_only = pass_row["entry_route"] == "START_IN_LAYER" and int(pass_row["transition_k"]) == 1
        cf_rows.append(
            {
                "trajectory_id": lr["n"],
                "pass_entry_route": pass_row["entry_route"],
                "pass_transition_k": pass_row["transition_k"],
                "pass_pre3": pass_row["pre_k_window_3"],
                "if_111_had_been_maintained_would_A_start_hold": "yes" if non_pre111_only else "no",
                "structural_note": "route and k already match A_start; only pre111 maintenance is absent"
                if non_pre111_only
                else "another A_start condition besides pre111 is absent",
            }
        )
    write_csv(OUT / "lost111_step6_counterfactual_structural_check.csv", cf_rows)

    cards = ["# Lost111 trajectory cards", ""]
    for lr in sorted(lost, key=lambda r: int(r["n"])):
        rows = lr["timeline"]
        formation_idx = int(lr["first111_index"])
        break_idx = int(lr["break_index"])
        cards.extend(
            [
                f"## Trajectory {lr['n']} (odd_core {lr['odd_core']})",
                "",
                f"- formation event: {formation_idx}",
                f"- break event: {break_idx}",
                f"- pass event: {len(rows) - 1}",
                "",
                "| event | marker | remaining_K | bin | transition | k | pre3 | local4 |",
                "|---:|---|---:|---|---|---:|---|---|",
            ]
        )
        for row in rows:
            idx = int(row["event_index"])
            marker = []
            if idx == 0:
                marker.append("entry")
            if idx == formation_idx:
                marker.append("111 formed")
            if idx == break_idx:
                marker.append("111 lost")
            if idx == len(rows) - 1:
                marker.append("pass")
            cards.append(
                f"| {idx} | {', '.join(marker)} | {row['remaining_K']} | {row['remaining_K_bin']} | {row['transition']} | {row['transition_k']} | {row['pre_k_window_3']} | {row['local_window_4']} |"
            )
        cards.append("")
    (OUT / "lost111_step7_trajectory_cards.md").write_text("\n".join(cards), encoding="utf-8")

    distances = [int(r["distance_break_to_pass"]) for r in break_rows]
    cf_yes = sum(1 for r in cf_rows if r["if_111_had_been_maintained_would_A_start_hold"] == "yes")
    report = [
        "# Micro-case analysis of trajectories that lose 111 before first pass",
        "",
        "Observational analysis only. Dataset and scanner mode: `original_n_strict`.",
        "",
        "## Verified groups",
        "",
        f"- Lost111: `{len(lost)}`",
        f"- matched Keep111: `{len(matches)}`",
        "",
        "## Matching quality",
        "",
        f"- mean |log2(n)| difference: `{fmt(mean(float(r['abs_log2_n']) for r in pair_rows))}`",
        f"- mean |total_K| difference: `{fmt(mean(float(r['abs_total_K']) for r in pair_rows))}`",
        f"- mean |first_pass_wait| difference: `{fmt(mean(float(r['abs_first_pass_wait']) for r in pair_rows))}`",
        f"- mean |word_length| difference: `{fmt(mean(float(r['abs_word_length']) for r in pair_rows))}`",
        "",
        "## Break categories",
        "",
        *[f"- `{r['break_category']}`: {r['count']}" for r in category_rows],
        "",
        "## Main descriptive answers",
        "",
        "1. The eight do not all fail in one exact row pattern, but the break is tightly localized: every case has formed 111 and then the current pre3 no longer remains `1,1,1` before pass.",
        f"2. The dominant break categories are listed above; the most common category is `{category_rows[0]['break_category']}`.",
        "3. In these rows, losing 111 is observed as a concrete interruption of the current k=1 run rather than passive survival of the same current pre3. Some rows retain all-1 material in local4 for a moment, which is recorded separately.",
        f"4. Median distance from break to pass is `{fmt(median(distances))}` events; min/max are `{min(distances)}` / `{max(distances)}`.",
        f"5. They are genuine near-A failures structurally in `{cf_yes}/{len(cf_rows)}` cases: if 111 had been maintained to pass, the remaining A_start route/k conditions would already hold.",
        "6. These eight support the reading that 111 maintenance, not merely first formation, separates A_start from this micro-subset of Other_start.",
        "",
        "## Output files",
        "",
        "- `lost111_step1_full_timeline.csv`",
        "- `lost111_step2_break_events.csv`",
        "- `lost111_step3_break_category_counts.csv`",
        "- `lost111_step4_matched_pair_comparison.csv`",
        "- `lost111_step5_earliest_divergence.csv`",
        "- `lost111_step6_counterfactual_structural_check.csv`",
        "- `lost111_step7_trajectory_cards.md`",
    ]
    (OUT / "lost111_microcase_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(OUT / "lost111_microcase_report.md")


if __name__ == "__main__":
    main()
